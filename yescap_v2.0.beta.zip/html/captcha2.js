/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 179);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */,
/* 1 */,
/* 2 */
/***/ (function(module, exports) {

// https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
var global = module.exports = typeof window != 'undefined' && window.Math == Math
  ? window : typeof self != 'undefined' && self.Math == Math ? self
  // eslint-disable-next-line no-new-func
  : Function('return this')();
if (typeof __g == 'number') __g = global; // eslint-disable-line no-undef


/***/ }),
/* 3 */,
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

var store = __webpack_require__(48)('wks');
var uid = __webpack_require__(49);
var Symbol = __webpack_require__(2).Symbol;
var USE_SYMBOL = typeof Symbol == 'function';

var $exports = module.exports = function (name) {
  return store[name] || (store[name] =
    USE_SYMBOL && Symbol[name] || (USE_SYMBOL ? Symbol : uid)('Symbol.' + name));
};

$exports.store = store;


/***/ }),
/* 5 */
/***/ (function(module, exports) {

var core = module.exports = { version: '2.6.12' };
if (typeof __e == 'number') __e = core; // eslint-disable-line no-undef


/***/ }),
/* 6 */,
/* 7 */,
/* 8 */,
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(15);
module.exports = function (it) {
  if (!isObject(it)) throw TypeError(it + ' is not an object!');
  return it;
};


/***/ }),
/* 10 */,
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

var dP = __webpack_require__(17);
var createDesc = __webpack_require__(42);
module.exports = __webpack_require__(13) ? function (object, key, value) {
  return dP.f(object, key, createDesc(1, value));
} : function (object, key, value) {
  object[key] = value;
  return object;
};


/***/ }),
/* 12 */,
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

// Thank's IE8 for his funny defineProperty
module.exports = !__webpack_require__(39)(function () {
  return Object.defineProperty({}, 'a', { get: function () { return 7; } }).a != 7;
});


/***/ }),
/* 14 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(2);
var core = __webpack_require__(5);
var ctx = __webpack_require__(18);
var hide = __webpack_require__(11);
var has = __webpack_require__(20);
var PROTOTYPE = 'prototype';

var $export = function (type, name, source) {
  var IS_FORCED = type & $export.F;
  var IS_GLOBAL = type & $export.G;
  var IS_STATIC = type & $export.S;
  var IS_PROTO = type & $export.P;
  var IS_BIND = type & $export.B;
  var IS_WRAP = type & $export.W;
  var exports = IS_GLOBAL ? core : core[name] || (core[name] = {});
  var expProto = exports[PROTOTYPE];
  var target = IS_GLOBAL ? global : IS_STATIC ? global[name] : (global[name] || {})[PROTOTYPE];
  var key, own, out;
  if (IS_GLOBAL) source = name;
  for (key in source) {
    // contains in native
    own = !IS_FORCED && target && target[key] !== undefined;
    if (own && has(exports, key)) continue;
    // export native or passed
    out = own ? target[key] : source[key];
    // prevent global pollution for namespaces
    exports[key] = IS_GLOBAL && typeof target[key] != 'function' ? source[key]
    // bind timers to global for call from export context
    : IS_BIND && own ? ctx(out, global)
    // wrap global constructors for prevent change them in library
    : IS_WRAP && target[key] == out ? (function (C) {
      var F = function (a, b, c) {
        if (this instanceof C) {
          switch (arguments.length) {
            case 0: return new C();
            case 1: return new C(a);
            case 2: return new C(a, b);
          } return new C(a, b, c);
        } return C.apply(this, arguments);
      };
      F[PROTOTYPE] = C[PROTOTYPE];
      return F;
    // make static versions for prototype methods
    })(out) : IS_PROTO && typeof out == 'function' ? ctx(Function.call, out) : out;
    // export proto methods to core.%CONSTRUCTOR%.methods.%NAME%
    if (IS_PROTO) {
      (exports.virtual || (exports.virtual = {}))[key] = out;
      // export proto methods to core.%CONSTRUCTOR%.prototype.%NAME%
      if (type & $export.R && expProto && !expProto[key]) hide(expProto, key, out);
    }
  }
};
// type bitmap
$export.F = 1;   // forced
$export.G = 2;   // global
$export.S = 4;   // static
$export.P = 8;   // proto
$export.B = 16;  // bind
$export.W = 32;  // wrap
$export.U = 64;  // safe
$export.R = 128; // real proto method for `library`
module.exports = $export;


/***/ }),
/* 15 */
/***/ (function(module, exports) {

module.exports = function (it) {
  return typeof it === 'object' ? it !== null : typeof it === 'function';
};


/***/ }),
/* 16 */
/***/ (function(module, exports) {

module.exports = {};


/***/ }),
/* 17 */
/***/ (function(module, exports, __webpack_require__) {

var anObject = __webpack_require__(9);
var IE8_DOM_DEFINE = __webpack_require__(78);
var toPrimitive = __webpack_require__(79);
var dP = Object.defineProperty;

exports.f = __webpack_require__(13) ? Object.defineProperty : function defineProperty(O, P, Attributes) {
  anObject(O);
  P = toPrimitive(P, true);
  anObject(Attributes);
  if (IE8_DOM_DEFINE) try {
    return dP(O, P, Attributes);
  } catch (e) { /* empty */ }
  if ('get' in Attributes || 'set' in Attributes) throw TypeError('Accessors not supported!');
  if ('value' in Attributes) O[P] = Attributes.value;
  return O;
};


/***/ }),
/* 18 */
/***/ (function(module, exports, __webpack_require__) {

// optional / simple context binding
var aFunction = __webpack_require__(22);
module.exports = function (fn, that, length) {
  aFunction(fn);
  if (that === undefined) return fn;
  switch (length) {
    case 1: return function (a) {
      return fn.call(that, a);
    };
    case 2: return function (a, b) {
      return fn.call(that, a, b);
    };
    case 3: return function (a, b, c) {
      return fn.call(that, a, b, c);
    };
  }
  return function (/* ...args */) {
    return fn.apply(that, arguments);
  };
};


/***/ }),
/* 19 */,
/* 20 */
/***/ (function(module, exports) {

var hasOwnProperty = {}.hasOwnProperty;
module.exports = function (it, key) {
  return hasOwnProperty.call(it, key);
};


/***/ }),
/* 21 */
/***/ (function(module, exports) {

var toString = {}.toString;

module.exports = function (it) {
  return toString.call(it).slice(8, -1);
};


/***/ }),
/* 22 */
/***/ (function(module, exports) {

module.exports = function (it) {
  if (typeof it != 'function') throw TypeError(it + ' is not a function!');
  return it;
};


/***/ }),
/* 23 */,
/* 24 */,
/* 25 */,
/* 26 */,
/* 27 */,
/* 28 */
/***/ (function(module, exports) {

// 7.2.1 RequireObjectCoercible(argument)
module.exports = function (it) {
  if (it == undefined) throw TypeError("Can't call method on  " + it);
  return it;
};


/***/ }),
/* 29 */
/***/ (function(module, exports, __webpack_require__) {

// to indexed object, toObject with fallback for non-array-like ES3 strings
var IObject = __webpack_require__(66);
var defined = __webpack_require__(28);
module.exports = function (it) {
  return IObject(defined(it));
};


/***/ }),
/* 30 */
/***/ (function(module, exports) {

// 7.1.4 ToInteger
var ceil = Math.ceil;
var floor = Math.floor;
module.exports = function (it) {
  return isNaN(it = +it) ? 0 : (it > 0 ? floor : ceil)(it);
};


/***/ }),
/* 31 */
/***/ (function(module, exports, __webpack_require__) {

var shared = __webpack_require__(48)('keys');
var uid = __webpack_require__(49);
module.exports = function (key) {
  return shared[key] || (shared[key] = uid(key));
};


/***/ }),
/* 32 */
/***/ (function(module, exports) {

module.exports = true;


/***/ }),
/* 33 */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(15);
var document = __webpack_require__(2).document;
// typeof document.createElement is 'object' in old IE
var is = isObject(document) && isObject(document.createElement);
module.exports = function (it) {
  return is ? document.createElement(it) : {};
};


/***/ }),
/* 34 */
/***/ (function(module, exports, __webpack_require__) {

var def = __webpack_require__(17).f;
var has = __webpack_require__(20);
var TAG = __webpack_require__(4)('toStringTag');

module.exports = function (it, tag, stat) {
  if (it && !has(it = stat ? it : it.prototype, TAG)) def(it, TAG, { configurable: true, value: tag });
};


/***/ }),
/* 35 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 25.4.1.5 NewPromiseCapability(C)
var aFunction = __webpack_require__(22);

function PromiseCapability(C) {
  var resolve, reject;
  this.promise = new C(function ($$resolve, $$reject) {
    if (resolve !== undefined || reject !== undefined) throw TypeError('Bad Promise constructor');
    resolve = $$resolve;
    reject = $$reject;
  });
  this.resolve = aFunction(resolve);
  this.reject = aFunction(reject);
}

module.exports.f = function (C) {
  return new PromiseCapability(C);
};


/***/ }),
/* 36 */,
/* 37 */,
/* 38 */,
/* 39 */
/***/ (function(module, exports) {

module.exports = function (exec) {
  try {
    return !!exec();
  } catch (e) {
    return true;
  }
};


/***/ }),
/* 40 */,
/* 41 */
/***/ (function(module, exports, __webpack_require__) {

// 7.1.15 ToLength
var toInteger = __webpack_require__(30);
var min = Math.min;
module.exports = function (it) {
  return it > 0 ? min(toInteger(it), 0x1fffffffffffff) : 0; // pow(2, 53) - 1 == 9007199254740991
};


/***/ }),
/* 42 */
/***/ (function(module, exports) {

module.exports = function (bitmap, value) {
  return {
    enumerable: !(bitmap & 1),
    configurable: !(bitmap & 2),
    writable: !(bitmap & 4),
    value: value
  };
};


/***/ }),
/* 43 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(86);


/***/ }),
/* 44 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _promise = __webpack_require__(45);

var _promise2 = _interopRequireDefault(_promise);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = function (fn) {
  return function () {
    var gen = fn.apply(this, arguments);
    return new _promise2.default(function (resolve, reject) {
      function step(key, arg) {
        try {
          var info = gen[key](arg);
          var value = info.value;
        } catch (error) {
          reject(error);
          return;
        }

        if (info.done) {
          resolve(value);
        } else {
          return _promise2.default.resolve(value).then(function (value) {
            step("next", value);
          }, function (err) {
            step("throw", err);
          });
        }
      }

      return step("next");
    });
  };
};

/***/ }),
/* 45 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(88), __esModule: true };

/***/ }),
/* 46 */,
/* 47 */
/***/ (function(module, exports, __webpack_require__) {

// 7.1.13 ToObject(argument)
var defined = __webpack_require__(28);
module.exports = function (it) {
  return Object(defined(it));
};


/***/ }),
/* 48 */
/***/ (function(module, exports, __webpack_require__) {

var core = __webpack_require__(5);
var global = __webpack_require__(2);
var SHARED = '__core-js_shared__';
var store = global[SHARED] || (global[SHARED] = {});

(module.exports = function (key, value) {
  return store[key] || (store[key] = value !== undefined ? value : {});
})('versions', []).push({
  version: core.version,
  mode: __webpack_require__(32) ? 'pure' : 'global',
  copyright: '© 2020 Denis Pushkarev (zloirock.ru)'
});


/***/ }),
/* 49 */
/***/ (function(module, exports) {

var id = 0;
var px = Math.random();
module.exports = function (key) {
  return 'Symbol('.concat(key === undefined ? '' : key, ')_', (++id + px).toString(36));
};


/***/ }),
/* 50 */
/***/ (function(module, exports) {

// IE 8- don't enum bug keys
module.exports = (
  'constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf'
).split(',');


/***/ }),
/* 51 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var LIBRARY = __webpack_require__(32);
var $export = __webpack_require__(14);
var redefine = __webpack_require__(81);
var hide = __webpack_require__(11);
var Iterators = __webpack_require__(16);
var $iterCreate = __webpack_require__(82);
var setToStringTag = __webpack_require__(34);
var getPrototypeOf = __webpack_require__(85);
var ITERATOR = __webpack_require__(4)('iterator');
var BUGGY = !([].keys && 'next' in [].keys()); // Safari has buggy iterators w/o `next`
var FF_ITERATOR = '@@iterator';
var KEYS = 'keys';
var VALUES = 'values';

var returnThis = function () { return this; };

module.exports = function (Base, NAME, Constructor, next, DEFAULT, IS_SET, FORCED) {
  $iterCreate(Constructor, NAME, next);
  var getMethod = function (kind) {
    if (!BUGGY && kind in proto) return proto[kind];
    switch (kind) {
      case KEYS: return function keys() { return new Constructor(this, kind); };
      case VALUES: return function values() { return new Constructor(this, kind); };
    } return function entries() { return new Constructor(this, kind); };
  };
  var TAG = NAME + ' Iterator';
  var DEF_VALUES = DEFAULT == VALUES;
  var VALUES_BUG = false;
  var proto = Base.prototype;
  var $native = proto[ITERATOR] || proto[FF_ITERATOR] || DEFAULT && proto[DEFAULT];
  var $default = $native || getMethod(DEFAULT);
  var $entries = DEFAULT ? !DEF_VALUES ? $default : getMethod('entries') : undefined;
  var $anyNative = NAME == 'Array' ? proto.entries || $native : $native;
  var methods, key, IteratorPrototype;
  // Fix native
  if ($anyNative) {
    IteratorPrototype = getPrototypeOf($anyNative.call(new Base()));
    if (IteratorPrototype !== Object.prototype && IteratorPrototype.next) {
      // Set @@toStringTag to native iterators
      setToStringTag(IteratorPrototype, TAG, true);
      // fix for some old engines
      if (!LIBRARY && typeof IteratorPrototype[ITERATOR] != 'function') hide(IteratorPrototype, ITERATOR, returnThis);
    }
  }
  // fix Array#{values, @@iterator}.name in V8 / FF
  if (DEF_VALUES && $native && $native.name !== VALUES) {
    VALUES_BUG = true;
    $default = function values() { return $native.call(this); };
  }
  // Define iterator
  if ((!LIBRARY || FORCED) && (BUGGY || VALUES_BUG || !proto[ITERATOR])) {
    hide(proto, ITERATOR, $default);
  }
  // Plug for library
  Iterators[NAME] = $default;
  Iterators[TAG] = returnThis;
  if (DEFAULT) {
    methods = {
      values: DEF_VALUES ? $default : getMethod(VALUES),
      keys: IS_SET ? $default : getMethod(KEYS),
      entries: $entries
    };
    if (FORCED) for (key in methods) {
      if (!(key in proto)) redefine(proto, key, methods[key]);
    } else $export($export.P + $export.F * (BUGGY || VALUES_BUG), NAME, methods);
  }
  return methods;
};


/***/ }),
/* 52 */
/***/ (function(module, exports, __webpack_require__) {

var document = __webpack_require__(2).document;
module.exports = document && document.documentElement;


/***/ }),
/* 53 */
/***/ (function(module, exports, __webpack_require__) {

// getting tag from 19.1.3.6 Object.prototype.toString()
var cof = __webpack_require__(21);
var TAG = __webpack_require__(4)('toStringTag');
// ES3 wrong here
var ARG = cof(function () { return arguments; }()) == 'Arguments';

// fallback for IE11 Script Access Denied error
var tryGet = function (it, key) {
  try {
    return it[key];
  } catch (e) { /* empty */ }
};

module.exports = function (it) {
  var O, T, B;
  return it === undefined ? 'Undefined' : it === null ? 'Null'
    // @@toStringTag case
    : typeof (T = tryGet(O = Object(it), TAG)) == 'string' ? T
    // builtinTag case
    : ARG ? cof(O)
    // ES3 arguments fallback
    : (B = cof(O)) == 'Object' && typeof O.callee == 'function' ? 'Arguments' : B;
};


/***/ }),
/* 54 */
/***/ (function(module, exports, __webpack_require__) {

// 7.3.20 SpeciesConstructor(O, defaultConstructor)
var anObject = __webpack_require__(9);
var aFunction = __webpack_require__(22);
var SPECIES = __webpack_require__(4)('species');
module.exports = function (O, D) {
  var C = anObject(O).constructor;
  var S;
  return C === undefined || (S = anObject(C)[SPECIES]) == undefined ? D : aFunction(S);
};


/***/ }),
/* 55 */
/***/ (function(module, exports, __webpack_require__) {

var ctx = __webpack_require__(18);
var invoke = __webpack_require__(97);
var html = __webpack_require__(52);
var cel = __webpack_require__(33);
var global = __webpack_require__(2);
var process = global.process;
var setTask = global.setImmediate;
var clearTask = global.clearImmediate;
var MessageChannel = global.MessageChannel;
var Dispatch = global.Dispatch;
var counter = 0;
var queue = {};
var ONREADYSTATECHANGE = 'onreadystatechange';
var defer, channel, port;
var run = function () {
  var id = +this;
  // eslint-disable-next-line no-prototype-builtins
  if (queue.hasOwnProperty(id)) {
    var fn = queue[id];
    delete queue[id];
    fn();
  }
};
var listener = function (event) {
  run.call(event.data);
};
// Node.js 0.9+ & IE10+ has setImmediate, otherwise:
if (!setTask || !clearTask) {
  setTask = function setImmediate(fn) {
    var args = [];
    var i = 1;
    while (arguments.length > i) args.push(arguments[i++]);
    queue[++counter] = function () {
      // eslint-disable-next-line no-new-func
      invoke(typeof fn == 'function' ? fn : Function(fn), args);
    };
    defer(counter);
    return counter;
  };
  clearTask = function clearImmediate(id) {
    delete queue[id];
  };
  // Node.js 0.8-
  if (__webpack_require__(21)(process) == 'process') {
    defer = function (id) {
      process.nextTick(ctx(run, id, 1));
    };
  // Sphere (JS game engine) Dispatch API
  } else if (Dispatch && Dispatch.now) {
    defer = function (id) {
      Dispatch.now(ctx(run, id, 1));
    };
  // Browsers with MessageChannel, includes WebWorkers
  } else if (MessageChannel) {
    channel = new MessageChannel();
    port = channel.port2;
    channel.port1.onmessage = listener;
    defer = ctx(port.postMessage, port, 1);
  // Browsers with postMessage, skip WebWorkers
  // IE8 has postMessage, but it's sync & typeof its postMessage is 'object'
  } else if (global.addEventListener && typeof postMessage == 'function' && !global.importScripts) {
    defer = function (id) {
      global.postMessage(id + '', '*');
    };
    global.addEventListener('message', listener, false);
  // IE8-
  } else if (ONREADYSTATECHANGE in cel('script')) {
    defer = function (id) {
      html.appendChild(cel('script'))[ONREADYSTATECHANGE] = function () {
        html.removeChild(this);
        run.call(id);
      };
    };
  // Rest old browsers
  } else {
    defer = function (id) {
      setTimeout(ctx(run, id, 1), 0);
    };
  }
}
module.exports = {
  set: setTask,
  clear: clearTask
};


/***/ }),
/* 56 */
/***/ (function(module, exports) {

module.exports = function (exec) {
  try {
    return { e: false, v: exec() };
  } catch (e) {
    return { e: true, v: e };
  }
};


/***/ }),
/* 57 */
/***/ (function(module, exports, __webpack_require__) {

var anObject = __webpack_require__(9);
var isObject = __webpack_require__(15);
var newPromiseCapability = __webpack_require__(35);

module.exports = function (C, x) {
  anObject(C);
  if (isObject(x) && x.constructor === C) return x;
  var promiseCapability = newPromiseCapability.f(C);
  var resolve = promiseCapability.resolve;
  resolve(x);
  return promiseCapability.promise;
};


/***/ }),
/* 58 */,
/* 59 */,
/* 60 */,
/* 61 */,
/* 62 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.14 / 15.2.3.14 Object.keys(O)
var $keys = __webpack_require__(75);
var enumBugKeys = __webpack_require__(50);

module.exports = Object.keys || function keys(O) {
  return $keys(O, enumBugKeys);
};


/***/ }),
/* 63 */,
/* 64 */,
/* 65 */,
/* 66 */
/***/ (function(module, exports, __webpack_require__) {

// fallback for non-array-like ES3 and non-enumerable old V8 strings
var cof = __webpack_require__(21);
// eslint-disable-next-line no-prototype-builtins
module.exports = Object('z').propertyIsEnumerable(0) ? Object : function (it) {
  return cof(it) == 'String' ? it.split('') : Object(it);
};


/***/ }),
/* 67 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $at = __webpack_require__(80)(true);

// 21.1.3.27 String.prototype[@@iterator]()
__webpack_require__(51)(String, 'String', function (iterated) {
  this._t = String(iterated); // target
  this._i = 0;                // next index
// 21.1.5.2.1 %StringIteratorPrototype%.next()
}, function () {
  var O = this._t;
  var index = this._i;
  var point;
  if (index >= O.length) return { value: undefined, done: true };
  point = $at(O, index);
  this._i += point.length;
  return { value: point, done: false };
});


/***/ }),
/* 68 */
/***/ (function(module, exports, __webpack_require__) {

// call something on iterator step with safe closing on error
var anObject = __webpack_require__(9);
module.exports = function (iterator, fn, value, entries) {
  try {
    return entries ? fn(anObject(value)[0], value[1]) : fn(value);
  // 7.4.6 IteratorClose(iterator, completion)
  } catch (e) {
    var ret = iterator['return'];
    if (ret !== undefined) anObject(ret.call(iterator));
    throw e;
  }
};


/***/ }),
/* 69 */
/***/ (function(module, exports, __webpack_require__) {

// check on default Array iterator
var Iterators = __webpack_require__(16);
var ITERATOR = __webpack_require__(4)('iterator');
var ArrayProto = Array.prototype;

module.exports = function (it) {
  return it !== undefined && (Iterators.Array === it || ArrayProto[ITERATOR] === it);
};


/***/ }),
/* 70 */
/***/ (function(module, exports, __webpack_require__) {

var classof = __webpack_require__(53);
var ITERATOR = __webpack_require__(4)('iterator');
var Iterators = __webpack_require__(16);
module.exports = __webpack_require__(5).getIteratorMethod = function (it) {
  if (it != undefined) return it[ITERATOR]
    || it['@@iterator']
    || Iterators[classof(it)];
};


/***/ }),
/* 71 */
/***/ (function(module, exports, __webpack_require__) {

var ITERATOR = __webpack_require__(4)('iterator');
var SAFE_CLOSING = false;

try {
  var riter = [7][ITERATOR]();
  riter['return'] = function () { SAFE_CLOSING = true; };
  // eslint-disable-next-line no-throw-literal
  Array.from(riter, function () { throw 2; });
} catch (e) { /* empty */ }

module.exports = function (exec, skipClosing) {
  if (!skipClosing && !SAFE_CLOSING) return false;
  var safe = false;
  try {
    var arr = [7];
    var iter = arr[ITERATOR]();
    iter.next = function () { return { done: safe = true }; };
    arr[ITERATOR] = function () { return iter; };
    exec(arr);
  } catch (e) { /* empty */ }
  return safe;
};


/***/ }),
/* 72 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
var config = exports.config = { HOST: 'http://jscn.sz-hgy.com', develop: true };

/***/ }),
/* 73 */,
/* 74 */,
/* 75 */
/***/ (function(module, exports, __webpack_require__) {

var has = __webpack_require__(20);
var toIObject = __webpack_require__(29);
var arrayIndexOf = __webpack_require__(76)(false);
var IE_PROTO = __webpack_require__(31)('IE_PROTO');

module.exports = function (object, names) {
  var O = toIObject(object);
  var i = 0;
  var result = [];
  var key;
  for (key in O) if (key != IE_PROTO) has(O, key) && result.push(key);
  // Don't enum bug & hidden keys
  while (names.length > i) if (has(O, key = names[i++])) {
    ~arrayIndexOf(result, key) || result.push(key);
  }
  return result;
};


/***/ }),
/* 76 */
/***/ (function(module, exports, __webpack_require__) {

// false -> Array#indexOf
// true  -> Array#includes
var toIObject = __webpack_require__(29);
var toLength = __webpack_require__(41);
var toAbsoluteIndex = __webpack_require__(77);
module.exports = function (IS_INCLUDES) {
  return function ($this, el, fromIndex) {
    var O = toIObject($this);
    var length = toLength(O.length);
    var index = toAbsoluteIndex(fromIndex, length);
    var value;
    // Array#includes uses SameValueZero equality algorithm
    // eslint-disable-next-line no-self-compare
    if (IS_INCLUDES && el != el) while (length > index) {
      value = O[index++];
      // eslint-disable-next-line no-self-compare
      if (value != value) return true;
    // Array#indexOf ignores holes, Array#includes - not
    } else for (;length > index; index++) if (IS_INCLUDES || index in O) {
      if (O[index] === el) return IS_INCLUDES || index || 0;
    } return !IS_INCLUDES && -1;
  };
};


/***/ }),
/* 77 */
/***/ (function(module, exports, __webpack_require__) {

var toInteger = __webpack_require__(30);
var max = Math.max;
var min = Math.min;
module.exports = function (index, length) {
  index = toInteger(index);
  return index < 0 ? max(index + length, 0) : min(index, length);
};


/***/ }),
/* 78 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = !__webpack_require__(13) && !__webpack_require__(39)(function () {
  return Object.defineProperty(__webpack_require__(33)('div'), 'a', { get: function () { return 7; } }).a != 7;
});


/***/ }),
/* 79 */
/***/ (function(module, exports, __webpack_require__) {

// 7.1.1 ToPrimitive(input [, PreferredType])
var isObject = __webpack_require__(15);
// instead of the ES6 spec version, we didn't implement @@toPrimitive case
// and the second argument - flag - preferred type is a string
module.exports = function (it, S) {
  if (!isObject(it)) return it;
  var fn, val;
  if (S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
  if (typeof (fn = it.valueOf) == 'function' && !isObject(val = fn.call(it))) return val;
  if (!S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
  throw TypeError("Can't convert object to primitive value");
};


/***/ }),
/* 80 */
/***/ (function(module, exports, __webpack_require__) {

var toInteger = __webpack_require__(30);
var defined = __webpack_require__(28);
// true  -> String#at
// false -> String#codePointAt
module.exports = function (TO_STRING) {
  return function (that, pos) {
    var s = String(defined(that));
    var i = toInteger(pos);
    var l = s.length;
    var a, b;
    if (i < 0 || i >= l) return TO_STRING ? '' : undefined;
    a = s.charCodeAt(i);
    return a < 0xd800 || a > 0xdbff || i + 1 === l || (b = s.charCodeAt(i + 1)) < 0xdc00 || b > 0xdfff
      ? TO_STRING ? s.charAt(i) : a
      : TO_STRING ? s.slice(i, i + 2) : (a - 0xd800 << 10) + (b - 0xdc00) + 0x10000;
  };
};


/***/ }),
/* 81 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(11);


/***/ }),
/* 82 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var create = __webpack_require__(83);
var descriptor = __webpack_require__(42);
var setToStringTag = __webpack_require__(34);
var IteratorPrototype = {};

// 25.1.2.1.1 %IteratorPrototype%[@@iterator]()
__webpack_require__(11)(IteratorPrototype, __webpack_require__(4)('iterator'), function () { return this; });

module.exports = function (Constructor, NAME, next) {
  Constructor.prototype = create(IteratorPrototype, { next: descriptor(1, next) });
  setToStringTag(Constructor, NAME + ' Iterator');
};


/***/ }),
/* 83 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.2 / 15.2.3.5 Object.create(O [, Properties])
var anObject = __webpack_require__(9);
var dPs = __webpack_require__(84);
var enumBugKeys = __webpack_require__(50);
var IE_PROTO = __webpack_require__(31)('IE_PROTO');
var Empty = function () { /* empty */ };
var PROTOTYPE = 'prototype';

// Create object with fake `null` prototype: use iframe Object with cleared prototype
var createDict = function () {
  // Thrash, waste and sodomy: IE GC bug
  var iframe = __webpack_require__(33)('iframe');
  var i = enumBugKeys.length;
  var lt = '<';
  var gt = '>';
  var iframeDocument;
  iframe.style.display = 'none';
  __webpack_require__(52).appendChild(iframe);
  iframe.src = 'javascript:'; // eslint-disable-line no-script-url
  // createDict = iframe.contentWindow.Object;
  // html.removeChild(iframe);
  iframeDocument = iframe.contentWindow.document;
  iframeDocument.open();
  iframeDocument.write(lt + 'script' + gt + 'document.F=Object' + lt + '/script' + gt);
  iframeDocument.close();
  createDict = iframeDocument.F;
  while (i--) delete createDict[PROTOTYPE][enumBugKeys[i]];
  return createDict();
};

module.exports = Object.create || function create(O, Properties) {
  var result;
  if (O !== null) {
    Empty[PROTOTYPE] = anObject(O);
    result = new Empty();
    Empty[PROTOTYPE] = null;
    // add "__proto__" for Object.getPrototypeOf polyfill
    result[IE_PROTO] = O;
  } else result = createDict();
  return Properties === undefined ? result : dPs(result, Properties);
};


/***/ }),
/* 84 */
/***/ (function(module, exports, __webpack_require__) {

var dP = __webpack_require__(17);
var anObject = __webpack_require__(9);
var getKeys = __webpack_require__(62);

module.exports = __webpack_require__(13) ? Object.defineProperties : function defineProperties(O, Properties) {
  anObject(O);
  var keys = getKeys(Properties);
  var length = keys.length;
  var i = 0;
  var P;
  while (length > i) dP.f(O, P = keys[i++], Properties[P]);
  return O;
};


/***/ }),
/* 85 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.9 / 15.2.3.2 Object.getPrototypeOf(O)
var has = __webpack_require__(20);
var toObject = __webpack_require__(47);
var IE_PROTO = __webpack_require__(31)('IE_PROTO');
var ObjectProto = Object.prototype;

module.exports = Object.getPrototypeOf || function (O) {
  O = toObject(O);
  if (has(O, IE_PROTO)) return O[IE_PROTO];
  if (typeof O.constructor == 'function' && O instanceof O.constructor) {
    return O.constructor.prototype;
  } return O instanceof Object ? ObjectProto : null;
};


/***/ }),
/* 86 */
/***/ (function(module, exports, __webpack_require__) {

/**
 * Copyright (c) 2014-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

// This method of obtaining a reference to the global object needs to be
// kept identical to the way it is obtained in runtime.js
var g = (function() { return this })() || Function("return this")();

// Use `getOwnPropertyNames` because not all browsers support calling
// `hasOwnProperty` on the global `self` object in a worker. See #183.
var hadRuntime = g.regeneratorRuntime &&
  Object.getOwnPropertyNames(g).indexOf("regeneratorRuntime") >= 0;

// Save the old regeneratorRuntime in case it needs to be restored later.
var oldRuntime = hadRuntime && g.regeneratorRuntime;

// Force reevalutation of runtime.js.
g.regeneratorRuntime = undefined;

module.exports = __webpack_require__(87);

if (hadRuntime) {
  // Restore the original runtime.
  g.regeneratorRuntime = oldRuntime;
} else {
  // Remove the global property added by runtime.js.
  try {
    delete g.regeneratorRuntime;
  } catch(e) {
    g.regeneratorRuntime = undefined;
  }
}


/***/ }),
/* 87 */
/***/ (function(module, exports) {

/**
 * Copyright (c) 2014-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

!(function(global) {
  "use strict";

  var Op = Object.prototype;
  var hasOwn = Op.hasOwnProperty;
  var undefined; // More compressible than void 0.
  var $Symbol = typeof Symbol === "function" ? Symbol : {};
  var iteratorSymbol = $Symbol.iterator || "@@iterator";
  var asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator";
  var toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";

  var inModule = typeof module === "object";
  var runtime = global.regeneratorRuntime;
  if (runtime) {
    if (inModule) {
      // If regeneratorRuntime is defined globally and we're in a module,
      // make the exports object identical to regeneratorRuntime.
      module.exports = runtime;
    }
    // Don't bother evaluating the rest of this file if the runtime was
    // already defined globally.
    return;
  }

  // Define the runtime globally (as expected by generated code) as either
  // module.exports (if we're in a module) or a new, empty object.
  runtime = global.regeneratorRuntime = inModule ? module.exports : {};

  function wrap(innerFn, outerFn, self, tryLocsList) {
    // If outerFn provided and outerFn.prototype is a Generator, then outerFn.prototype instanceof Generator.
    var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator;
    var generator = Object.create(protoGenerator.prototype);
    var context = new Context(tryLocsList || []);

    // The ._invoke method unifies the implementations of the .next,
    // .throw, and .return methods.
    generator._invoke = makeInvokeMethod(innerFn, self, context);

    return generator;
  }
  runtime.wrap = wrap;

  // Try/catch helper to minimize deoptimizations. Returns a completion
  // record like context.tryEntries[i].completion. This interface could
  // have been (and was previously) designed to take a closure to be
  // invoked without arguments, but in all the cases we care about we
  // already have an existing method we want to call, so there's no need
  // to create a new function object. We can even get away with assuming
  // the method takes exactly one argument, since that happens to be true
  // in every case, so we don't have to touch the arguments object. The
  // only additional allocation required is the completion record, which
  // has a stable shape and so hopefully should be cheap to allocate.
  function tryCatch(fn, obj, arg) {
    try {
      return { type: "normal", arg: fn.call(obj, arg) };
    } catch (err) {
      return { type: "throw", arg: err };
    }
  }

  var GenStateSuspendedStart = "suspendedStart";
  var GenStateSuspendedYield = "suspendedYield";
  var GenStateExecuting = "executing";
  var GenStateCompleted = "completed";

  // Returning this object from the innerFn has the same effect as
  // breaking out of the dispatch switch statement.
  var ContinueSentinel = {};

  // Dummy constructor functions that we use as the .constructor and
  // .constructor.prototype properties for functions that return Generator
  // objects. For full spec compliance, you may wish to configure your
  // minifier not to mangle the names of these two functions.
  function Generator() {}
  function GeneratorFunction() {}
  function GeneratorFunctionPrototype() {}

  // This is a polyfill for %IteratorPrototype% for environments that
  // don't natively support it.
  var IteratorPrototype = {};
  IteratorPrototype[iteratorSymbol] = function () {
    return this;
  };

  var getProto = Object.getPrototypeOf;
  var NativeIteratorPrototype = getProto && getProto(getProto(values([])));
  if (NativeIteratorPrototype &&
      NativeIteratorPrototype !== Op &&
      hasOwn.call(NativeIteratorPrototype, iteratorSymbol)) {
    // This environment has a native %IteratorPrototype%; use it instead
    // of the polyfill.
    IteratorPrototype = NativeIteratorPrototype;
  }

  var Gp = GeneratorFunctionPrototype.prototype =
    Generator.prototype = Object.create(IteratorPrototype);
  GeneratorFunction.prototype = Gp.constructor = GeneratorFunctionPrototype;
  GeneratorFunctionPrototype.constructor = GeneratorFunction;
  GeneratorFunctionPrototype[toStringTagSymbol] =
    GeneratorFunction.displayName = "GeneratorFunction";

  // Helper for defining the .next, .throw, and .return methods of the
  // Iterator interface in terms of a single ._invoke method.
  function defineIteratorMethods(prototype) {
    ["next", "throw", "return"].forEach(function(method) {
      prototype[method] = function(arg) {
        return this._invoke(method, arg);
      };
    });
  }

  runtime.isGeneratorFunction = function(genFun) {
    var ctor = typeof genFun === "function" && genFun.constructor;
    return ctor
      ? ctor === GeneratorFunction ||
        // For the native GeneratorFunction constructor, the best we can
        // do is to check its .name property.
        (ctor.displayName || ctor.name) === "GeneratorFunction"
      : false;
  };

  runtime.mark = function(genFun) {
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(genFun, GeneratorFunctionPrototype);
    } else {
      genFun.__proto__ = GeneratorFunctionPrototype;
      if (!(toStringTagSymbol in genFun)) {
        genFun[toStringTagSymbol] = "GeneratorFunction";
      }
    }
    genFun.prototype = Object.create(Gp);
    return genFun;
  };

  // Within the body of any async function, `await x` is transformed to
  // `yield regeneratorRuntime.awrap(x)`, so that the runtime can test
  // `hasOwn.call(value, "__await")` to determine if the yielded value is
  // meant to be awaited.
  runtime.awrap = function(arg) {
    return { __await: arg };
  };

  function AsyncIterator(generator) {
    function invoke(method, arg, resolve, reject) {
      var record = tryCatch(generator[method], generator, arg);
      if (record.type === "throw") {
        reject(record.arg);
      } else {
        var result = record.arg;
        var value = result.value;
        if (value &&
            typeof value === "object" &&
            hasOwn.call(value, "__await")) {
          return Promise.resolve(value.__await).then(function(value) {
            invoke("next", value, resolve, reject);
          }, function(err) {
            invoke("throw", err, resolve, reject);
          });
        }

        return Promise.resolve(value).then(function(unwrapped) {
          // When a yielded Promise is resolved, its final value becomes
          // the .value of the Promise<{value,done}> result for the
          // current iteration. If the Promise is rejected, however, the
          // result for this iteration will be rejected with the same
          // reason. Note that rejections of yielded Promises are not
          // thrown back into the generator function, as is the case
          // when an awaited Promise is rejected. This difference in
          // behavior between yield and await is important, because it
          // allows the consumer to decide what to do with the yielded
          // rejection (swallow it and continue, manually .throw it back
          // into the generator, abandon iteration, whatever). With
          // await, by contrast, there is no opportunity to examine the
          // rejection reason outside the generator function, so the
          // only option is to throw it from the await expression, and
          // let the generator function handle the exception.
          result.value = unwrapped;
          resolve(result);
        }, reject);
      }
    }

    var previousPromise;

    function enqueue(method, arg) {
      function callInvokeWithMethodAndArg() {
        return new Promise(function(resolve, reject) {
          invoke(method, arg, resolve, reject);
        });
      }

      return previousPromise =
        // If enqueue has been called before, then we want to wait until
        // all previous Promises have been resolved before calling invoke,
        // so that results are always delivered in the correct order. If
        // enqueue has not been called before, then it is important to
        // call invoke immediately, without waiting on a callback to fire,
        // so that the async generator function has the opportunity to do
        // any necessary setup in a predictable way. This predictability
        // is why the Promise constructor synchronously invokes its
        // executor callback, and why async functions synchronously
        // execute code before the first await. Since we implement simple
        // async functions in terms of async generators, it is especially
        // important to get this right, even though it requires care.
        previousPromise ? previousPromise.then(
          callInvokeWithMethodAndArg,
          // Avoid propagating failures to Promises returned by later
          // invocations of the iterator.
          callInvokeWithMethodAndArg
        ) : callInvokeWithMethodAndArg();
    }

    // Define the unified helper method that is used to implement .next,
    // .throw, and .return (see defineIteratorMethods).
    this._invoke = enqueue;
  }

  defineIteratorMethods(AsyncIterator.prototype);
  AsyncIterator.prototype[asyncIteratorSymbol] = function () {
    return this;
  };
  runtime.AsyncIterator = AsyncIterator;

  // Note that simple async functions are implemented on top of
  // AsyncIterator objects; they just return a Promise for the value of
  // the final result produced by the iterator.
  runtime.async = function(innerFn, outerFn, self, tryLocsList) {
    var iter = new AsyncIterator(
      wrap(innerFn, outerFn, self, tryLocsList)
    );

    return runtime.isGeneratorFunction(outerFn)
      ? iter // If outerFn is a generator, return the full iterator.
      : iter.next().then(function(result) {
          return result.done ? result.value : iter.next();
        });
  };

  function makeInvokeMethod(innerFn, self, context) {
    var state = GenStateSuspendedStart;

    return function invoke(method, arg) {
      if (state === GenStateExecuting) {
        throw new Error("Generator is already running");
      }

      if (state === GenStateCompleted) {
        if (method === "throw") {
          throw arg;
        }

        // Be forgiving, per 25.3.3.3.3 of the spec:
        // https://people.mozilla.org/~jorendorff/es6-draft.html#sec-generatorresume
        return doneResult();
      }

      context.method = method;
      context.arg = arg;

      while (true) {
        var delegate = context.delegate;
        if (delegate) {
          var delegateResult = maybeInvokeDelegate(delegate, context);
          if (delegateResult) {
            if (delegateResult === ContinueSentinel) continue;
            return delegateResult;
          }
        }

        if (context.method === "next") {
          // Setting context._sent for legacy support of Babel's
          // function.sent implementation.
          context.sent = context._sent = context.arg;

        } else if (context.method === "throw") {
          if (state === GenStateSuspendedStart) {
            state = GenStateCompleted;
            throw context.arg;
          }

          context.dispatchException(context.arg);

        } else if (context.method === "return") {
          context.abrupt("return", context.arg);
        }

        state = GenStateExecuting;

        var record = tryCatch(innerFn, self, context);
        if (record.type === "normal") {
          // If an exception is thrown from innerFn, we leave state ===
          // GenStateExecuting and loop back for another invocation.
          state = context.done
            ? GenStateCompleted
            : GenStateSuspendedYield;

          if (record.arg === ContinueSentinel) {
            continue;
          }

          return {
            value: record.arg,
            done: context.done
          };

        } else if (record.type === "throw") {
          state = GenStateCompleted;
          // Dispatch the exception by looping back around to the
          // context.dispatchException(context.arg) call above.
          context.method = "throw";
          context.arg = record.arg;
        }
      }
    };
  }

  // Call delegate.iterator[context.method](context.arg) and handle the
  // result, either by returning a { value, done } result from the
  // delegate iterator, or by modifying context.method and context.arg,
  // setting context.delegate to null, and returning the ContinueSentinel.
  function maybeInvokeDelegate(delegate, context) {
    var method = delegate.iterator[context.method];
    if (method === undefined) {
      // A .throw or .return when the delegate iterator has no .throw
      // method always terminates the yield* loop.
      context.delegate = null;

      if (context.method === "throw") {
        if (delegate.iterator.return) {
          // If the delegate iterator has a return method, give it a
          // chance to clean up.
          context.method = "return";
          context.arg = undefined;
          maybeInvokeDelegate(delegate, context);

          if (context.method === "throw") {
            // If maybeInvokeDelegate(context) changed context.method from
            // "return" to "throw", let that override the TypeError below.
            return ContinueSentinel;
          }
        }

        context.method = "throw";
        context.arg = new TypeError(
          "The iterator does not provide a 'throw' method");
      }

      return ContinueSentinel;
    }

    var record = tryCatch(method, delegate.iterator, context.arg);

    if (record.type === "throw") {
      context.method = "throw";
      context.arg = record.arg;
      context.delegate = null;
      return ContinueSentinel;
    }

    var info = record.arg;

    if (! info) {
      context.method = "throw";
      context.arg = new TypeError("iterator result is not an object");
      context.delegate = null;
      return ContinueSentinel;
    }

    if (info.done) {
      // Assign the result of the finished delegate to the temporary
      // variable specified by delegate.resultName (see delegateYield).
      context[delegate.resultName] = info.value;

      // Resume execution at the desired location (see delegateYield).
      context.next = delegate.nextLoc;

      // If context.method was "throw" but the delegate handled the
      // exception, let the outer generator proceed normally. If
      // context.method was "next", forget context.arg since it has been
      // "consumed" by the delegate iterator. If context.method was
      // "return", allow the original .return call to continue in the
      // outer generator.
      if (context.method !== "return") {
        context.method = "next";
        context.arg = undefined;
      }

    } else {
      // Re-yield the result returned by the delegate method.
      return info;
    }

    // The delegate iterator is finished, so forget it and continue with
    // the outer generator.
    context.delegate = null;
    return ContinueSentinel;
  }

  // Define Generator.prototype.{next,throw,return} in terms of the
  // unified ._invoke helper method.
  defineIteratorMethods(Gp);

  Gp[toStringTagSymbol] = "Generator";

  // A Generator should always return itself as the iterator object when the
  // @@iterator function is called on it. Some browsers' implementations of the
  // iterator prototype chain incorrectly implement this, causing the Generator
  // object to not be returned from this call. This ensures that doesn't happen.
  // See https://github.com/facebook/regenerator/issues/274 for more details.
  Gp[iteratorSymbol] = function() {
    return this;
  };

  Gp.toString = function() {
    return "[object Generator]";
  };

  function pushTryEntry(locs) {
    var entry = { tryLoc: locs[0] };

    if (1 in locs) {
      entry.catchLoc = locs[1];
    }

    if (2 in locs) {
      entry.finallyLoc = locs[2];
      entry.afterLoc = locs[3];
    }

    this.tryEntries.push(entry);
  }

  function resetTryEntry(entry) {
    var record = entry.completion || {};
    record.type = "normal";
    delete record.arg;
    entry.completion = record;
  }

  function Context(tryLocsList) {
    // The root entry object (effectively a try statement without a catch
    // or a finally block) gives us a place to store values thrown from
    // locations where there is no enclosing try statement.
    this.tryEntries = [{ tryLoc: "root" }];
    tryLocsList.forEach(pushTryEntry, this);
    this.reset(true);
  }

  runtime.keys = function(object) {
    var keys = [];
    for (var key in object) {
      keys.push(key);
    }
    keys.reverse();

    // Rather than returning an object with a next method, we keep
    // things simple and return the next function itself.
    return function next() {
      while (keys.length) {
        var key = keys.pop();
        if (key in object) {
          next.value = key;
          next.done = false;
          return next;
        }
      }

      // To avoid creating an additional object, we just hang the .value
      // and .done properties off the next function object itself. This
      // also ensures that the minifier will not anonymize the function.
      next.done = true;
      return next;
    };
  };

  function values(iterable) {
    if (iterable) {
      var iteratorMethod = iterable[iteratorSymbol];
      if (iteratorMethod) {
        return iteratorMethod.call(iterable);
      }

      if (typeof iterable.next === "function") {
        return iterable;
      }

      if (!isNaN(iterable.length)) {
        var i = -1, next = function next() {
          while (++i < iterable.length) {
            if (hasOwn.call(iterable, i)) {
              next.value = iterable[i];
              next.done = false;
              return next;
            }
          }

          next.value = undefined;
          next.done = true;

          return next;
        };

        return next.next = next;
      }
    }

    // Return an iterator with no values.
    return { next: doneResult };
  }
  runtime.values = values;

  function doneResult() {
    return { value: undefined, done: true };
  }

  Context.prototype = {
    constructor: Context,

    reset: function(skipTempReset) {
      this.prev = 0;
      this.next = 0;
      // Resetting context._sent for legacy support of Babel's
      // function.sent implementation.
      this.sent = this._sent = undefined;
      this.done = false;
      this.delegate = null;

      this.method = "next";
      this.arg = undefined;

      this.tryEntries.forEach(resetTryEntry);

      if (!skipTempReset) {
        for (var name in this) {
          // Not sure about the optimal order of these conditions:
          if (name.charAt(0) === "t" &&
              hasOwn.call(this, name) &&
              !isNaN(+name.slice(1))) {
            this[name] = undefined;
          }
        }
      }
    },

    stop: function() {
      this.done = true;

      var rootEntry = this.tryEntries[0];
      var rootRecord = rootEntry.completion;
      if (rootRecord.type === "throw") {
        throw rootRecord.arg;
      }

      return this.rval;
    },

    dispatchException: function(exception) {
      if (this.done) {
        throw exception;
      }

      var context = this;
      function handle(loc, caught) {
        record.type = "throw";
        record.arg = exception;
        context.next = loc;

        if (caught) {
          // If the dispatched exception was caught by a catch block,
          // then let that catch block handle the exception normally.
          context.method = "next";
          context.arg = undefined;
        }

        return !! caught;
      }

      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        var record = entry.completion;

        if (entry.tryLoc === "root") {
          // Exception thrown outside of any try block that could handle
          // it, so set the completion value of the entire function to
          // throw the exception.
          return handle("end");
        }

        if (entry.tryLoc <= this.prev) {
          var hasCatch = hasOwn.call(entry, "catchLoc");
          var hasFinally = hasOwn.call(entry, "finallyLoc");

          if (hasCatch && hasFinally) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            } else if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else if (hasCatch) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            }

          } else if (hasFinally) {
            if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else {
            throw new Error("try statement without catch or finally");
          }
        }
      }
    },

    abrupt: function(type, arg) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc <= this.prev &&
            hasOwn.call(entry, "finallyLoc") &&
            this.prev < entry.finallyLoc) {
          var finallyEntry = entry;
          break;
        }
      }

      if (finallyEntry &&
          (type === "break" ||
           type === "continue") &&
          finallyEntry.tryLoc <= arg &&
          arg <= finallyEntry.finallyLoc) {
        // Ignore the finally entry if control is not jumping to a
        // location outside the try/catch block.
        finallyEntry = null;
      }

      var record = finallyEntry ? finallyEntry.completion : {};
      record.type = type;
      record.arg = arg;

      if (finallyEntry) {
        this.method = "next";
        this.next = finallyEntry.finallyLoc;
        return ContinueSentinel;
      }

      return this.complete(record);
    },

    complete: function(record, afterLoc) {
      if (record.type === "throw") {
        throw record.arg;
      }

      if (record.type === "break" ||
          record.type === "continue") {
        this.next = record.arg;
      } else if (record.type === "return") {
        this.rval = this.arg = record.arg;
        this.method = "return";
        this.next = "end";
      } else if (record.type === "normal" && afterLoc) {
        this.next = afterLoc;
      }

      return ContinueSentinel;
    },

    finish: function(finallyLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.finallyLoc === finallyLoc) {
          this.complete(entry.completion, entry.afterLoc);
          resetTryEntry(entry);
          return ContinueSentinel;
        }
      }
    },

    "catch": function(tryLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc === tryLoc) {
          var record = entry.completion;
          if (record.type === "throw") {
            var thrown = record.arg;
            resetTryEntry(entry);
          }
          return thrown;
        }
      }

      // The context.catch method must only be called with a location
      // argument that corresponds to a known catch block.
      throw new Error("illegal catch attempt");
    },

    delegateYield: function(iterable, resultName, nextLoc) {
      this.delegate = {
        iterator: values(iterable),
        resultName: resultName,
        nextLoc: nextLoc
      };

      if (this.method === "next") {
        // Deliberately forget the last sent value so that we don't
        // accidentally pass it on to the delegate.
        this.arg = undefined;
      }

      return ContinueSentinel;
    }
  };
})(
  // In sloppy mode, unbound `this` refers to the global object, fallback to
  // Function constructor if we're in global strict mode. That is sadly a form
  // of indirect eval which violates Content Security Policy.
  (function() { return this })() || Function("return this")()
);


/***/ }),
/* 88 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(89);
__webpack_require__(67);
__webpack_require__(90);
__webpack_require__(94);
__webpack_require__(102);
__webpack_require__(103);
module.exports = __webpack_require__(5).Promise;


/***/ }),
/* 89 */
/***/ (function(module, exports) {



/***/ }),
/* 90 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(91);
var global = __webpack_require__(2);
var hide = __webpack_require__(11);
var Iterators = __webpack_require__(16);
var TO_STRING_TAG = __webpack_require__(4)('toStringTag');

var DOMIterables = ('CSSRuleList,CSSStyleDeclaration,CSSValueList,ClientRectList,DOMRectList,DOMStringList,' +
  'DOMTokenList,DataTransferItemList,FileList,HTMLAllCollection,HTMLCollection,HTMLFormElement,HTMLSelectElement,' +
  'MediaList,MimeTypeArray,NamedNodeMap,NodeList,PaintRequestList,Plugin,PluginArray,SVGLengthList,SVGNumberList,' +
  'SVGPathSegList,SVGPointList,SVGStringList,SVGTransformList,SourceBufferList,StyleSheetList,TextTrackCueList,' +
  'TextTrackList,TouchList').split(',');

for (var i = 0; i < DOMIterables.length; i++) {
  var NAME = DOMIterables[i];
  var Collection = global[NAME];
  var proto = Collection && Collection.prototype;
  if (proto && !proto[TO_STRING_TAG]) hide(proto, TO_STRING_TAG, NAME);
  Iterators[NAME] = Iterators.Array;
}


/***/ }),
/* 91 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var addToUnscopables = __webpack_require__(92);
var step = __webpack_require__(93);
var Iterators = __webpack_require__(16);
var toIObject = __webpack_require__(29);

// 22.1.3.4 Array.prototype.entries()
// 22.1.3.13 Array.prototype.keys()
// 22.1.3.29 Array.prototype.values()
// 22.1.3.30 Array.prototype[@@iterator]()
module.exports = __webpack_require__(51)(Array, 'Array', function (iterated, kind) {
  this._t = toIObject(iterated); // target
  this._i = 0;                   // next index
  this._k = kind;                // kind
// 22.1.5.2.1 %ArrayIteratorPrototype%.next()
}, function () {
  var O = this._t;
  var kind = this._k;
  var index = this._i++;
  if (!O || index >= O.length) {
    this._t = undefined;
    return step(1);
  }
  if (kind == 'keys') return step(0, index);
  if (kind == 'values') return step(0, O[index]);
  return step(0, [index, O[index]]);
}, 'values');

// argumentsList[@@iterator] is %ArrayProto_values% (9.4.4.6, 9.4.4.7)
Iterators.Arguments = Iterators.Array;

addToUnscopables('keys');
addToUnscopables('values');
addToUnscopables('entries');


/***/ }),
/* 92 */
/***/ (function(module, exports) {

module.exports = function () { /* empty */ };


/***/ }),
/* 93 */
/***/ (function(module, exports) {

module.exports = function (done, value) {
  return { value: value, done: !!done };
};


/***/ }),
/* 94 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var LIBRARY = __webpack_require__(32);
var global = __webpack_require__(2);
var ctx = __webpack_require__(18);
var classof = __webpack_require__(53);
var $export = __webpack_require__(14);
var isObject = __webpack_require__(15);
var aFunction = __webpack_require__(22);
var anInstance = __webpack_require__(95);
var forOf = __webpack_require__(96);
var speciesConstructor = __webpack_require__(54);
var task = __webpack_require__(55).set;
var microtask = __webpack_require__(98)();
var newPromiseCapabilityModule = __webpack_require__(35);
var perform = __webpack_require__(56);
var userAgent = __webpack_require__(99);
var promiseResolve = __webpack_require__(57);
var PROMISE = 'Promise';
var TypeError = global.TypeError;
var process = global.process;
var versions = process && process.versions;
var v8 = versions && versions.v8 || '';
var $Promise = global[PROMISE];
var isNode = classof(process) == 'process';
var empty = function () { /* empty */ };
var Internal, newGenericPromiseCapability, OwnPromiseCapability, Wrapper;
var newPromiseCapability = newGenericPromiseCapability = newPromiseCapabilityModule.f;

var USE_NATIVE = !!function () {
  try {
    // correct subclassing with @@species support
    var promise = $Promise.resolve(1);
    var FakePromise = (promise.constructor = {})[__webpack_require__(4)('species')] = function (exec) {
      exec(empty, empty);
    };
    // unhandled rejections tracking support, NodeJS Promise without it fails @@species test
    return (isNode || typeof PromiseRejectionEvent == 'function')
      && promise.then(empty) instanceof FakePromise
      // v8 6.6 (Node 10 and Chrome 66) have a bug with resolving custom thenables
      // https://bugs.chromium.org/p/chromium/issues/detail?id=830565
      // we can't detect it synchronously, so just check versions
      && v8.indexOf('6.6') !== 0
      && userAgent.indexOf('Chrome/66') === -1;
  } catch (e) { /* empty */ }
}();

// helpers
var isThenable = function (it) {
  var then;
  return isObject(it) && typeof (then = it.then) == 'function' ? then : false;
};
var notify = function (promise, isReject) {
  if (promise._n) return;
  promise._n = true;
  var chain = promise._c;
  microtask(function () {
    var value = promise._v;
    var ok = promise._s == 1;
    var i = 0;
    var run = function (reaction) {
      var handler = ok ? reaction.ok : reaction.fail;
      var resolve = reaction.resolve;
      var reject = reaction.reject;
      var domain = reaction.domain;
      var result, then, exited;
      try {
        if (handler) {
          if (!ok) {
            if (promise._h == 2) onHandleUnhandled(promise);
            promise._h = 1;
          }
          if (handler === true) result = value;
          else {
            if (domain) domain.enter();
            result = handler(value); // may throw
            if (domain) {
              domain.exit();
              exited = true;
            }
          }
          if (result === reaction.promise) {
            reject(TypeError('Promise-chain cycle'));
          } else if (then = isThenable(result)) {
            then.call(result, resolve, reject);
          } else resolve(result);
        } else reject(value);
      } catch (e) {
        if (domain && !exited) domain.exit();
        reject(e);
      }
    };
    while (chain.length > i) run(chain[i++]); // variable length - can't use forEach
    promise._c = [];
    promise._n = false;
    if (isReject && !promise._h) onUnhandled(promise);
  });
};
var onUnhandled = function (promise) {
  task.call(global, function () {
    var value = promise._v;
    var unhandled = isUnhandled(promise);
    var result, handler, console;
    if (unhandled) {
      result = perform(function () {
        if (isNode) {
          process.emit('unhandledRejection', value, promise);
        } else if (handler = global.onunhandledrejection) {
          handler({ promise: promise, reason: value });
        } else if ((console = global.console) && console.error) {
          console.error('Unhandled promise rejection', value);
        }
      });
      // Browsers should not trigger `rejectionHandled` event if it was handled here, NodeJS - should
      promise._h = isNode || isUnhandled(promise) ? 2 : 1;
    } promise._a = undefined;
    if (unhandled && result.e) throw result.v;
  });
};
var isUnhandled = function (promise) {
  return promise._h !== 1 && (promise._a || promise._c).length === 0;
};
var onHandleUnhandled = function (promise) {
  task.call(global, function () {
    var handler;
    if (isNode) {
      process.emit('rejectionHandled', promise);
    } else if (handler = global.onrejectionhandled) {
      handler({ promise: promise, reason: promise._v });
    }
  });
};
var $reject = function (value) {
  var promise = this;
  if (promise._d) return;
  promise._d = true;
  promise = promise._w || promise; // unwrap
  promise._v = value;
  promise._s = 2;
  if (!promise._a) promise._a = promise._c.slice();
  notify(promise, true);
};
var $resolve = function (value) {
  var promise = this;
  var then;
  if (promise._d) return;
  promise._d = true;
  promise = promise._w || promise; // unwrap
  try {
    if (promise === value) throw TypeError("Promise can't be resolved itself");
    if (then = isThenable(value)) {
      microtask(function () {
        var wrapper = { _w: promise, _d: false }; // wrap
        try {
          then.call(value, ctx($resolve, wrapper, 1), ctx($reject, wrapper, 1));
        } catch (e) {
          $reject.call(wrapper, e);
        }
      });
    } else {
      promise._v = value;
      promise._s = 1;
      notify(promise, false);
    }
  } catch (e) {
    $reject.call({ _w: promise, _d: false }, e); // wrap
  }
};

// constructor polyfill
if (!USE_NATIVE) {
  // 25.4.3.1 Promise(executor)
  $Promise = function Promise(executor) {
    anInstance(this, $Promise, PROMISE, '_h');
    aFunction(executor);
    Internal.call(this);
    try {
      executor(ctx($resolve, this, 1), ctx($reject, this, 1));
    } catch (err) {
      $reject.call(this, err);
    }
  };
  // eslint-disable-next-line no-unused-vars
  Internal = function Promise(executor) {
    this._c = [];             // <- awaiting reactions
    this._a = undefined;      // <- checked in isUnhandled reactions
    this._s = 0;              // <- state
    this._d = false;          // <- done
    this._v = undefined;      // <- value
    this._h = 0;              // <- rejection state, 0 - default, 1 - handled, 2 - unhandled
    this._n = false;          // <- notify
  };
  Internal.prototype = __webpack_require__(100)($Promise.prototype, {
    // 25.4.5.3 Promise.prototype.then(onFulfilled, onRejected)
    then: function then(onFulfilled, onRejected) {
      var reaction = newPromiseCapability(speciesConstructor(this, $Promise));
      reaction.ok = typeof onFulfilled == 'function' ? onFulfilled : true;
      reaction.fail = typeof onRejected == 'function' && onRejected;
      reaction.domain = isNode ? process.domain : undefined;
      this._c.push(reaction);
      if (this._a) this._a.push(reaction);
      if (this._s) notify(this, false);
      return reaction.promise;
    },
    // 25.4.5.1 Promise.prototype.catch(onRejected)
    'catch': function (onRejected) {
      return this.then(undefined, onRejected);
    }
  });
  OwnPromiseCapability = function () {
    var promise = new Internal();
    this.promise = promise;
    this.resolve = ctx($resolve, promise, 1);
    this.reject = ctx($reject, promise, 1);
  };
  newPromiseCapabilityModule.f = newPromiseCapability = function (C) {
    return C === $Promise || C === Wrapper
      ? new OwnPromiseCapability(C)
      : newGenericPromiseCapability(C);
  };
}

$export($export.G + $export.W + $export.F * !USE_NATIVE, { Promise: $Promise });
__webpack_require__(34)($Promise, PROMISE);
__webpack_require__(101)(PROMISE);
Wrapper = __webpack_require__(5)[PROMISE];

// statics
$export($export.S + $export.F * !USE_NATIVE, PROMISE, {
  // 25.4.4.5 Promise.reject(r)
  reject: function reject(r) {
    var capability = newPromiseCapability(this);
    var $$reject = capability.reject;
    $$reject(r);
    return capability.promise;
  }
});
$export($export.S + $export.F * (LIBRARY || !USE_NATIVE), PROMISE, {
  // 25.4.4.6 Promise.resolve(x)
  resolve: function resolve(x) {
    return promiseResolve(LIBRARY && this === Wrapper ? $Promise : this, x);
  }
});
$export($export.S + $export.F * !(USE_NATIVE && __webpack_require__(71)(function (iter) {
  $Promise.all(iter)['catch'](empty);
})), PROMISE, {
  // 25.4.4.1 Promise.all(iterable)
  all: function all(iterable) {
    var C = this;
    var capability = newPromiseCapability(C);
    var resolve = capability.resolve;
    var reject = capability.reject;
    var result = perform(function () {
      var values = [];
      var index = 0;
      var remaining = 1;
      forOf(iterable, false, function (promise) {
        var $index = index++;
        var alreadyCalled = false;
        values.push(undefined);
        remaining++;
        C.resolve(promise).then(function (value) {
          if (alreadyCalled) return;
          alreadyCalled = true;
          values[$index] = value;
          --remaining || resolve(values);
        }, reject);
      });
      --remaining || resolve(values);
    });
    if (result.e) reject(result.v);
    return capability.promise;
  },
  // 25.4.4.4 Promise.race(iterable)
  race: function race(iterable) {
    var C = this;
    var capability = newPromiseCapability(C);
    var reject = capability.reject;
    var result = perform(function () {
      forOf(iterable, false, function (promise) {
        C.resolve(promise).then(capability.resolve, reject);
      });
    });
    if (result.e) reject(result.v);
    return capability.promise;
  }
});


/***/ }),
/* 95 */
/***/ (function(module, exports) {

module.exports = function (it, Constructor, name, forbiddenField) {
  if (!(it instanceof Constructor) || (forbiddenField !== undefined && forbiddenField in it)) {
    throw TypeError(name + ': incorrect invocation!');
  } return it;
};


/***/ }),
/* 96 */
/***/ (function(module, exports, __webpack_require__) {

var ctx = __webpack_require__(18);
var call = __webpack_require__(68);
var isArrayIter = __webpack_require__(69);
var anObject = __webpack_require__(9);
var toLength = __webpack_require__(41);
var getIterFn = __webpack_require__(70);
var BREAK = {};
var RETURN = {};
var exports = module.exports = function (iterable, entries, fn, that, ITERATOR) {
  var iterFn = ITERATOR ? function () { return iterable; } : getIterFn(iterable);
  var f = ctx(fn, that, entries ? 2 : 1);
  var index = 0;
  var length, step, iterator, result;
  if (typeof iterFn != 'function') throw TypeError(iterable + ' is not iterable!');
  // fast case for arrays with default iterator
  if (isArrayIter(iterFn)) for (length = toLength(iterable.length); length > index; index++) {
    result = entries ? f(anObject(step = iterable[index])[0], step[1]) : f(iterable[index]);
    if (result === BREAK || result === RETURN) return result;
  } else for (iterator = iterFn.call(iterable); !(step = iterator.next()).done;) {
    result = call(iterator, f, step.value, entries);
    if (result === BREAK || result === RETURN) return result;
  }
};
exports.BREAK = BREAK;
exports.RETURN = RETURN;


/***/ }),
/* 97 */
/***/ (function(module, exports) {

// fast apply, http://jsperf.lnkit.com/fast-apply/5
module.exports = function (fn, args, that) {
  var un = that === undefined;
  switch (args.length) {
    case 0: return un ? fn()
                      : fn.call(that);
    case 1: return un ? fn(args[0])
                      : fn.call(that, args[0]);
    case 2: return un ? fn(args[0], args[1])
                      : fn.call(that, args[0], args[1]);
    case 3: return un ? fn(args[0], args[1], args[2])
                      : fn.call(that, args[0], args[1], args[2]);
    case 4: return un ? fn(args[0], args[1], args[2], args[3])
                      : fn.call(that, args[0], args[1], args[2], args[3]);
  } return fn.apply(that, args);
};


/***/ }),
/* 98 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(2);
var macrotask = __webpack_require__(55).set;
var Observer = global.MutationObserver || global.WebKitMutationObserver;
var process = global.process;
var Promise = global.Promise;
var isNode = __webpack_require__(21)(process) == 'process';

module.exports = function () {
  var head, last, notify;

  var flush = function () {
    var parent, fn;
    if (isNode && (parent = process.domain)) parent.exit();
    while (head) {
      fn = head.fn;
      head = head.next;
      try {
        fn();
      } catch (e) {
        if (head) notify();
        else last = undefined;
        throw e;
      }
    } last = undefined;
    if (parent) parent.enter();
  };

  // Node.js
  if (isNode) {
    notify = function () {
      process.nextTick(flush);
    };
  // browsers with MutationObserver, except iOS Safari - https://github.com/zloirock/core-js/issues/339
  } else if (Observer && !(global.navigator && global.navigator.standalone)) {
    var toggle = true;
    var node = document.createTextNode('');
    new Observer(flush).observe(node, { characterData: true }); // eslint-disable-line no-new
    notify = function () {
      node.data = toggle = !toggle;
    };
  // environments with maybe non-completely correct, but existent Promise
  } else if (Promise && Promise.resolve) {
    // Promise.resolve without an argument throws an error in LG WebOS 2
    var promise = Promise.resolve(undefined);
    notify = function () {
      promise.then(flush);
    };
  // for other environments - macrotask based on:
  // - setImmediate
  // - MessageChannel
  // - window.postMessag
  // - onreadystatechange
  // - setTimeout
  } else {
    notify = function () {
      // strange IE + webpack dev server bug - use .call(global)
      macrotask.call(global, flush);
    };
  }

  return function (fn) {
    var task = { fn: fn, next: undefined };
    if (last) last.next = task;
    if (!head) {
      head = task;
      notify();
    } last = task;
  };
};


/***/ }),
/* 99 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(2);
var navigator = global.navigator;

module.exports = navigator && navigator.userAgent || '';


/***/ }),
/* 100 */
/***/ (function(module, exports, __webpack_require__) {

var hide = __webpack_require__(11);
module.exports = function (target, src, safe) {
  for (var key in src) {
    if (safe && target[key]) target[key] = src[key];
    else hide(target, key, src[key]);
  } return target;
};


/***/ }),
/* 101 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var global = __webpack_require__(2);
var core = __webpack_require__(5);
var dP = __webpack_require__(17);
var DESCRIPTORS = __webpack_require__(13);
var SPECIES = __webpack_require__(4)('species');

module.exports = function (KEY) {
  var C = typeof core[KEY] == 'function' ? core[KEY] : global[KEY];
  if (DESCRIPTORS && C && !C[SPECIES]) dP.f(C, SPECIES, {
    configurable: true,
    get: function () { return this; }
  });
};


/***/ }),
/* 102 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// https://github.com/tc39/proposal-promise-finally

var $export = __webpack_require__(14);
var core = __webpack_require__(5);
var global = __webpack_require__(2);
var speciesConstructor = __webpack_require__(54);
var promiseResolve = __webpack_require__(57);

$export($export.P + $export.R, 'Promise', { 'finally': function (onFinally) {
  var C = speciesConstructor(this, core.Promise || global.Promise);
  var isFunction = typeof onFinally == 'function';
  return this.then(
    isFunction ? function (x) {
      return promiseResolve(C, onFinally()).then(function () { return x; });
    } : onFinally,
    isFunction ? function (e) {
      return promiseResolve(C, onFinally()).then(function () { throw e; });
    } : onFinally
  );
} });


/***/ }),
/* 103 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://github.com/tc39/proposal-promise-try
var $export = __webpack_require__(14);
var newPromiseCapability = __webpack_require__(35);
var perform = __webpack_require__(56);

$export($export.S, 'Promise', { 'try': function (callbackfn) {
  var promiseCapability = newPromiseCapability.f(this);
  var result = perform(callbackfn);
  (result.e ? promiseCapability.reject : promiseCapability.resolve)(result.v);
  return promiseCapability.promise;
} });


/***/ }),
/* 104 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getLocalVersion = exports.currentVersion = exports.localVersion = exports.waitDo = exports.waitforbackground = exports.imageready = exports.waitFor = exports.notneedcontinue = exports.div2base64 = exports.delay = exports.captchaClassification = exports.messageHide = exports.message = undefined;

var _promise = __webpack_require__(45);

var _promise2 = _interopRequireDefault(_promise);

var _regenerator = __webpack_require__(43);

var _regenerator2 = _interopRequireDefault(_regenerator);

var _asyncToGenerator2 = __webpack_require__(44);

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

exports.testnetwork = testnetwork;
exports.post = post;
exports.getBalance = getBalance;
exports.getconfig = getconfig;
exports.setconfig = setconfig;
exports.getParentUrl = getParentUrl;

var _config = __webpack_require__(72);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var chrome = window.chrome;

// 设置页面信息显示和隐藏
// 为替换pc客户端实现一个同样的接口的对象，这样就不用改之前的captcha.js的代码了
// 测试key  a2000da995ef93962df8a4f6d200004b1fdd4c943
// 需实现的接口
// 1.onopen  启动时调用
// 2.onclose 关闭时调用
// 3.onmessage 接收到消息时调用
// 4.send 方法发送消息
// onmessage  时需返回 json字符串+"##" 作为结束标志
// 返回对象需要有 type 属性 10,表示是否开启自动识别,2表示结果,
// import axios from 'axios'
// 服务器版本信息
var message = exports.message = function message(_ref) {
  var _ref$text = _ref.text,
      text = _ref$text === undefined ? '' : _ref$text,
      _ref$color = _ref.color,
      color = _ref$color === undefined ? 'red' : _ref$color;

  var message = document.getElementById('mymessage');
  if (!message) {
    message = document.createElement('div');
    message.id = 'mymessage';

    // message.className = 'fankui'
    message.style.position = 'fixed';
    message.style.top = '0px';
    message.style.left = '0px';

    // message.style.width = '100%'
    // message.style.height = '100%'
    message.style.zIndex = '99999999';
    // // message.style.backgroundColor = 'rgba(0,0,0,0.5)'
    // message.style.border = '1px solid red'
    // message.style.textAlign = 'left'
    // message.style.lineHeight = '100%'
    // message.style.fontSize = '20px'
    message.innerText = text;
    document.body.appendChild(message);
  } else {
    message.innerText = text;
  }
  color === 'green' ? message.className = 'fankui' : message.className = 'fankui2';
  message.style.display = 'block';
  // message.style.color = color === 'green' ? 'red' : 'green'
};

// 设置页面信息显示和隐藏
var messageHide = exports.messageHide = function messageHide() {
  var message = document.getElementById('mymessage');
  if (message) {
    message.style.display = 'none';
  }
};

// 定义页面识别方法
var captchaClassification = exports.captchaClassification = function () {
  var _ref2 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee() {
    var result, typelist, i;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return delay(1000);

          case 2:
            result = null;
            // 对不同页面判断的定义 title 表示使用的接口，url_keywork 为url中的关键字,div 为判断是否这个页面

            typelist = [{
              title: 'imageclassification',
              url_keyword: 'recaptcha',
              div: '#recaptcha-anchor-label',
              imagediv: '#recaptcha-token' // 图片的div 和点击的框架为两个不同的框架

            }, {
              title: 'hcaptcha',
              url_keyword: 'hcaptcha.com',
              div: '#anchor-state',
              imagediv: '.challenge-container' // hcaptcha 图片的div 和点击的框架为两个不同的框架
            }, {
              title: 'rainbow',
              // assets-us-west-2.queue-it.net
              // assets-us-west-2.queue-it.net
              url_keyword: 'queue-it.net',
              div: '#enqueue-error > a:nth-child(3) > div > strong'
            }, {
              title: 'imagetotext',
              url_keyword: 'queue',
              // div: '#challenge-container > button'
              div: '#lbHeaderP'
            }];
            i = 0;

          case 5:
            if (!(i < typelist.length)) {
              _context.next = 12;
              break;
            }

            if (!(window.location.href.indexOf(typelist[i].url_keyword) > -1 && (document.querySelector(typelist[i].div) || typelist[i].imagediv && document.querySelector(typelist[i].imagediv)))) {
              _context.next = 9;
              break;
            }

            result = typelist[i];

            return _context.abrupt('break', 12);

          case 9:
            i++;
            _context.next = 5;
            break;

          case 12:
            return _context.abrupt('return', result);

          case 13:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, undefined);
  }));

  return function captchaClassification() {
    return _ref2.apply(this, arguments);
  };
}();

// 网络测试
function testnetwork(url) {
  return new _promise2.default(function (resolve, reject) {
    if (window.self === window.top) {
      chrome.runtime.sendMessage({ action: 'testnetwork', url: url }, function (response) {
        resolve(response);
      });
    } else {
      resolve(true);
    }
  });
}

// post 请求代理
function post(url, data) {
  return new _promise2.default(function (resolve, reject) {
    chrome.runtime.sendMessage({ action: 'post', url: url, data: data }, function (response) {
      resolve(response);
    });
  });
}

// 获取余额
function getBalance(_ref3) {
  var host = _ref3.host,
      clientKey = _ref3.clientKey;

  return post(host + '/getBalance', {
    clientKey: clientKey
  });
}
var delay = exports.delay = function delay(s) {
  return new _promise2.default(function (resolve) {
    setTimeout(resolve, s);
  });
};

function getconfig() {
  return new _promise2.default(function (resolve, reject) {
    chrome.runtime.sendMessage({ action: 'getconfig' }, function (response) {
      resolve(response);
    });
  });
}
function setconfig(config) {
  return new _promise2.default(function (resolve, reject) {
    chrome.runtime.sendMessage({ action: 'setconfig', config: config }, function (response) {
      resolve(response);
    });
  });
}

var div2base64 = exports.div2base64 = function div2base64(src) {
  var width = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 128;
  var height = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 128;

  return new _promise2.default(function (resolve, reject) {
    if (!src) resolve(null);
    var img = new Image();
    img.setAttribute('crossOrigin', 'Anonymous');
    img.src = src;
    img.width = width;
    img.height = height;
    var canvas = document.createElement('canvas');
    var context = canvas.getContext('2d');
    canvas.width = img.width;
    canvas.height = img.height;
    img.onload = function () {
      // 图片加载完，再draw 和 toDataURL
      context.drawImage(img, 0, 0, width, height);
      var base64 = canvas.toDataURL();
      // console.log('base64', base64)
      var out = base64.replace('data:image/png;base64,', '');

      resolve(out);
    };
  });
};

function getParentUrl() {
  var url = null;
  if (parent !== window) {
    try {
      url = parent.location.href;
    } catch (e) {
      url = document.referrer;
    }
  }
  return url;
};

// 无需返回的错误码
var notneedcontinue = exports.notneedcontinue = function notneedcontinue(errorstr) {
  return errorstr && 'ERROR_REQUIRED_FIELDS\n  ERROR_KEY_DOES_NOT_EXIST\n  ERROR_ZERO_BALANCE\n  ERROR_ZERO_CAPTCHA_FILESIZE\n  ERROR_DOMAIN_NOT_ALLOWED\n  ERROR_TOO_BIG_CAPTCHA_FILESIZE\n  ERROR_ILLEGAL_IMAGE\n  ERROR_IP_BANNED\n  ERROR_IP_BLOCKED_5MIN\n  ERROR_CLIENTKEY_UNAUTHORIZED'.includes(errorstr);
};
// 等待dom元素存在,超时 默认10秒
var waitFor = exports.waitFor = function waitFor(divstr) {
  var outtime = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 10;

  return new _promise2.default(function (resolve, reject) {
    var timer = setInterval(function () {
      if (document.querySelector(divstr)) {
        clearInterval(timer);
        resolve(true);
      }
    }, 100);
    setTimeout(function () {
      clearInterval(timer);
      resolve(true);
    }, outtime * 1000);
  });
};
// 等待图像加载完
var imageready = exports.imageready = function imageready(imgsrc) {
  return new _promise2.default(function (resolve, reject) {
    var img = new Image();
    img.src = imgsrc;
    img.onload = function () {
      resolve(true);
    };
  });
};
// 等待背景图片属性存在
var waitforbackground = exports.waitforbackground = function waitforbackground(div) {
  return new _promise2.default(function (resolve, reject) {
    var timer = setInterval(function () {
      if (div.style.background) {
        clearInterval(timer);
        resolve(true);
      }
    }, 100);
  });
};

// 等待func返回true,超时默认10秒
var waitDo = exports.waitDo = function waitDo(func) {
  var outtime = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 10;

  return new _promise2.default(function (resolve, reject) {
    var timer = setInterval(function () {
      if (func()) {
        console.log('func true');
        clearInterval(timer);
        resolve(true);
      }
    }, 100);
    setTimeout(function () {
      console.log('func false');
      clearInterval(timer);
      resolve(false);
    }, outtime * 1000);
  });
};

// 客户端获取版本号

function getLocalVersion() {
  return new _promise2.default(function (resolve) {
    chrome.runtime.sendMessage({
      getLocalVersion: true
    }, function (ver) {
      resolve(ver);
    });
  });
}

// 本地版本信息

function localVersion() {
  return localStorage.version ? localStorage.version : 1;
}
function currentVersion(url) {
  return new _promise2.default(function (resolve) {
    var XHR = null;
    XHR = new XMLHttpRequest();
    XHR.open('GET', url || _config.config.HOST + '/chrome/version.txt');
    XHR.onreadystatechange = function () {
      if (XHR.readyState === 4 && XHR.status === 200) {
        console.log('服务器版本', XHR.responseText);
        resolve(XHR.responseText);
      }
    };
    XHR.send();
  }).catch(function () {
    return _promise2.default.resolve(0);
  });
}

exports.localVersion = localVersion;
exports.currentVersion = currentVersion;
exports.getLocalVersion = getLocalVersion;

/***/ }),
/* 105 */,
/* 106 */,
/* 107 */,
/* 108 */,
/* 109 */,
/* 110 */,
/* 111 */,
/* 112 */,
/* 113 */,
/* 114 */,
/* 115 */,
/* 116 */,
/* 117 */,
/* 118 */,
/* 119 */,
/* 120 */,
/* 121 */,
/* 122 */,
/* 123 */,
/* 124 */,
/* 125 */,
/* 126 */,
/* 127 */,
/* 128 */,
/* 129 */,
/* 130 */,
/* 131 */,
/* 132 */,
/* 133 */,
/* 134 */,
/* 135 */,
/* 136 */,
/* 137 */,
/* 138 */,
/* 139 */,
/* 140 */,
/* 141 */,
/* 142 */,
/* 143 */,
/* 144 */,
/* 145 */,
/* 146 */,
/* 147 */,
/* 148 */,
/* 149 */,
/* 150 */,
/* 151 */,
/* 152 */,
/* 153 */,
/* 154 */,
/* 155 */,
/* 156 */,
/* 157 */,
/* 158 */,
/* 159 */,
/* 160 */,
/* 161 */,
/* 162 */,
/* 163 */,
/* 164 */,
/* 165 */,
/* 166 */,
/* 167 */,
/* 168 */,
/* 169 */,
/* 170 */,
/* 171 */,
/* 172 */,
/* 173 */,
/* 174 */,
/* 175 */,
/* 176 */,
/* 177 */,
/* 178 */,
/* 179 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _stringify = __webpack_require__(180);

var _stringify2 = _interopRequireDefault(_stringify);

var _keys = __webpack_require__(182);

var _keys2 = _interopRequireDefault(_keys);

var _from = __webpack_require__(186);

var _from2 = _interopRequireDefault(_from);

var _regenerator = __webpack_require__(43);

var _regenerator2 = _interopRequireDefault(_regenerator);

var _asyncToGenerator2 = __webpack_require__(44);

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

// hcaptcha处理流程
var hcaptcha = function () {
  var _ref2 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(config) {
    var data, imagelist, i, div, backgroundurl, url, base64img, res, _i;

    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            if (false) {
              _context2.next = 61;
              break;
            }

          case 1:
            if (document.querySelector('.prompt-text')) {
              _context2.next = 6;
              break;
            }

            _context2.next = 4;
            return (0, _common.delay)(1000);

          case 4:
            _context2.next = 1;
            break;

          case 6:
            // console.log('结束等待')
            // await delay(3000)// 等待5秒
            data = { // 构建请求参数
              'clientKey': config.clientKey,
              'task': {
                'type': 'HCaptchaClassification',
                'queries': [],
                question: document.querySelector('.prompt-text') ? document.querySelector('.prompt-text').innerText : ''
              }
            };
            _context2.next = 9;
            return (0, _common.waitFor)('.task-image .image');

          case 9:
            imagelist = (0, _from2.default)(document.querySelectorAll('.task-image .image')); // 获取图片列表

            console.log(imagelist);
            i = 0;

          case 12:
            if (!(i < imagelist.length)) {
              _context2.next = 27;
              break;
            }

            div = imagelist[i];
            _context2.next = 16;
            return (0, _common.waitforbackground)(div);

          case 16:
            // console.log(div)
            backgroundurl = div.style.background;
            url = backgroundurl.split('"')[1];
            // console.log('加载图像', url)

            _context2.next = 20;
            return (0, _common.imageready)(url);

          case 20:
            _context2.next = 22;
            return (0, _common.div2base64)(url);

          case 22:
            base64img = _context2.sent;

            data.task.queries.push(base64img);

          case 24:
            i++;
            _context2.next = 12;
            break;

          case 27:
            // 增加当前网页URL参数
            data.callurl = (0, _common.getParentUrl)();
            _context2.next = 30;
            return (0, _common.post)(config.host + '/createTask', data);

          case 30:
            res = _context2.sent;

            if (!res.errorDescription) {
              _context2.next = 37;
              break;
            }

            // 出错时显示出错信息然后跳过
            console.log('出错:', res.errorDescription);
            (0, _common.message)({ text: res.errorDescription, color: 'red' });

            if (!(0, _common.notneedcontinue)(res.errorCode)) {
              _context2.next = 37;
              break;
            }

            console.log('不需要继续,程序退出');
            return _context2.abrupt('break', 61);

          case 37:
            if (!res.solution) {
              _context2.next = 48;
              break;
            }

            _i = 0;

          case 39:
            if (!(_i < res.solution.objects.length)) {
              _context2.next = 48;
              break;
            }

            // 点图片
            console.log('client: ' + _i + res.solution.objects[_i]);

            if (!res.solution.objects[_i]) {
              _context2.next = 45;
              break;
            }

            _context2.next = 44;
            return (0, _common.delay)(100);

          case 44:
            imagelist[_i].click();

          case 45:
            _i++;
            _context2.next = 39;
            break;

          case 48:
            _context2.next = 50;
            return (0, _common.delay)(100);

          case 50:
            _context2.next = 52;
            return (0, _common.waitFor)('.button-submit');

          case 52:
            console.log('等待3秒点击提交');
            _context2.next = 55;
            return (0, _common.delay)(3000);

          case 55:

            //   点击提交按钮
            // if (count > 0) { await delay(2200) } else { count += 1 }
            document.querySelector('.button-submit') && document.querySelector('.button-submit').click();
            console.log('等待1秒判断是否有进行下一轮');
            _context2.next = 59;
            return (0, _common.delay)(1000);

          case 59:
            _context2.next = 0;
            break;

          case 61:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function hcaptcha(_x) {
    return _ref2.apply(this, arguments);
  };
}();

// 彩虹点击流程


var rainbow = function () {
  var _ref3 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee4() {
    var chrome;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            chrome = window.chrome;

            console.log(location.href, 'location.href');
            // await delay(3000)

          case 2:
            if (false) {
              _context4.next = 11;
              break;
            }

            _context4.next = 5;
            return (0, _common.waitFor)('strong');

          case 5:
            if (!(document.querySelector('strong') && document.getElementById('enqueue-error').style.display !== 'none')) {
              _context4.next = 9;
              break;
            }

            console.log('找到了按钮');
            chrome.runtime.sendMessage({ action: 'gettabs' }, function () {
              var _ref4 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(tabs) {
                var totaltabs;
                return _regenerator2.default.wrap(function _callee3$(_context3) {
                  while (1) {
                    switch (_context3.prev = _context3.next) {
                      case 0:
                        totaltabs = tabs.length;

                        document.querySelector('strong').click();
                        _context3.next = 4;
                        return (0, _common.delay)(2000);

                      case 4:
                        chrome.runtime.sendMessage({ action: 'gettabs' }, function (tabs) {
                          if (totaltabs === tabs.length) {
                            console.log('点击失败');
                            return;
                          }
                          console.log('点击成功');
                          chrome.runtime.sendMessage({ action: 'removetab' });
                        });

                      case 5:
                      case 'end':
                        return _context3.stop();
                    }
                  }
                }, _callee3, this);
              }));

              return function (_x2) {
                return _ref4.apply(this, arguments);
              };
            }());

            return _context4.abrupt('break', 11);

          case 9:
            _context4.next = 2;
            break;

          case 11:
            return _context4.abrupt('return', true);

          case 12:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function rainbow() {
    return _ref3.apply(this, arguments);
  };
}();

// 英文数字转文本流程


var imagetotext = function () {
  var _ref5 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(config) {
    var imgsrc, base64img, data, res;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            // await delay(2000)
            console.log('英文数字转文本');

          case 1:
            if (false) {
              _context5.next = 31;
              break;
            }

            if (document.querySelector('#solution') && document.querySelector('#solution').value) {
              location.reload();
            }
            console.log('等待加载图片');
            // await waitFor('#challenge-container > div > fieldset > div.botdetect-label > img')

          case 4:
            if (document.querySelector('#challenge-container > div > fieldset > div.botdetect-label > img')) {
              _context5.next = 9;
              break;
            }

            _context5.next = 7;
            return (0, _common.delay)(1000);

          case 7:
            _context5.next = 4;
            break;

          case 9:
            console.log('获取到图片');
            imgsrc = document.querySelector('#challenge-container > div > fieldset > div.botdetect-label > img').src;

            console.log('图片地址', imgsrc);
            _context5.next = 14;
            return (0, _common.div2base64)(imgsrc, 250, 50);

          case 14:
            base64img = _context5.sent;
            data = {
              'clientKey': config.clientKey,
              'task': {
                'type': 'ImageToTextTaskTest',
                'body': base64img
              }
            };
            _context5.next = 18;
            return (0, _common.post)(config.host + '/createTask', data);

          case 18:
            res = _context5.sent;

            if (!res.errorDescription) {
              _context5.next = 25;
              break;
            }

            // 出错时显示出错信息然后跳过
            console.log('出错:', res.errorDescription);
            (0, _common.message)({ text: res.errorDescription, color: 'red' });

            if (!(0, _common.notneedcontinue)(res.errorCode)) {
              _context5.next = 25;
              break;
            }

            console.log('不需要继续,程序退出');
            return _context5.abrupt('break', 31);

          case 25:
            console.log(res);
            if (res.solution && res.solution.text) {
              document.querySelector('#solution').value = res.solution.text;
              document.querySelector('.botdetect-button') && document.querySelector('.botdetect-button').click();
              console.log('点击提交按钮');
            }
            _context5.next = 29;
            return (0, _common.delay)(7000);

          case 29:
            _context5.next = 1;
            break;

          case 31:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this);
  }));

  return function imagetotext(_x3) {
    return _ref5.apply(this, arguments);
  };
}();

// 图像识别分类待完成
// 1. 传整图,2. 传单个图片,3,确定按钮


var imageclassification = function () {
  var _ref6 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(config) {
    var _this = this;

    var data, imgcache, _loop, _ret;

    return _regenerator2.default.wrap(function _callee6$(_context7) {
      while (1) {
        switch (_context7.prev = _context7.next) {
          case 0:
            _context7.next = 2;
            return (0, _common.waitFor)('#rc-imageselect > div.rc-imageselect-payload > div.rc-imageselect-instructions > div.rc-imageselect-desc-wrapper > div > strong');

          case 2:
            _context7.next = 4;
            return (0, _common.messageHide)();

          case 4:
            data = {
              'clientKey': config.clientKey,
              'task': {
                'type': 'ReCaptchaV2Classification',
                'image': null,
                'question': null
              }
            };
            imgcache = '';
            _loop = /*#__PURE__*/_regenerator2.default.mark(function _loop() {
              var questionstr, imgsrc, widthXheight, width, res, resultlist, i, replaceImages, j, src, _res;

              return _regenerator2.default.wrap(function _loop$(_context6) {
                while (1) {
                  switch (_context6.prev = _context6.next) {
                    case 0:
                      questionstr = document.querySelector('#rc-imageselect > div.rc-imageselect-payload > div.rc-imageselect-instructions > div.rc-imageselect-desc-wrapper > div > strong') && document.querySelector('#rc-imageselect > div.rc-imageselect-payload > div.rc-imageselect-instructions > div.rc-imageselect-desc-wrapper > div > strong').innerText.replace(/\s/g, '');

                      if (questionstr) {
                        _context6.next = 5;
                        break;
                      }

                      _context6.next = 4;
                      return (0, _common.delay)(50);

                    case 4:
                      return _context6.abrupt('return', 'continue');

                    case 5:
                      data.task.question = _jsonall.jsonall[questionstr];
                      imgsrc = document.querySelector('#rc-imageselect-target .rc-image-tile-wrapper').querySelector('img').src;
                      _context6.next = 9;
                      return (0, _common.imageready)(imgsrc);

                    case 9:
                      if (!(imgsrc === imgcache)) {
                        _context6.next = 13;
                        break;
                      }

                      _context6.next = 12;
                      return (0, _common.delay)(300);

                    case 12:
                      return _context6.abrupt('return', 'continue');

                    case 13:
                      imgcache = imgsrc;
                      widthXheight = document.querySelector('#rc-imageselect-target .rc-image-tile-wrapper').querySelector('img').attributes.class.value.match(/\d+/)[0]; // 宽度x高度

                      width = widthXheight === '44' ? 450 : 300;
                      _context6.next = 18;
                      return (0, _common.div2base64)(imgsrc, width, width);

                    case 18:
                      data.task.image = _context6.sent;

                      // 增加当前网页URL参数
                      data.callurl = (0, _common.getParentUrl)();
                      _context6.next = 22;
                      return (0, _common.post)(config.host + '/createTask', data);

                    case 22:
                      res = _context6.sent;

                      console.log(res);

                      if (!res.errorDescription) {
                        _context6.next = 33;
                        break;
                      }

                      // 出错时显示出错信息然后跳过
                      (0, _common.message)({ text: res.errorDescription, color: 'green' });

                      if (!(0, _common.notneedcontinue)(res.errorCode)) {
                        _context6.next = 29;
                        break;
                      }

                      console.log('不需要继续');
                      return _context6.abrupt('return', 'break');

                    case 29:
                      _context6.next = 31;
                      return (0, _common.delay)(300);

                    case 31:
                      document.querySelector('.rc-button-reload') && document.querySelector('.rc-button-reload').click(); // 点击刷新按钮
                      return _context6.abrupt('return', 'continue');

                    case 33:
                      resultlist = (0, _from2.default)(document.querySelectorAll('.rc-image-tile-target'));

                      console.log('图片节点列表', resultlist);
                      res.solution.objects.forEach(function (item, index) {
                        resultlist[item] && resultlist[item].click();
                      });
                      _context6.next = 38;
                      return (0, _common.delay)(500);

                    case 38:
                      document.querySelector('.verify-button-holder > button') && document.querySelector('.verify-button-holder > button').click(); // 点击验证按钮
                      console.log('点击了验证按钮');
                      (0, _common.message)({ text: '替换图片检测中', color: 'green' });
                      _context6.next = 43;
                      return (0, _common.delay)(300);

                    case 43:
                      if (!(document.querySelector('.rc-imageselect-error-select-more').style.display !== 'none' || document.querySelector('.rc-imageselect-error-dynamic-more').style.display !== 'none')) {
                        _context6.next = 49;
                        break;
                      }

                      // 如果显示请点击更多图片等3秒
                      console.log('提示了点更多图片,等待3秒等图片加载完成');
                      _context6.next = 47;
                      return (0, _common.delay)(300);

                    case 47:
                      _context6.next = 49;
                      return (0, _common.waitFor)('.rc-image-tile-wrapper .rc-image-tile-11');

                    case 49:
                      if (!(document.querySelector('.rc-image-tile-wrapper .rc-image-tile-11') && document.querySelectorAll('.rc-image-tile-wrapper .rc-image-tile-11').length)) {
                        _context6.next = 98;
                        break;
                      }

                    case 50:
                      if (!(document.querySelectorAll('.rc-image-tile-wrapper .rc-image-tile-11').length !== 3)) {
                        _context6.next = 55;
                        break;
                      }

                      _context6.next = 53;
                      return (0, _common.delay)(300);

                    case 53:
                      _context6.next = 50;
                      break;

                    case 55:
                      i = 0;

                    case 56:
                      if (!(i < 10)) {
                        _context6.next = 98;
                        break;
                      }

                      console.log('替换图片第' + i + '次');
                      replaceImages = (0, _from2.default)(document.querySelectorAll('.rc-image-tile-wrapper .rc-image-tile-11'));

                      console.log('替换图片张数:', replaceImages.length);

                      if (!replaceImages.length) {
                        _context6.next = 80;
                        break;
                      }

                      j = 0;

                    case 62:
                      if (!(j < replaceImages.length)) {
                        _context6.next = 78;
                        break;
                      }

                      src = replaceImages[j].src;
                      _context6.next = 66;
                      return (0, _common.imageready)(src);

                    case 66:
                      _context6.next = 68;
                      return (0, _common.div2base64)(src, 100, 100);

                    case 68:
                      data.task.image = _context6.sent;
                      _context6.next = 71;
                      return (0, _common.post)(config.host + '/createTask', data);

                    case 71:
                      _res = _context6.sent;

                      if (_res.errorCode) {
                        console.log(_res.errorDescription);
                        console.log('单张图片出现错误');
                      }
                      if (_res.solution.hasObject) {
                        replaceImages[j].click();
                      }
                      replaceImages[j].className = ''; // 移除 rc-image-tile-11 防止重复生成任务

                    case 75:
                      j++;
                      _context6.next = 62;
                      break;

                    case 78:
                      _context6.next = 82;
                      break;

                    case 80:
                      console.log('没有替换图片,退出循环');
                      return _context6.abrupt('break', 98);

                    case 82:
                      _context6.next = 84;
                      return (0, _common.delay)(300);

                    case 84:
                      if (document.querySelector('.rc-image-tile-wrapper .rc-image-tile-11')) {
                        _context6.next = 95;
                        break;
                      }

                      console.log('没有替换图片,点击验证按钮');
                      document.querySelector('.verify-button-holder > button') && document.querySelector('.verify-button-holder > button').click(); // 点击验证按钮
                      _context6.next = 89;
                      return (0, _common.delay)(3000);

                    case 89:
                      if (!(document.querySelector('.rc-imageselect-error-select-more').style.display !== 'none' || document.querySelector('.rc-imageselect-error-dynamic-more').style.display !== 'none')) {
                        _context6.next = 95;
                        break;
                      }

                      // 如果显示请点击更多图片,点刷新
                      console.log('提示选更多图,但是不知道点什么,刷新下吧.');
                      document.querySelector('.rc-button-reload') && document.querySelector('.rc-button-reload').click(); // 点击刷新按钮
                      _context6.next = 94;
                      return (0, _common.delay)(300);

                    case 94:
                      return _context6.abrupt('break', 98);

                    case 95:
                      i++;
                      _context6.next = 56;
                      break;

                    case 98:
                      _context6.next = 100;
                      return (0, _common.delay)(200);

                    case 100:
                      document.querySelector('.verify-button-holder > button') && document.querySelector('.verify-button-holder > button').click(); // 点击验证按钮

                      (0, _common.message)({ text: '等待运行完成', color: 'green' });

                    case 102:
                    case 'end':
                      return _context6.stop();
                  }
                }
              }, _loop, _this);
            });

          case 7:
            if (false) {
              _context7.next = 17;
              break;
            }

            return _context7.delegateYield(_loop(), 't0', 9);

          case 9:
            _ret = _context7.t0;
            _context7.t1 = _ret;
            _context7.next = _context7.t1 === 'continue' ? 13 : _context7.t1 === 'break' ? 14 : 15;
            break;

          case 13:
            return _context7.abrupt('continue', 7);

          case 14:
            return _context7.abrupt('break', 17);

          case 15:
            _context7.next = 7;
            break;

          case 17:
          case 'end':
            return _context7.stop();
        }
      }
    }, _callee6, this);
  }));

  return function imageclassification(_x4) {
    return _ref6.apply(this, arguments);
  };
}();

// 1、刷新出3x3图片
// 2、提交接口识别，返回3个坐标，点击3个图片
// 3、等待小图加载完成
// 4、识别三个小图，是否需要点击
// 5、如果三个小图需要点击，则点击
// 6、等待点击之后的小图加载完成
// 7、继续识别小图是否需要点击
// 8、……直到所有小图都不需要点击了，点击提交
// 9、如果报错，点击最后一个小图，再点击交
// 10、如果仍然报错，点刷新换图。


var imageclassification2 = function () {
  var _ref7 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee7(config) {
    var getquestion, getsmallimagenumber, getsmallimagelist, needclickmore, submit, refresh, imgcache, data, lastsmallimage, questionstr, img, imgsrc, widthXheight, width, _res2, _resultlist, i, replaceImages, j, src, _res3;

    return _regenerator2.default.wrap(function _callee7$(_context8) {
      while (1) {
        switch (_context8.prev = _context8.next) {
          case 0:
            // 问题
            getquestion = function getquestion() {
              return document.querySelector('#rc-imageselect > div.rc-imageselect-payload > div.rc-imageselect-instructions > div.rc-imageselect-desc-wrapper > div > strong') ? document.querySelector('#rc-imageselect > div.rc-imageselect-payload > div.rc-imageselect-instructions > div.rc-imageselect-desc-wrapper > div > strong').innerText.replace(/\s/g, '') : '';
            };
            // 小图数


            getsmallimagenumber = function getsmallimagenumber() {
              return document.querySelectorAll('.rc-image-tile-wrapper .rc-image-tile-11').length;
            };
            // 小图列表


            getsmallimagelist = function getsmallimagelist() {
              return (0, _from2.default)(document.querySelectorAll('.rc-image-tile-wrapper .rc-image-tile-11'));
            };
            // 提示点更多


            needclickmore = function needclickmore() {
              return document.querySelector('.rc-imageselect-error-select-more').style.display !== 'none' || document.querySelector('.rc-imageselect-error-dynamic-more').style.display !== 'none';
            };
            // 点提交按钮


            submit = function submit() {
              return document.querySelector('.verify-button-holder > button') && document.querySelector('.verify-button-holder > button').click();
            };
            // 刷新


            refresh = function refresh() {
              return document.querySelector('.rc-button-reload') && document.querySelector('.rc-button-reload').click();
            };

            imgcache = ''; // 图片缓存

            data = { 'clientKey': config.clientKey, callurl: (0, _common.getParentUrl)(), 'task': { 'type': 'ReCaptchaV2Classification', 'image': null, 'question': null } };

            console.log('等待页问题');
            _context8.next = 11;
            return (0, _common.waitFor)('#rc-imageselect > div.rc-imageselect-payload > div.rc-imageselect-instructions > div.rc-imageselect-desc-wrapper > div > strong');

          case 11:
            if (false) {
              _context8.next = 125;
              break;
            }

            _context8.next = 14;
            return (0, _common.delay)(1000);

          case 14:
            lastsmallimage = void 0; // 最后的小图,等待最后一次失败时点击

            _context8.next = 17;
            return (0, _common.waitDo)(getquestion);

          case 17:
            questionstr = getquestion();

            console.log('问题:', questionstr);

            if (questionstr) {
              _context8.next = 21;
              break;
            }

            return _context8.abrupt('continue', 11);

          case 21:
            data.task.question = _jsonall.jsonall[questionstr];
            img = document.querySelector('#rc-imageselect-target .rc-image-tile-wrapper');

            if (img) {
              _context8.next = 28;
              break;
            }

            console.log('未找到图片对象');
            _context8.next = 27;
            return (0, _common.delay)(1000);

          case 27:
            return _context8.abrupt('continue', 11);

          case 28:
            imgsrc = img.querySelector('img').src;
            _context8.next = 31;
            return (0, _common.imageready)(imgsrc);

          case 31:
            console.log('图片加载完成');

            if (!(imgsrc === imgcache)) {
              _context8.next = 37;
              break;
            }

            console.log('发现图片在缓存区,跳过');
            _context8.next = 36;
            return (0, _common.delay)(300);

          case 36:
            return _context8.abrupt('continue', 11);

          case 37:
            imgcache = imgsrc;
            widthXheight = img.querySelector('img').attributes.class.value.match(/\d+/)[0];
            width = widthXheight === '44' ? 450 : 300;

            console.log('获取到图像class为', widthXheight, '推断宽度为', width);
            _context8.next = 43;
            return (0, _common.div2base64)(imgsrc, width, width);

          case 43:
            data.task.image = _context8.sent;
            _context8.next = 46;
            return (0, _common.post)(config.host + '/createTask', data);

          case 46:
            _res2 = _context8.sent;

            console.log('提交获取结果:', _res2);

            if (!_res2.errorDescription) {
              _context8.next = 56;
              break;
            }

            // 出错时显示出错信息然后跳过
            console.log('出错:', _res2.errorDescription);
            (0, _common.message)({ text: _res2.errorDescription, color: 'red' });

            if (!(0, _common.notneedcontinue)(_res2.errorCode)) {
              _context8.next = 54;
              break;
            }

            console.log('不需要继续,程序退出');
            return _context8.abrupt('break', 125);

          case 54:
            // 如果不需要继续则退出
            document.querySelector('.rc-button-reload') && document.querySelector('.rc-button-reload').click(); // 点击刷新按钮
            return _context8.abrupt('continue', 11);

          case 56:
            console.log('图片为' + width + '的图片');
            console.log('需点击数量为', _res2.solution.objects.length);
            _resultlist = (0, _from2.default)(document.querySelectorAll('#rc-imageselect-target > table > tbody > tr> td'));
            // console.log('添加延时1秒')
            // await delay(1000)
            // res.solution.objects.forEach(async (item, index) => {
            //   console.log('点击第' + (item + 1) + '个')
            //   await delay(500)
            //   resultlist[item].click()
            // })

            i = 0;

          case 60:
            if (!(i < _res2.solution.objects.length)) {
              _context8.next = 68;
              break;
            }

            console.log('点击第' + (_res2.solution.objects[i] + 1) + '个');
            _context8.next = 64;
            return (0, _common.delay)(50);

          case 64:
            _resultlist[_res2.solution.objects[i]].click();

          case 65:
            i++;
            _context8.next = 60;
            break;

          case 68:
            if (!(width === 450)) {
              _context8.next = 74;
              break;
            }

            // 如果是4X4图片，则点击提交等待下一个循环
            console.log('宽度为 450,点击提交,等待3秒后会最开始循环');
            // break
            _context8.next = 72;
            return (0, _common.delay)(1000);

          case 72:
            document.querySelector('.verify-button-holder > button') && document.querySelector('.verify-button-holder > button').click(); // 点击验证按钮
            // await delay(1000)
            return _context8.abrupt('continue', 11);

          case 74:
            console.log('宽度为300,判断是否加载小图,超时5秒');
            _context8.next = 77;
            return (0, _common.waitDo)(function () {
              return getsmallimagenumber() === 3;
            }, 5);

          case 77:
            // 等待超时时间设置...
            console.log('小图个数', getsmallimagenumber());

          case 78:
            if (!getsmallimagenumber()) {
              _context8.next = 110;
              break;
            }

            replaceImages = getsmallimagelist();

            lastsmallimage = replaceImages[replaceImages.length - 1];
            console.log('小图列表', replaceImages);
            console.log('循环点击小图');
            j = 0;

          case 84:
            if (!(j < replaceImages.length)) {
              _context8.next = 105;
              break;
            }

            src = replaceImages[j].src;

            console.log('加载小图' + (j + 1));
            _context8.next = 89;
            return (0, _common.imageready)(src);

          case 89:
            _context8.next = 91;
            return (0, _common.div2base64)(src, 100, 100);

          case 91:
            data.task.image = _context8.sent;

            console.log('加载完成提交识别');
            _context8.next = 95;
            return (0, _common.post)(config.host + '/createTask', data);

          case 95:
            _res3 = _context8.sent;

            console.log('提交获取结果:', _res3);
            if (_res3.errorCode) {
              console.log(_res3.errorDescription);
              console.log('单张图片出现错误');
            }
            if (_res3.solution.hasObject) {
              console.log('点击了第' + (j + 1) + '张小图');
              replaceImages[j].click();
            }
            replaceImages[j].className = ''; // 清除小图样式
            replaceImages[j].style.width = '100%';
            replaceImages[j].style.height = '100%';

          case 102:
            j++;
            _context8.next = 84;
            break;

          case 105:
            console.log('等待加载新小图,超时5秒');
            _context8.next = 108;
            return (0, _common.waitDo)(function () {
              return getsmallimagenumber();
            }, 5);

          case 108:
            _context8.next = 78;
            break;

          case 110:

            // while (document.querySelectorAll('.rc-image-tile-wrapper .rc-image-tile-11').length) {
            //   while (document.querySelectorAll('.rc-image-tile-wrapper .rc-image-tile-11').length !== 3) {
            //     console.log('等待小图加载完成', document.querySelectorAll('.rc-image-tile-wrapper .rc-image-tile-11').length)
            //     await delay(300)
            //   }

            //   let replaceImages = Array.from(document.querySelectorAll('.rc-image-tile-wrapper .rc-image-tile-11'))
            //   console.log('替换的小图为', replaceImages)
            //   lastsmallimage = replaceImages[replaceImages.length - 1]
            //   for (let j = 0; j < replaceImages.length; j++) {
            //     let src = replaceImages[j].src

            //     await imageready(src)

            //     // if (!catchesiglelist.includes(src)) {
            //     //   catchesiglelist.push(src)
            //     data.task.image = await div2base64(src, 100, 100)
            //     let res = await post(`${config.host}/createTask`, data)
            //     if (res.errorCode) {
            //       console.log(res.errorDescription)
            //       console.log('单张图片出现错误')
            //     }
            //     if (res.solution.hasObject) {
            //       console.log('点击了第' + (j + 1) + '张小图')
            //       replaceImages[j].click()
            //     }
            //     replaceImages[j].className = ''
            //   }
            //   await delay(500)
            // }
            // 没小图了,点提交
            console.log('没小图提交');
            // await delay(2000)
            // 点提交
            submit();
            _context8.next = 114;
            return (0, _common.delay)(1000);

          case 114:
            if (!needclickmore()) {
              _context8.next = 123;
              break;
            }

            // 如果显示请点击更多图片点最后一张小图
            console.log('显示请点击更多,点最后一张,然点提交');
            lastsmallimage && lastsmallimage.click();
            _context8.next = 119;
            return (0, _common.delay)(2000);

          case 119:
            submit(); // 点提交
            _context8.next = 122;
            return (0, _common.delay)(2000);

          case 122:
            if (needclickmore()) {
              // 仍然报错,刷新
              console.log('仍然报错点刷新');
              refresh(); // 点击刷新按钮
            }

          case 123:
            _context8.next = 11;
            break;

          case 125:
          case 'end':
            return _context8.stop();
        }
      }
    }, _callee7, this);
  }));

  return function imageclassification2(_x5) {
    return _ref7.apply(this, arguments);
  };
}();

// 图像识别分类第三版


var imageclassification_aaron = function () {
  var _ref8 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee12(config) {
    var _this2 = this;

    var img11, img11Score, verifyStatus, imgurlall, watchService, refresh, verify, delayVerify, needclickmore, reClick, getquestion, getindex, DoOcr, Clicks, listener, watchCheckbox;
    return _regenerator2.default.wrap(function _callee12$(_context13) {
      while (1) {
        switch (_context13.prev = _context13.next) {
          case 0:
            getindex = function getindex(obj, objall) {
              var objall = document.querySelectorAll(objall);
              for (var i = 0; i < objall.length; i++) {
                if (obj == objall[i]) {
                  return i;
                }
              }
              return -1;
            };

            // 小图
            img11 = [];
            // 记录小图的分值

            img11Score = {};
            // 延时点击验证按钮

            verifyStatus = 0;

            // 图片缓存

            imgurlall = "";

            // 定时打勾开关

            watchService = 0;

            // 刷新

            refresh = function refresh() {
              return document.querySelector('.rc-button-reload') && document.querySelector('.rc-button-reload').click();
            };

            // 验证


            verify = function verify() {
              return img11.length == 0 && document.querySelector('#recaptcha-verify-button') && document.querySelector('#recaptcha-verify-button').click() && console.log('verify: clicked');
            };

            // 延时验证


            delayVerify = function delayVerify() {
              console.log('delayVerify: ' + verifyStatus);
              clearTimeout(verifyStatus);
              verifyStatus = setTimeout(verify(), 3000);
            };

            // 提示点更多


            needclickmore = function needclickmore() {
              return document.querySelector('.rc-imageselect-error-select-more').style.display !== 'none' || document.querySelector('.rc-imageselect-error-dynamic-more').style.display !== 'none';
            };

            // 如果未点击完成，需要进行补点


            reClick = function () {
              var _ref9 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee9() {
                var keysSorted, index, imagesList, image;
                return _regenerator2.default.wrap(function _callee9$(_context10) {
                  while (1) {
                    switch (_context10.prev = _context10.next) {
                      case 0:
                        // 如果需要点击更多的提示
                        console.log('reClick: needclickmore: ' + needclickmore());

                        if (!needclickmore()) {
                          _context10.next = 22;
                          break;
                        }

                        console.log('reClick: needclickmore!');
                        // 先判断记录小图分值是否为空

                        if (!(0, _keys2.default)(img11Score).length) {
                          _context10.next = 20;
                          break;
                        }

                        console.log('reClick: img11Score: ' + (0, _stringify2.default)(img11Score));
                        keysSorted = (0, _keys2.default)(img11Score).sort(function (a, b) {
                          return img11Score[b] - img11Score[a];
                        });

                        console.log('reClick: keysSorted: ' + keysSorted);
                        index = keysSorted[0][1] * 1;

                        console.log('reClick: index: ' + index);
                        imagesList = (0, _from2.default)(document.querySelectorAll('#rc-imageselect-target > table > tbody > tr> td'));
                        image = imagesList[index];

                        if (image) {
                          _context10.next = 17;
                          break;
                        }

                        console.log('reClick: no image refresh!');
                        _context10.next = 15;
                        return (0, _common.delay)(1000);

                      case 15:
                        refresh();
                        return _context10.abrupt('return');

                      case 17:
                        // 提交图像识别
                        DoOcr(image, index).then(function () {
                          var _ref10 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee8(res) {
                            return _regenerator2.default.wrap(function _callee8$(_context9) {
                              while (1) {
                                switch (_context9.prev = _context9.next) {
                                  case 0:
                                    console.log("reClick doocr: " + res);
                                    // 删除这个元素
                                    delete img11Score['_' + index];

                                    if (!needclickmore()) {
                                      _context9.next = 7;
                                      break;
                                    }

                                    // 未能成功点击最后一张图，刷新
                                    console.log("reClick cannot pass refresh");
                                    _context9.next = 6;
                                    return (0, _common.delay)(1000);

                                  case 6:
                                    refresh();

                                  case 7:
                                  case 'end':
                                    return _context9.stop();
                                }
                              }
                            }, _callee8, _this2);
                          }));

                          return function (_x7) {
                            return _ref10.apply(this, arguments);
                          };
                        }());

                        // 如果为空说明全部点错了，需要刷新
                        _context10.next = 22;
                        break;

                      case 20:
                        // 清空记录
                        img11Score = {};
                        // await delay(2000)
                        console.log('reClick: refresh!');
                        // refresh()

                      case 22:
                      case 'end':
                        return _context10.stop();
                    }
                  }
                }, _callee9, _this2);
              }));

              return function reClick() {
                return _ref9.apply(this, arguments);
              };
            }();

            // 获取问题


            getquestion = function getquestion() {
              return document.querySelector("strong").innerText.replace(/\s/g, "");
            };

            // 获取对象的位置


            ;

            // 提交图像识别

            DoOcr = function () {
              var _ref11 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee10(image, index) {
                var data, questionstr, res;
                return _regenerator2.default.wrap(function _callee10$(_context11) {
                  while (1) {
                    switch (_context11.prev = _context11.next) {
                      case 0:
                        if (image.src) {
                          _context11.next = 3;
                          break;
                        }

                        console.log('ocr: image.src: ' + image.src);
                        return _context11.abrupt('return');

                      case 3:
                        if (!(imgurlall.indexOf(image.src) == 1)) {
                          _context11.next = 6;
                          break;
                        }

                        console.log('ocr: image.src: exist');
                        return _context11.abrupt('return');

                      case 6:

                        // 图片加入缓存
                        imgurlall = imgurlall + image.src;

                        // 图像识别参数
                        data = { 'clientKey': config.clientKey, callurl: (0, _common.getParentUrl)(), 'task': { 'type': 'ReCaptchaV2Classification', 'image': null, 'question': null }
                          // 等待
                          // await imageready(image.src)
                          // 转换图片
                        };
                        _context11.next = 10;
                        return (0, _common.div2base64)(image.src, image.naturalWidth, image.naturalHeight);

                      case 10:
                        data.task.image = _context11.sent;

                        if (!(data.task.image == "data:,")) {
                          _context11.next = 22;
                          break;
                        }

                        // console.log('ocr: image: data')
                        // return false

                        console.log('ocr: image: data');
                        _context11.next = 15;
                        return (0, _common.delay)(3000);

                      case 15:
                        console.log('ocr: image: try again');
                        _context11.next = 18;
                        return (0, _common.div2base64)(image.src, image.naturalWidth, image.naturalHeight);

                      case 18:
                        data.task.image = _context11.sent;

                        if (!(data.task.image == "data:,")) {
                          _context11.next = 22;
                          break;
                        }

                        console.log('ocr: image: failed');
                        return _context11.abrupt('return', false);

                      case 22:

                        // 获取当前问题
                        questionstr = getquestion();

                        console.log('ocr: question:', questionstr);
                        data.task.question = _jsonall.jsonall[questionstr];

                        if (!(!data.task.question || !data.task.image)) {
                          _context11.next = 28;
                          break;
                        }

                        console.log('ocr: error: ' + data.task.image);
                        return _context11.abrupt('return', false);

                      case 28:
                        _context11.next = 30;
                        return (0, _common.post)(config.host + '/createTask', data);

                      case 30:
                        res = _context11.sent;

                        console.log('ocr: response:', res);

                        // 处理识别结果: 出错

                        if (!res.errorDescription) {
                          _context11.next = 45;
                          break;
                        }

                        console.log('ocr: errorDescription:', res.errorDescription);
                        (0, _common.message)({ text: res.errorDescription, color: 'green' });

                        if (!(0, _common.notneedcontinue)(res.errorCode)) {
                          _context11.next = 40;
                          break;
                        }

                        console.log('ocr: exit.');
                        return _context11.abrupt('return', false);

                      case 40:
                        // 点刷新按钮
                        console.log('ocr: refresh.');
                        _context11.next = 43;
                        return (0, _common.delay)(2000);

                      case 43:
                        refresh();
                        return _context11.abrupt('return', true);

                      case 45:
                        if (!res.solution) {
                          _context11.next = 50;
                          break;
                        }

                        console.log('ocr: goto clicks.');
                        _context11.next = 49;
                        return Clicks(image, res.solution, index);

                      case 49:
                        return _context11.abrupt('return', _context11.sent);

                      case 50:
                        return _context11.abrupt('return', false);

                      case 51:
                      case 'end':
                        return _context11.stop();
                    }
                  }
                }, _callee10, this);
              }));

              return function DoOcr(_x8, _x9) {
                return _ref11.apply(this, arguments);
              };
            }();

            // 点击图片对象


            Clicks = function () {
              var _ref12 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee11(image, solution, index) {
                var resultlist, i;
                return _regenerator2.default.wrap(function _callee11$(_context12) {
                  while (1) {
                    switch (_context12.prev = _context12.next) {
                      case 0:

                        console.log('click: index: ' + index);
                        console.log('click: width: ' + image.naturalWidth);
                        console.log('click: objects: ' + (0, _stringify2.default)(solution));

                        // 处理1x1图片的点击

                        if (!(image.naturalWidth == 100 && solution.hasObject)) {
                          _context12.next = 15;
                          break;
                        }

                        // 点击小图
                        console.log('click: 1x1: ' + index);
                        image.click();
                        _context12.next = 8;
                        return (0, _common.delay)(3000);

                      case 8:
                        delayVerify();
                        _context12.next = 11;
                        return (0, _common.delay)(2000);

                      case 11:
                        reClick();
                        return _context12.abrupt('return', true);

                      case 15:
                        if (!(image.naturalWidth == 100 && !solution.hasObject)) {
                          _context12.next = 29;
                          break;
                        }

                        // 不点击返回
                        delete img11['_' + index];
                        // 记录分值
                        console.log('click: score: ' + solution.confidence);
                        img11Score['_' + index] = solution.confidence;
                        console.log('click: img11Score: ' + (0, _stringify2.default)(img11Score));
                        _context12.next = 22;
                        return (0, _common.delay)(3000);

                      case 22:
                        delayVerify();
                        _context12.next = 25;
                        return (0, _common.delay)(2000);

                      case 25:
                        reClick();
                        return _context12.abrupt('return', true);

                      case 29:
                        if (!(image.naturalWidth == 100 && !index)) {
                          _context12.next = 32;
                          break;
                        }

                        console.log('click: no index return');
                        return _context12.abrupt('return', false);

                      case 32:

                        // 列出所有图片
                        resultlist = (0, _from2.default)(document.querySelectorAll('#rc-imageselect-target > table > tbody > tr> td'));


                        for (i = 0; i < solution.objects.length; i++) {
                          // await delay(100)
                          console.log('click: ojbects: ' + (solution.objects[i] + 1));
                          resultlist[solution.objects[i]].click();
                        }

                        // 450 的图片立即确认

                        if (!(image.naturalWidth == 450)) {
                          _context12.next = 40;
                          break;
                        }

                        _context12.next = 37;
                        return (0, _common.delay)(500);

                      case 37:
                        delayVerify();
                        // 300 的图片需要延迟3秒后检查1x1图片
                        _context12.next = 44;
                        break;

                      case 40:
                        if (!(image.naturalWidth == 300)) {
                          _context12.next = 44;
                          break;
                        }

                        _context12.next = 43;
                        return (0, _common.delay)(3000);

                      case 43:
                        delayVerify();

                      case 44:
                      case 'end':
                        return _context12.stop();
                    }
                  }
                }, _callee11, this);
              }));

              return function Clicks(_x10, _x11, _x12) {
                return _ref12.apply(this, arguments);
              };
            }();

            // 九宫格
            // https://www.google.com/recaptcha/api2/bframe?hl=zh-CN&v=_exWVY_hlNJJl2Abm8pI9i1L&k=6Le-wvkSAAAAAPBMRTvw0Q4Muexq9bi0DJwx_mJ-

            // 勾选框
            // https://www.google.com/recaptcha/api2/anchor?ar=1&k=6Le-wvkSAAAAAPBMRTvw0Q4Muexq9bi0DJwx_mJ-&co=aHR0cHM6Ly93d3cuZ29vZ2xlLmNvbTo0NDM.&hl=zh-CN&v=_exWVY_hlNJJl2Abm8pI9i1L&size=normal&sa=action&cb=8zd5f5cs1elv

            if (window.self.location.href.match(/\/recaptcha\/(.*?)\/bframe\?/) != null) {

              console.log("now we in bframe page, do bfame page action");

              // setInterval(itmeerval, 1000);

              // 对当前框架页增加监听，当页面发生变化时执行以下函数
              listener = document.addEventListener("DOMSubtreeModified", function (e) {

                // CASE1: 如果发生变化的对象是图片框，并且已经加载了图片: 用于侦听窗口变化 
                if (e.target == document.querySelector("#rc-imageselect-target") && document.querySelector('#rc-imageselect-target > table > tbody > tr> td>div>div>img')) {

                  // 1、当图片加载完成触发事件
                  document.querySelector("div.rc-image-tile-wrapper > img").onload = function () {

                    // 获取第一张图片
                    var image = document.querySelectorAll('#rc-imageselect-target > table > tbody > tr> td>div>div>img')[0];
                    var imagecode = "";

                    // 获取这张图片的class名称，用于判断当前是3x3/4x4的框架
                    if (image) {
                      imagecode = image.className.substring(image.className.length - 2);
                    }

                    // 提交图像识别
                    DoOcr(image).then(function (res) {
                      console.log('doocr: ' + res);
                    });
                  };

                  //CSSE2: 检测当前图片是否已经识别过，如果没有识别过就进行识别
                  var lsurl = document.querySelector('#rc-imageselect-target > table > tbody > tr> td>div>div>img').src;
                  console.log('case2: lsurl:' + lsurl);
                  if (imgurlall.indexOf(lsurl) == -1) {
                    // 缓存图片地址
                    // imgurlall = imgurlall + lsurl;

                    // 选择图片
                    var image = document.querySelector('#rc-imageselect-target > table > tbody > tr> td>div>div>img');
                    console.log('case2: image: ' + image);
                    var index = getindex(image, "#rc-imageselect-target > table > tbody > tr> td> div > div.rc-image-tile-wrapper > img");
                    var imagecode = image.className.substring(image.className.length - 2);
                    console.log('case2: index: ' + index);
                    console.log('case2: imagecode: ' + imagecode);
                    if (imagecode * 1 == 11) {
                      clearTimeout(verifyStatus);
                      img11['_' + index] = 'y';
                    }
                    // 提交图像识别
                    if (image) {
                      DoOcr(image, index).then(function (res) {
                        console.log('doocr: ' + res);
                      });
                    }
                  }
                } else {
                  // CSSE3 处理直接加载的情况: 如1x1图片的点击
                  var image = e.target.querySelector(" div > div.rc-image-tile-wrapper > img");

                  if (image) {
                    console.log('case3: image: ' + image.src);
                    var index = getindex(image, "#rc-imageselect-target > table > tbody > tr> td> div > div.rc-image-tile-wrapper > img");
                    var imagecode = image.className.substring(image.className.length - 2);
                    console.log('case3: index: ' + index);
                    console.log('case3: imagecode: ' + imagecode);

                    if (imagecode * 1 == 11) {
                      clearTimeout(verifyStatus);
                      img11['_' + index] = 'y';
                    }

                    // 提交图像识别
                    DoOcr(image, index).then(function (res) {
                      console.log('case3 doocr: ' + res);
                    });
                  }
                }
              }, false);
            }

            if (window.self.location.href.match(/\/recaptcha\/(.*?)\/anchor\?/) != null) {

              // 自动勾选识别框
              watchCheckbox = function watchCheckbox() {

                if (document.querySelector("#recaptcha-anchor")) {
                  if (document.querySelector("#recaptcha-anchor").getAttribute("aria-checked") == "false" && getComputedStyle(document.querySelector("#recaptcha-anchor > div.recaptcha-checkbox-border")).getPropertyValue("border") == ".125rem solid rgb(255, 0, 0)" && document.querySelector("#rc-anchor-container > div.rc-anchor-error-msg-container").style.display == "none") {
                    location.reload();
                  } else {
                    if (document.querySelector("#recaptcha-anchor").getAttribute("aria-checked") == "false") {
                      document.querySelector("#recaptcha-anchor").click();
                    }
                  }
                }
              };

              console.log("now we in anchor page, do anchor page action");

              if (watchService == 0) {
                watchService = setInterval(watchCheckbox, 3000);
              }
            }

          case 17:
          case 'end':
            return _context13.stop();
        }
      }
    }, _callee12, this);
  }));

  return function imageclassification_aaron(_x6) {
    return _ref8.apply(this, arguments);
  };
}();

// 图像识别分类第四版


var imageclassification_v4 = function () {
  var _ref13 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee15(config) {
    var img11, img11Score, timeid, watchService, stuckCount, stuckRefreshTimes, ImageCache, isBramePage, isAnchorPage, refresh, getquestion, clicktime, watchCheckbox, reTarget, rcImageselectTarget, errorSelectMore, errorDynamicMore, needMore, CheckforStuck, ImageToBase64, getindex, DoOcr, Clicks;
    return _regenerator2.default.wrap(function _callee15$(_context16) {
      while (1) {
        switch (_context16.prev = _context16.next) {
          case 0:
            getindex = function getindex(obj, objall) {
              var objall = document.querySelectorAll(objall);
              for (var i = 0; i < objall.length; i++) {
                if (obj == objall[i]) {
                  return i;
                }
              }
              return -1;
            };

            ImageToBase64 = function ImageToBase64(img) {
              var canvas = document.createElement("canvas");
              var widthx = img.naturalWidth;
              canvas.width = widthx;
              canvas.height = widthx;
              var ctx = canvas.getContext("2d");
              ctx.drawImage(img, 0, 0, widthx, widthx);
              var dataURL = canvas.toDataURL('image/jpeg');
              var base = dataURL.replace("data:image/jpeg;base64,", "");
              if (base == "data:,") {
                return;
              }
              return base;
            };

            CheckforStuck = function CheckforStuck() {
              if (needMore()) {
                stuckCount = stuckCount + 1;
                console.log('CheckforStuck: ' + stuckCount);
              } else {
                console.log('CheckforStuck: clear!');
                stuckCount = 0;
              }
              if (stuckCount >= stuckRefreshTimes) {
                console.log('CheckforStuck: 6 times for refresh()');
                refresh();
              }
            };

            clicktime = function clicktime() {

              // 如果有白屏，则等待3秒后再试
              if (document.querySelector('td.rc-imageselect-dynamic-selected')) {
                console.log('find selected image');
                // await delay(3000)
                clearTimeout(timeid);
                timeid = setTimeout(clicktime, 1000);
                return;
              }

              if (img11.length == 0) {
                document.querySelector('#recaptcha-verify-button').click();
              }
            };

            img11 = [];
            img11Score = {};
            timeid = 0;
            watchService = 0;
            stuckCount = 0;
            stuckRefreshTimes = 5;
            ImageCache = [];

            // 确定是九宫格页面

            isBramePage = window.self.location.href.match(/\/recaptcha\/(.*?)\/bframe\?/) != null;

            // 确定是勾选框页

            isAnchorPage = window.self.location.href.match(/\/recaptcha\/(.*?)\/anchor\?/) != null;

            // 刷新

            refresh = function refresh() {
              return document.querySelector('.rc-button-reload') && document.querySelector('.rc-button-reload').click();
            };
            // 获取问题


            getquestion = function getquestion() {
              return document.querySelector("strong").innerText.replace(/\s/g, "");
            };
            // 提交


            // 自动打勾开始识别
            if (isAnchorPage) {
              // 自动勾选识别框
              watchCheckbox = function watchCheckbox() {

                if (document.querySelector("#recaptcha-anchor")) {
                  if (document.querySelector("#recaptcha-anchor").getAttribute("aria-checked") == "false" && getComputedStyle(document.querySelector("#recaptcha-anchor > div.recaptcha-checkbox-border")).getPropertyValue("border") == ".125rem solid rgb(255, 0, 0)" && document.querySelector("#rc-anchor-container > div.rc-anchor-error-msg-container").style.display == "none") {
                    location.reload();
                  } else {
                    if (document.querySelector("#recaptcha-anchor").getAttribute("aria-checked") == "false") {
                      document.querySelector("#recaptcha-anchor").click();
                    }
                  }
                }
              };

              if (watchService == 0) {
                watchService = setInterval(watchCheckbox, 3000);
              }
            }

            // 验证码图片框

            reTarget = function reTarget() {
              return document.querySelector("#rc-imageselect-target");
            };
            // 验证码图片对象： 返回九张图


            rcImageselectTarget = function rcImageselectTarget() {
              return document.querySelector('div.rc-image-tile-wrapper > img');
            };
            // 提示：请选择所有相符的图片。


            errorSelectMore = function errorSelectMore() {
              return document.querySelector('div.rc-imageselect-error-select-more');
            };
            // 提示：另外，您还需查看新显示的图片。


            errorDynamicMore = function errorDynamicMore() {
              return document.querySelector('div.rc-imageselect-error-dynamic-more');
            };
            // 需要选择更多


            needMore = function needMore() {
              return errorSelectMore() && errorSelectMore().style.display != "none" || errorDynamicMore() && errorDynamicMore().style.display != "none";
            };

            // 一个循环检测方法，防止卡住不动


            ;

            // 图片转BASE64
            ;

            // 获取对象的位置
            ;

            // 对图片进行识别

            DoOcr = function () {
              var _ref14 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee13(image, index) {
                var data, questionstr, res;
                return _regenerator2.default.wrap(function _callee13$(_context14) {
                  while (1) {
                    switch (_context14.prev = _context14.next) {
                      case 0:
                        if (!(!image || !image.src)) {
                          _context14.next = 3;
                          break;
                        }

                        console.error('ocr: imgae src not found');
                        return _context14.abrupt('return');

                      case 3:

                        // 图像识别参数
                        data = { 'clientKey': config.clientKey, callurl: (0, _common.getParentUrl)(), 'task': { 'type': 'ReCaptchaV2Classification', 'image': null, 'question': null }
                          // 转换图片
                        };
                        data.task.image = ImageToBase64(image);

                        if (data.task.image) {
                          _context14.next = 14;
                          break;
                        }

                        console.info('ocr: error: image is null retry...');
                        stuckCount = 0;
                        // clearTimeout(timeid);
                        _context14.next = 10;
                        return (0, _common.delay)(2000);

                      case 10:
                        data.task.image = ImageToBase64(image);

                        if (data.task.image) {
                          _context14.next = 14;
                          break;
                        }

                        console.info('ocr: error: image not found');
                        return _context14.abrupt('return', false);

                      case 14:
                        if (!ImageCache[image.src]) {
                          _context14.next = 19;
                          break;
                        }

                        console.error('ocr: exist');
                        return _context14.abrupt('return');

                      case 19:
                        ImageCache[image.src] = 1;

                      case 20:

                        // 获取当前问题
                        questionstr = getquestion();

                        data.task.question = _jsonall.jsonall[questionstr];

                        if (data.task.question) {
                          _context14.next = 25;
                          break;
                        }

                        console.error('ocr: error: question not found');
                        return _context14.abrupt('return', false);

                      case 25:
                        // 如果是33或44图片，清空小图和提交按钮任务
                        if (!index) {
                          img11 = [], clearTimeout(timeid);
                        }
                        // 提交后端识别
                        console.log('ocr: index:', index || -1);
                        _context14.next = 29;
                        return (0, _common.post)(config.host + '/createTask', data);

                      case 29:
                        res = _context14.sent;

                        console.log('ocr: response:', res);

                        // 处理识别结果: 出错

                        if (!res.errorDescription) {
                          _context14.next = 44;
                          break;
                        }

                        console.log('ocr: errorDescription:', res.errorDescription);
                        (0, _common.message)({ text: res.errorDescription, color: 'green' });

                        if (!(0, _common.notneedcontinue)(res.errorCode)) {
                          _context14.next = 39;
                          break;
                        }

                        console.log('ocr: exit.');
                        return _context14.abrupt('return', false);

                      case 39:
                        // 点刷新按钮
                        console.log('ocr: refresh.');
                        _context14.next = 42;
                        return (0, _common.delay)(2000);

                      case 42:
                        refresh();
                        return _context14.abrupt('return', true);

                      case 44:
                        if (!res.solution) {
                          _context14.next = 48;
                          break;
                        }

                        _context14.next = 47;
                        return Clicks(image, res.solution, index);

                      case 47:
                        return _context14.abrupt('return', _context14.sent);

                      case 48:
                      case 'end':
                        return _context14.stop();
                    }
                  }
                }, _callee13, this);
              }));

              return function DoOcr(_x14, _x15) {
                return _ref14.apply(this, arguments);
              };
            }();

            // 点击图片对象


            Clicks = function () {
              var _ref15 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee14(image, solution, index) {
                var resultlist, i;
                return _regenerator2.default.wrap(function _callee14$(_context15) {
                  while (1) {
                    switch (_context15.prev = _context15.next) {
                      case 0:

                        console.log('click: index: ' + index);
                        // 增加延时，防止被识别为机器人
                        _context15.next = 3;
                        return (0, _common.delay)(1000);

                      case 3:
                        if (!(index && solution.hasObject)) {
                          _context15.next = 11;
                          break;
                        }

                        // 点击小图
                        console.log('click: 1x1: ' + index);
                        _context15.next = 7;
                        return (0, _common.delay)(100);

                      case 7:
                        if (document.querySelectorAll('#rc-imageselect-target > table > tbody > tr> td>div>div>img')[index] && image.src == document.querySelectorAll('#rc-imageselect-target > table > tbody > tr> td>div>div>img')[index].src) document.querySelectorAll('#rc-imageselect-target > table > tbody > tr> td')[index].click();
                        return _context15.abrupt('return');

                      case 11:
                        if (!(index && !solution.hasObject)) {
                          _context15.next = 18;
                          break;
                        }

                        // 不点击返回
                        delete img11['_' + index];
                        // 记录分值
                        // console.log('click: score: ' + solution.confidence)
                        // img11Score['_' + index] = solution.confidence
                        // console.log('click: img11Score: ' + JSON.stringify(img11Score))
                        clearTimeout(timeid);
                        timeid = setTimeout(clicktime, 5000);
                        return _context15.abrupt('return');

                      case 18:
                        if (!(image.naturalWidth == 100 && !index)) {
                          _context15.next = 21;
                          break;
                        }

                        console.log('click: no index return');
                        return _context15.abrupt('return');

                      case 21:

                        // 列出所有图片
                        resultlist = (0, _from2.default)(document.querySelectorAll('#rc-imageselect-target > table > tbody > tr> td'));
                        i = 0;

                      case 23:
                        if (!(i < solution.objects.length)) {
                          _context15.next = 31;
                          break;
                        }

                        _context15.next = 26;
                        return (0, _common.delay)(100);

                      case 26:
                        console.log('click: ojbects: ' + (solution.objects[i] + 1));
                        resultlist[solution.objects[i]].click();

                      case 28:
                        i++;
                        _context15.next = 23;
                        break;

                      case 31:
                        if (!(image.naturalWidth == 450)) {
                          _context15.next = 37;
                          break;
                        }

                        _context15.next = 34;
                        return (0, _common.delay)(1000);

                      case 34:
                        document.querySelector('#recaptcha-verify-button').click();
                        // 300 的图片需要延迟3秒后检查1x1图片
                        _context15.next = 38;
                        break;

                      case 37:
                        if (image.naturalWidth == 300) {
                          clearTimeout(timeid);
                          timeid = setTimeout(clicktime, 3000);
                        }

                      case 38:
                      case 'end':
                        return _context15.stop();
                    }
                  }
                }, _callee14, this);
              }));

              return function Clicks(_x16, _x17, _x18) {
                return _ref15.apply(this, arguments);
              };
            }();

            // 九宫格页面进行点击


            if (isBramePage) {
              // 每秒检测一次是否未识别，6次以上自动刷新，防止卡住不动
              setInterval(CheckforStuck, 1000);
              document.addEventListener("DOMSubtreeModified", function (e) {

                // 反馈变动的DOM
                // console.log("e.target:");
                // console.log(e.target);

                // 对DOM添加监听事件: 如果图片发生变化 
                if (e.target == document.querySelector("#rc-imageselect-target") && document.querySelector('#rc-imageselect-target > table > tbody > tr> td>div>div>img')) {
                  // 绑定每一张图片的加载事件，当加载就执行OCR
                  document.querySelector("div.rc-image-tile-wrapper > img").onload = function () {
                    // 当图片加载时，对图片进行识别
                    DoOcr(document.querySelector("div.rc-image-tile-wrapper > img"));
                  };

                  // var lsurl = document.querySelector(
                  //   '#rc-imageselect-target > table > tbody > tr> td>div>div>img').src;
                  // if (ImageCache.indexOf(lsurl) == -1){
                  // 直接执行OCR：不明白为什么要这么写
                  DoOcr(document.querySelector('#rc-imageselect-target > table > tbody > tr> td>div>div>img'));
                  // }

                } else {
                  var image = e.target.querySelector(" div > div.rc-image-tile-wrapper > img");
                  if (image) {
                    // 获取发生变化的位置
                    var index = getindex(image, "#rc-imageselect-target > table > tbody > tr> td> div > div.rc-image-tile-wrapper > img");
                    var imagecode = image.className.substring(image.className.length - 2);
                    if (imagecode * 1 == 11) {
                      clearTimeout(timeid);
                      img11['_' + index] = 'y';
                      // 图像识别
                      DoOcr(image, index);
                    }
                  }
                }
              });
            }

          case 27:
          case 'end':
            return _context16.stop();
        }
      }
    }, _callee15, this);
  }));

  return function imageclassification_v4(_x13) {
    return _ref13.apply(this, arguments);
  };
}();

var _common = __webpack_require__(104);

var _jsonall = __webpack_require__(190);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// window.console.log = function () {};// 清除调试代码
(0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee() {
  var config, documentObj, balance;
  return _regenerator2.default.wrap(function _callee$(_context) {
    while (1) {
      switch (_context.prev = _context.next) {
        case 0:
          _context.next = 2;
          return (0, _common.getconfig)();

        case 2:
          config = _context.sent;

          if (config.autorun) {
            _context.next = 5;
            break;
          }

          return _context.abrupt('return');

        case 5:
          _context.next = 7;
          return (0, _common.captchaClassification)();

        case 7:
          documentObj = _context.sent;
          // 页面类型对象
          (0, _common.message)({ text: '自动识别已经启动', color: 'green' });

          if (config.clientKey) {
            _context.next = 13;
            break;
          }

          console.log('请先配置clientKey');
          // alert('Please enter a client key')
          (0, _common.message)({ text: '请先填写密钥ClientKey', color: 'red' });
          return _context.abrupt('return');

        case 13:
          _context.next = 15;
          return (0, _common.getBalance)(config);

        case 15:
          balance = _context.sent;

          if (!(balance.balance < 0)) {
            _context.next = 20;
            break;
          }

          (0, _common.message)({ text: '余额不足', color: 'red' });
          alert('余额不足');
          return _context.abrupt('return');

        case 20:
          if (!(!documentObj || !config[documentObj['title']])) {
            _context.next = 23;
            break;
          }

          (0, _common.messageHide)();
          return _context.abrupt('return', false);

        case 23:
          if (!(window.self.location.href.match(/\/recaptcha\/(.*?)\/anchor\?/) == null)) {
            _context.next = 31;
            break;
          }

        case 24:
          if (!(visualViewport.width === 0)) {
            _context.next = 29;
            break;
          }

          _context.next = 27;
          return (0, _common.delay)(1000);

        case 27:
          _context.next = 24;
          break;

        case 29:
          document.getElementById('checkbox') && document.getElementById('checkbox').click();
          document.body.click();

        case 31:
          _context.t0 = documentObj['title'];
          _context.next = _context.t0 === 'hcaptcha' ? 34 : _context.t0 === 'imageclassification' ? 37 : _context.t0 === 'imagetotext' ? 40 : _context.t0 === 'rainbow' ? 43 : 47;
          break;

        case 34:
          _context.next = 36;
          return hcaptcha(config);

        case 36:
          return _context.abrupt('break', 47);

        case 37:
          _context.next = 39;
          return imageclassification_v4(config);

        case 39:
          return _context.abrupt('break', 47);

        case 40:
          _context.next = 42;
          return imagetotext(config);

        case 42:
          return _context.abrupt('break', 47);

        case 43:
          (0, _common.messageHide)();
          _context.next = 46;
          return rainbow();

        case 46:
          return _context.abrupt('break', 47);

        case 47:
        case 'end':
          return _context.stop();
      }
    }
  }, _callee, undefined);
}))();

/***/ }),
/* 180 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(181), __esModule: true };

/***/ }),
/* 181 */
/***/ (function(module, exports, __webpack_require__) {

var core = __webpack_require__(5);
var $JSON = core.JSON || (core.JSON = { stringify: JSON.stringify });
module.exports = function stringify(it) { // eslint-disable-line no-unused-vars
  return $JSON.stringify.apply($JSON, arguments);
};


/***/ }),
/* 182 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(183), __esModule: true };

/***/ }),
/* 183 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(184);
module.exports = __webpack_require__(5).Object.keys;


/***/ }),
/* 184 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.14 Object.keys(O)
var toObject = __webpack_require__(47);
var $keys = __webpack_require__(62);

__webpack_require__(185)('keys', function () {
  return function keys(it) {
    return $keys(toObject(it));
  };
});


/***/ }),
/* 185 */
/***/ (function(module, exports, __webpack_require__) {

// most Object methods by ES6 should accept primitives
var $export = __webpack_require__(14);
var core = __webpack_require__(5);
var fails = __webpack_require__(39);
module.exports = function (KEY, exec) {
  var fn = (core.Object || {})[KEY] || Object[KEY];
  var exp = {};
  exp[KEY] = exec(fn);
  $export($export.S + $export.F * fails(function () { fn(1); }), 'Object', exp);
};


/***/ }),
/* 186 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(187), __esModule: true };

/***/ }),
/* 187 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(67);
__webpack_require__(188);
module.exports = __webpack_require__(5).Array.from;


/***/ }),
/* 188 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var ctx = __webpack_require__(18);
var $export = __webpack_require__(14);
var toObject = __webpack_require__(47);
var call = __webpack_require__(68);
var isArrayIter = __webpack_require__(69);
var toLength = __webpack_require__(41);
var createProperty = __webpack_require__(189);
var getIterFn = __webpack_require__(70);

$export($export.S + $export.F * !__webpack_require__(71)(function (iter) { Array.from(iter); }), 'Array', {
  // 22.1.2.1 Array.from(arrayLike, mapfn = undefined, thisArg = undefined)
  from: function from(arrayLike /* , mapfn = undefined, thisArg = undefined */) {
    var O = toObject(arrayLike);
    var C = typeof this == 'function' ? this : Array;
    var aLen = arguments.length;
    var mapfn = aLen > 1 ? arguments[1] : undefined;
    var mapping = mapfn !== undefined;
    var index = 0;
    var iterFn = getIterFn(O);
    var length, result, step, iterator;
    if (mapping) mapfn = ctx(mapfn, aLen > 2 ? arguments[2] : undefined, 2);
    // if object isn't iterable or it's array with default iterator - use simple case
    if (iterFn != undefined && !(C == Array && isArrayIter(iterFn))) {
      for (iterator = iterFn.call(O), result = new C(); !(step = iterator.next()).done; index++) {
        createProperty(result, index, mapping ? call(iterator, mapfn, [step.value, index], true) : step.value);
      }
    } else {
      length = toLength(O.length);
      for (result = new C(length); length > index; index++) {
        createProperty(result, index, mapping ? mapfn(O[index], index) : O[index]);
      }
    }
    result.length = index;
    return result;
  }
});


/***/ }),
/* 189 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $defineProperty = __webpack_require__(17);
var createDesc = __webpack_require__(42);

module.exports = function (object, index, value) {
  if (index in object) $defineProperty.f(object, index, createDesc(0, value));
  else object[index] = value;
};


/***/ }),
/* 190 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.jsonall = exports.hcaptchaItemlist = undefined;

var _defineProperty2 = __webpack_require__(191);

var _defineProperty3 = _interopRequireDefault(_defineProperty2);

var _hcaptchaItemlist, _jsonall;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* eslint-disable no-dupe-keys */

var hcaptchaItemlist = exports.hcaptchaItemlist = (_hcaptchaItemlist = {
  'airplane': '飞机',
  'seaplane': '飞机',
  'motorbus': '巴士',
  'bus': '巴士',
  'boat': '船'
}, (0, _defineProperty3.default)(_hcaptchaItemlist, 'bus', '公交车'), (0, _defineProperty3.default)(_hcaptchaItemlist, 'train', '火车'), (0, _defineProperty3.default)(_hcaptchaItemlist, 'truck', '卡车'), (0, _defineProperty3.default)(_hcaptchaItemlist, 'motorcycle', '摩托车'), (0, _defineProperty3.default)(_hcaptchaItemlist, 'bicycle', '自行车'), _hcaptchaItemlist);

var jsonall = exports.jsonall = (_jsonall = {
  // 白俄罗斯
  горыабопагоркі: '/m/09d_r',
  знакіпрыпынку: '/m/02pv19',
  вулічныязнакі: '/m/01mqdt',
  расліны: '/m/05s2s',
  дрэвы: '/m/07j7r',
  трава: '/m/08t9c_',
  хмызнякоў: '/m/0gqbt',
  кактус: '/m/025_v',
  пальмы: '/m/0cdl1',
  прыроды: '/m/05h0n',
  вадаспады: '/m/0j2kx',
  горы: '/m/09d_r',
  пагоркі: '/m/09d_r',
  вадаёмы: '/m/03ktm1',
  рэкі: '/m/06cnp',
  пляжы: '/m/0b3yr',
  Сонца: '/m/06m_p',
  Месяц: '/m/04wv_',
  неба: '/m/01bqvp',
  транспартныхсродкаў: '/m/0k4j',
  машыны: '/m/0k4j',
  веласіпеды: '/m/0199g',
  матацыклы: '/m/04_sv',
  пікапы: '/m/0cvq3',
  камерцыйныягрузавікі: '/m/0fkwjg',
  лодкі: '/m/019jd',
  лімузіны: '/m/01lcw4',
  таксі: '/m/0pg52',
  школьныаўтобус: '/m/02yvhj',
  аўтобус: '/m/01bjv',
  будаўнічаямашына: '/m/02gx17',
  статуі: '/m/013_1c',
  фантаны: '/m/0h8lhkg',
  мост: '/m/015kr',
  прыстань: '/m/01phq4',
  хмарачос: '/m/079cl',
  слупыабокалоны: '/m/01_m7',
  вітражы: '/m/011y23',
  дом: '/m/03jm5',
  жылыдом: '/m/01nblt',
  светлавыдом: '/m/04h7h',
  чыгуначнаястанцыя: '/m/0py27',
  попелам: '/m/01n6fd',
  вогнегадрант: '/m/01pns0',
  рэкламнышчыт: '/m/01knjb',
  дарогі: '/m/06gfj',
  пешаходныяпераходы: '/m/014xcs',
  святлафор: '/m/015qff',
  гаражныядзверы: '/m/08l941',
  аўтобусныяпрыпынкі: '/m/01jw_1',
  трафіку: '/m/03sy7v',
  паркоматары: '/m/015qbp',
  лесвіцы: '/m/01lynh',
  коміны: '/m/01jk_4',
  трактары: '/m/013xlm',

  // 泰语
  ภูเขาหรือเนินเขา: '/m/09d_r',
  ป้ายหยุด: '/m/02pv19',
  ป้ายถนน: '/m/01mqdt',
  พืช: '/m/05s2s',
  ต้นไม้: '/m/07j7r',
  หญ้า: '/m/08t9c_',
  พุ่มไม้: '/m/0gqbt',
  กระบองเพชร: '/m/025_v',
  ต้นปาล์ม: '/m/0cdl1',
  ธรรมชาติ: '/m/05h0n',
  น้ำตก: '/m/0j2kx',
  ภูเขา: '/m/09d_r',
  เนินเขา: '/m/09d_r',
  แหล่งน้ำ: '/m/03ktm1',
  แม่น้ำ: '/m/06cnp',
  ชายหาด: '/m/0b3yr',
  ดวงอาทิตย์: '/m/06m_p',
  ดวงจันทร์: '/m/04wv_',
  ท้องฟ้า: '/m/01bqvp',
  ยานพาหนะ: '/m/0k4j',
  รถ: '/m/0k4j',
  จักรยาน: '/m/0199g',
  รถจักรยานยนต์: '/m/04_sv',
  รถปิคอัพ: '/m/0cvq3',
  รถบรรทุกเชิงพาณิชย์: '/m/0fkwjg',
  เรือ: '/m/019jd',
  รถลีมูซีน: '/m/01lcw4',
  แท็กซี่: '/m/0pg52',
  รถโรงเรียน: '/m/02yvhj',
  รสบัส: '/m/01bjv',
  รถก่อสร้าง: '/m/02gx17',
  รูปปั้น: '/m/013_1c',
  น้ำพุ: '/m/0h8lhkg',
  สะพาน: '/m/015kr',
  ท่าเรือ: '/m/01phq4',
  ตึกระฟ้า: '/m/079cl',
  เสาเสา: '/m/01_m7',
  กระจกสี: '/m/011y23',
  บ้าน: '/m/03jm5',
  ตึกอพาร์ตเมนท์: '/m/01nblt',
  ประภาคาร: '/m/04h7h',
  สถานีรถไฟ: '/m/0py27',
  เถ้าถ่าน: '/m/01n6fd',
  ดับเพลิง: '/m/01pns0',
  ป้ายบิลบอร์ด: '/m/01knjb',
  ถนน: '/m/06gfj',
  ทางม้าลาย: '/m/014xcs',
  ไฟจราจร: '/m/015qff',
  ประตูโรงรถ: '/m/08l941',
  ป้ายรถเมล์: '/m/01jw_1',
  กรวยจราจร: '/m/03sy7v',
  เมตรที่จอดรถ: '/m/015qbp',
  บันได: '/m/01lynh',
  ปล่องไฟ: '/m/01jk_4',
  รถแทรกเตอร์: '/m/013xlm',
  รถบัส: '/m/01bjv',
  รถจักรยาน: '/m/0199g',
  หัวก๊อกน้ำดับเพลิง: '/m/01pns0',
  รถยนต์: '/m/0k4j',

  // 土耳其
  dağlarveyatepeler: '/m/09d_r',
  'dur"işaretleri': '/m/02pv19',
  sokakişaretleri: '/m/01mqdt',
  bitkiler: '/m/05s2s',
  ağaçlar: '/m/07j7r',
  Çimen: '/m/08t9c_',
  çalılar: '/m/0gqbt',
  kaktüs: '/m/025_v',
  Palmiyeağaçları: '/m/0cdl1',
  Doğa: '/m/05h0n',
  şelaleler: '/m/0j2kx',
  dağlar: '/m/09d_r',
  tepeler: '/m/09d_r',
  suyunbedenleri: '/m/03ktm1',
  nehirler: '/m/06cnp',
  Sahiller: '/m/0b3yr',
  Güneş: '/m/06m_p',
  Ay: '/m/04wv_',
  gökyüzü: '/m/01bqvp',
  Araçlar: '/m/0k4j',
  arabalar: '/m/0k4j',
  bisikletler: '/m/0199g',
  motosikletler: '/m/04_sv',
  kamyonetler: '/m/0cvq3',
  ticarikamyonlar: '/m/0fkwjg',
  tekneler: '/m/019jd',
  limuzinler: '/m/01lcw4',
  taksiler: '/m/0pg52',
  okulotobüsü: '/m/02yvhj',
  otobüs: '/m/01bjv',
  inşaataracı: '/m/02gx17',
  heykeller: '/m/013_1c',
  çeşmeler: '/m/0h8lhkg',
  köprü: '/m/015kr',
  iskele: '/m/01phq4',
  gökdelen: '/m/079cl',
  sütunsütunları: '/m/01_m7',
  vitray: '/m/011y23',
  ev: '/m/03jm5',
  apartmanbinası: '/m/01nblt',
  hafifev: '/m/04h7h',
  trenistasyonu: '/m/0py27',
  kül: '/m/01n6fd',
  yangınmusluğu: '/m/01pns0',
  reklampanosu: '/m/01knjb',
  yollar: '/m/06gfj',
  yayageçitleri: '/m/014xcs',
  trafikışıkları: '/m/015qff',
  garajkapıları: '/m/08l941',
  otobüsdurakları: '/m/01jw_1',
  trafikKonileri: '/m/03sy7v',
  Parksayacı: '/m/015qbp',
  merdivenler: '/m/01lynh',
  bacalar: '/m/01jk_4',
  traktörler: '/m/013xlm',
  Yangınmusluğu: '/m/01pns0',

  Traktör: '/m/013xlm',
  Trafiklambası: '/m/015qff',
  Motosikletin: '/m/04_sv',
  Baca: '/m/01jk_4',
  Merdiven: '/m/01lynh',
  Dağveyatepe: '/m/09d_r',
  Palmiyeağacı: '/m/0cdl1',
  Yayageçidi: '/m/014xcs',
  Köprü: '/m/015kr',
  Taksi: '/m/0pg52',
  Tekne: '/m/019jd',
  Otobüs: '/m/01bjv',
  Bisiklet: '/m/0199g',
  Motosiklet: '/m/04_sv',
  Taşıt: '/m/0k4j',
  Araba: '/m/0k4j',

  // 日语
  ストップサイン: '/m/02pv19',
  道路標識: '/m/01mqdt',
  植物: '/m/05s2s',
  木: '/m/07j7r',
  草: '/m/08t9c_',
  低木: '/m/0gqbt',
  カクタス: '/m/025_v',
  ヤシの木: '/m/0cdl1',
  自然: '/m/05h0n',
  滝: '/m/0j2kx',
  山: '/m/09d_r',
  丘: '/m/09d_r',
  水域: '/m/03ktm1',
  河川: '/m/06cnp',
  ビーチ: '/m/0b3yr',
  太陽: '/m/06m_p',
  月: '/m/04wv_',
  空: '/m/01bqvp',
  車両: '/m/0k4j',
  自動車: '/m/0k4j',
  車: '/m/0k4j',
  自転車: '/m/0199g',
  オートバイ: '/m/04_sv',
  ピックアップトラック: '/m/0cvq3',
  コマーシャルトラック: '/m/0fkwjg',
  ボート: '/m/019jd',
  リムジン: '/m/01lcw4',
  タクシー: '/m/0pg52',
  スクールバス: '/m/02yvhj',
  バス: '/m/01bjv',
  建設車両: '/m/02gx17',
  彫像: '/m/013_1c',
  噴水: '/m/0h8lhkg',
  橋: '/m/015kr',
  橋脚: '/m/01phq4',
  超高層ビル: '/m/079cl',
  柱または柱: '/m/01_m7',
  ステンドグラス: '/m/011y23',
  家: '/m/03jm5',
  アナパートメントビル: '/m/01nblt',
  灯台: '/m/04h7h',
  でんしゃのりば: '/m/0py27',
  小屋: '/m/01n6fd',
  消火剤: '/m/01pns0',
  アビルボード: '/m/01knjb',
  道路: '/m/06gfj',
  横断歩道: '/m/014xcs',
  信号機: '/m/015qff',
  交通灯: '/m/015qff',
  ガレージドア: '/m/08l941',
  バス停: '/m/01jw_1',
  トラフィックコーン: '/m/03sy7v',
  パーキングメーター: '/m/015qbp',
  階段: '/m/01lynh',
  煙突: '/m/01jk_4',
  トラクター: '/m/013xlm',

  山や丘: '/m/09d_r',

  // 繁体中文: 台湾
  停車標誌: '/m/02pv19',
  路牌: '/m/01mqdt',
  樹木: '/m/07j7r',
  灌木: '/m/0gqbt',
  仙人掌: '/m/025_v',
  棕櫚樹: '/m/0cdl1',
  瀑布: '/m/0j2kx',
  高山或山丘: '/m/09d_r',
  丘陵: '/m/09d_r',
  水體: '/m/03ktm1',
  河流: '/m/06cnp',
  海灘: '/m/0b3yr',
  月亮: '/m/04wv_',
  天空: '/m/01bqvp',
  車輛: '/m/0k4j',
  汽車: '/m/0k4j',
  腳踏車: '/m/0199g',
  自行車: '/m/0199g',
  機車: '/m/04_sv',
  摩托車: '/m/04_sv',
  皮卡車: '/m/0cvq3',
  商用卡車: '/m/0fkwjg',
  船: '/m/019jd',
  豪華轎車: '/m/01lcw4',
  出租車: '/m/0pg52',
  校車: '/m/02yvhj',
  公車: '/m/01bjv',
  公共汽車: '/m/01bjv',
  施工車輛: '/m/02gx17',
  雕像: '/m/013_1c',
  噴泉: '/m/0h8lhkg',
  橋梁: '/m/015kr',
  碼頭: '/m/01phq4',
  摩天大樓: '/m/079cl',
  柱子或柱子: '/m/01_m7',
  彩色玻璃: '/m/011y23',
  房子: '/m/03jm5',
  公寓樓: '/m/01nblt',
  燈塔: '/m/04h7h',
  火車站: '/m/0py27',
  一棚: '/m/01n6fd',
  消防栓: '/m/01pns0',
  廣告牌: '/m/01knjb',
  行人穿越道: '/m/014xcs',
  人行橫道: '/m/014xcs',
  紅綠燈: '/m/015qff',
  車庫門: '/m/08l941',
  巴士站: '/m/01jw_1',
  交通錐: '/m/03sy7v',
  停車場計價表: '/m/015qbp',
  樓梯: '/m/01lynh',
  煙囪: '/m/01jk_4',
  拖拉機: '/m/013xlm',

  // 繁体中文：香港
  電單車: '/m/04_sv',
  單車: '/m/0199g',
  巴士: '/m/01bjv',
  十字路口: '/m/014xcs',
  交通燈: '/m/015qff',
  斑馬線: '/m/014xcs',
  計程車: '/m/0pg52',
  的士: '/m/0pg52',
  船隻: '/m/019jd',
  山峰或山: '/m/09d_r',
  橋樑: '/m/015kr',

  // 俄语
  'стоп-сигналы': '/m/02pv19',
  'дорожные знаки': '/m/01mqdt',
  растения: '/m/05s2s',
  деревья: '/m/07j7r',
  кустарники: '/m/0gqbt',
  'пальмовые деревья': '/m/0cdl1',
  природа: '/m/05h0n',
  водопады: '/m/0j2kx',
  холмы: '/m/09d_r',
  водоемы: '/m/03ktm1',
  реки: '/m/06cnp',
  пляжи: '/m/0b3yr',
  солнце: '/m/06m_p',
  Луна: '/m/04wv_',
  небо: '/m/01bqvp',
  'транспортные средства': '/m/0k4j',
  машины: '/m/0k4j',
  велосипеды: '/m/0199g',
  мотоциклы: '/m/04_sv',
  пикапы: '/m/0cvq3',
  'коммерческие грузовики': '/m/0fkwjg',
  лодки: '/m/019jd',
  лимузины: '/m/01lcw4',
  Таксис: '/m/0pg52',
  'школьный автобус': '/m/02yvhj',
  автобус: '/m/01bjv',
  'строительная машина': '/m/02gx17',
  статуи: '/m/013_1c',
  фонтаны: '/m/0h8lhkg',
  пирс: '/m/01phq4',
  небоскреб: '/m/079cl',
  'столбыили колонны': '/m/01_m7',
  витраж: '/m/011y23',
  'многоквартирный дом': '/m/01nblt',
  'светлый дом': '/m/04h7h',
  'железнодорожная станция': '/m/0py27',
  пепельный: '/m/01n6fd',
  'пожарный гидрант': '/m/01pns0',
  'рекламный щит': '/m/01knjb',
  дороги: '/m/06gfj',
  'пешеходные переходы': '/m/014xcs',
  светофор: '/m/015qff',
  'гаражные ворота': '/m/08l941',
  'автобусные остановки': '/m/01jw_1',
  конусы: '/m/03sy7v',
  'парковочные счетчики': '/m/015qbp',
  лестница: '/m/01lynh',
  дымоходы: '/m/01jk_4',
  тракторы: '/m/013xlm',

  автомобили: '/m/0k4j',
  горыилихолмы: '/m/09d_r',
  светофоры: '/m/015qff',
  транспортныесредства: '/m/0k4j',
  пешеходныепереходы: '/m/014xcs',
  пожарныегидранты: '/m/01pns0',
  лестницы: '/m/01lynh',
  гидрантами: '/m/01pns0',
  автобусы: '/m/01bjv',
  дымовыетрубы: '/m/01jk_4',
  трактора: '/m/013xlm',
  такси: '/m/0pg52',
  мостами: '/m/015kr',

  // 乌克兰语
  горичипагорби: '/m/09d_r',
  знакизупинки: '/m/02pv19',
  дорожнізнаки: '/m/01mqdt',
  рослини: '/m/05s2s',
  дерева: '/m/07j7r',
  чагарники: '/m/0gqbt',
  пальмовідерева: '/m/0cdl1',
  водоспади: '/m/0j2kx',
  гори: '/m/09d_r',
  пагорби: '/m/09d_r',
  водойми: '/m/03ktm1',
  річки: '/m/06cnp',
  пляжі: '/m/0b3yr',
  сонце: '/m/06m_p',
  Місяць: '/m/04wv_'
}, (0, _defineProperty3.default)(_jsonall, '\u043D\u0435\u0431\u043E', '/m/01bqvp'), (0, _defineProperty3.default)(_jsonall, '\u0442\u0440\u0430\u043D\u0441\u043F\u043E\u0440\u0442\u043D\u0456\u0437\u0430\u0441\u043E\u0431\u0438', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, '\u0430\u0432\u0442\u043E\u043C\u043E\u0431\u0456\u043B\u0456\u0432', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, '\u0432\u0435\u043B\u043E\u0441\u0438\u043F\u0435\u0434\u0438', '/m/0199g'), (0, _defineProperty3.default)(_jsonall, '\u043C\u043E\u0442\u043E\u0446\u0438\u043A\u043B\u0438', '/m/04_sv'), (0, _defineProperty3.default)(_jsonall, '\u043F\u0456\u043A\u0430\u043F\u0438', '/m/0cvq3'), (0, _defineProperty3.default)(_jsonall, '\u043A\u043E\u043C\u0435\u0440\u0446\u0456\u0439\u043D\u0456\u0432\u0430\u043D\u0442\u0430\u0436\u0456\u0432\u043A\u0438', '/m/0fkwjg'), (0, _defineProperty3.default)(_jsonall, '\u0447\u043E\u0432\u043D\u0438', '/m/019jd'), (0, _defineProperty3.default)(_jsonall, '\u043B\u0456\u043C\u0443\u0437\u0438\u043D\u0438', '/m/01lcw4'), (0, _defineProperty3.default)(_jsonall, '\u0442\u0430\u043A\u0441\u0456', '/m/0pg52'), (0, _defineProperty3.default)(_jsonall, '\u0448\u043A\u0456\u043B\u044C\u043D\u0438\u0439\u0430\u0432\u0442\u043E\u0431\u0443\u0441', '/m/02yvhj'), (0, _defineProperty3.default)(_jsonall, '\u0430\u0432\u0442\u043E\u0431\u0443\u0441', '/m/01bjv'), (0, _defineProperty3.default)(_jsonall, '\u0431\u0443\u0434\u0456\u0432\u0435\u043B\u044C\u043D\u0438\u0439\u0430\u0432\u0442\u043E\u043C\u043E\u0431\u0456\u043B\u044C', '/m/02gx17'), (0, _defineProperty3.default)(_jsonall, '\u0441\u0442\u0430\u0442\u0443\u0457', '/m/013_1c'), (0, _defineProperty3.default)(_jsonall, '\u0444\u043E\u043D\u0442\u0430\u043D\u0438', '/m/0h8lhkg'), (0, _defineProperty3.default)(_jsonall, '\u043C\u0456\u0441\u0442', '/m/015kr'), (0, _defineProperty3.default)(_jsonall, '\u043F\u0440\u0438\u0441\u0442\u0430\u043D\u044C', '/m/01phq4'), (0, _defineProperty3.default)(_jsonall, '\u0445\u043C\u0430\u0440\u043E\u0447\u043E\u0441', '/m/079cl'), (0, _defineProperty3.default)(_jsonall, '\u0441\u0442\u043E\u0432\u043F\u0438\u0430\u0431\u043E\u043A\u043E\u043B\u043E\u043D\u0438', '/m/01_m7'), (0, _defineProperty3.default)(_jsonall, '\u0432\u0456\u0442\u0440\u0430\u0436\u043D\u0435\u0441\u043A\u043B\u043E', '/m/011y23'), (0, _defineProperty3.default)(_jsonall, '\u0431\u0443\u0434\u0438\u043D\u043E\u043A', '/m/03jm5'), (0, _defineProperty3.default)(_jsonall, '\u0431\u0430\u0433\u0430\u0442\u043E\u043A\u0432\u0430\u0440\u0442\u0438\u0440\u043D\u0438\u0439\u0431\u0443\u0434\u0438\u043D\u043E\u043A', '/m/01nblt'), (0, _defineProperty3.default)(_jsonall, '\u0441\u0432\u0456\u0442\u043B\u0438\u0439\u0431\u0443\u0434\u0438\u043D\u043E\u043A', '/m/04h7h'), (0, _defineProperty3.default)(_jsonall, '\u0437\u0430\u043B\u0456\u0437\u043D\u0438\u0447\u043D\u0430\u0441\u0442\u0430\u043D\u0446\u0456\u044F', '/m/0py27'), (0, _defineProperty3.default)(_jsonall, '\u043F\u043E\u043F\u0456\u043B', '/m/01n6fd'), (0, _defineProperty3.default)(_jsonall, '\u0432\u043E\u0433\u043D\u0435\u0433\u0456\u0434\u0440\u0430\u043D\u0442', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, '\u0431\u0456\u043B\u0431\u043E\u0440\u0434', '/m/01knjb'), (0, _defineProperty3.default)(_jsonall, '\u0434\u043E\u0440\u043E\u0433\u0438', '/m/06gfj'), (0, _defineProperty3.default)(_jsonall, '\u043F\u0456\u0448\u043E\u0445\u0456\u0434\u043D\u0456\u043F\u0435\u0440\u0435\u0445\u043E\u0434\u0438', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, '\u0441\u0432\u0456\u0442\u043B\u043E\u0444\u043E\u0440', '/m/015qff'), (0, _defineProperty3.default)(_jsonall, '\u0433\u0430\u0440\u0430\u0436\u043D\u0456\u0434\u0432\u0435\u0440\u0456', '/m/08l941'), (0, _defineProperty3.default)(_jsonall, '\u0430\u0432\u0442\u043E\u0431\u0443\u0441\u043D\u0456\u0437\u0443\u043F\u0438\u043D\u043A\u0438', '/m/01jw_1'), (0, _defineProperty3.default)(_jsonall, '\u0442\u0440\u0430\u043D\u0441\u043F\u043E\u0440\u0442\u043D\u0456\u043A\u043E\u043D\u0443\u0441\u0438', '/m/03sy7v'), (0, _defineProperty3.default)(_jsonall, '\u043F\u0430\u0440\u043A\u043E\u043C\u0430\u0442\u0438', '/m/015qbp'), (0, _defineProperty3.default)(_jsonall, '\u0441\u0445\u043E\u0434\u0438', '/m/01lynh'), (0, _defineProperty3.default)(_jsonall, '\u0434\u0438\u043C\u0430\u0440\u0456', '/m/01jk_4'), (0, _defineProperty3.default)(_jsonall, '\u0442\u0440\u0430\u043A\u0442\u043E\u0440\u0438', '/m/013xlm'), (0, _defineProperty3.default)(_jsonall, '\u0430\u0432\u0442\u043E\u043C\u043E\u0431\u0456\u043B\u0456', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, '\u0433\u043E\u0440\u0438\u0447\u0438\u043F\u0430\u0433\u043E\u0440\u0431\u0438', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, '\u0442\u0440\u0430\u043D\u0441\u043F\u043E\u0440\u0442\u043D\u0456\u0437\u0430\u0441\u043E\u0431\u0438', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, '\u043A\u043E\u043C\u0438\u043D\u0438', '/m/01jk_4'), (0, _defineProperty3.default)(_jsonall, '\u043F\u0456\u0448\u043E\u0445\u0456\u0434\u043D\u0456\u043F\u0435\u0440\u0435\u0445\u043E\u0434\u0438', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, '\u0441\u0432\u0456\u0442\u043B\u043E\u0444\u043E\u0440\u0438', '/m/015qff'), (0, _defineProperty3.default)(_jsonall, '\u043C\u043E\u0441\u0442\u0438', '/m/015kr'), (0, _defineProperty3.default)(_jsonall, '\u043F\u043E\u0436\u0435\u0436\u043D\u0438\u0439\u0433\u0456\u0434\u0440\u0430\u043D\u0442', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, '\u043F\u0430\u043B\u044C\u043C\u0438', '/m/0cdl1'), (0, _defineProperty3.default)(_jsonall, '\u0430\u0432\u0442\u043E\u0431\u0443\u0441\u0438', '/m/01bjv'), (0, _defineProperty3.default)(_jsonall, '\u0441\u0443\u0434\u043D\u0430', '/m/019jd'), (0, _defineProperty3.default)(_jsonall, '\u043F\u043E\u0436\u0435\u0436\u043D\u0456\u0433\u0456\u0434\u0440\u0430\u043D\u0442\u0438', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, 'monta\xF1asocolinas', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, 'se\xF1alesdealto', '/m/02pv19'), (0, _defineProperty3.default)(_jsonall, 'Se\xF1alesdetransito', '/m/01mqdt'), (0, _defineProperty3.default)(_jsonall, 'plantas', '/m/05s2s'), (0, _defineProperty3.default)(_jsonall, '\xE1rboles', '/m/07j7r'), (0, _defineProperty3.default)(_jsonall, 'c\xE9sped', '/m/08t9c_'), (0, _defineProperty3.default)(_jsonall, 'arbustos', '/m/0gqbt'), (0, _defineProperty3.default)(_jsonall, 'cactus', '/m/025_v'), (0, _defineProperty3.default)(_jsonall, 'palmeras', '/m/0cdl1'), (0, _defineProperty3.default)(_jsonall, 'naturaleza', '/m/05h0n'), (0, _defineProperty3.default)(_jsonall, 'cascadas', '/m/0j2kx'), (0, _defineProperty3.default)(_jsonall, 'monta\xF1as', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, 'sierras', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, 'cuerposdeagua', '/m/03ktm1'), (0, _defineProperty3.default)(_jsonall, 'r\xEDos', '/m/06cnp'), (0, _defineProperty3.default)(_jsonall, 'playas', '/m/0b3yr'), (0, _defineProperty3.default)(_jsonall, 'sol', '/m/06m_p'), (0, _defineProperty3.default)(_jsonall, 'Luna', '/m/04wv_'), (0, _defineProperty3.default)(_jsonall, 'cielo', '/m/01bqvp'), (0, _defineProperty3.default)(_jsonall, 'veh\xEDculos', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, 'coches', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, 'bicicletas', '/m/0199g'), (0, _defineProperty3.default)(_jsonall, 'motocicletas', '/m/04_sv'), (0, _defineProperty3.default)(_jsonall, 'camionetas', '/m/0cvq3'), (0, _defineProperty3.default)(_jsonall, 'camionescomerciales', '/m/0fkwjg'), (0, _defineProperty3.default)(_jsonall, 'barcos', '/m/019jd'), (0, _defineProperty3.default)(_jsonall, 'limusinas', '/m/01lcw4'), (0, _defineProperty3.default)(_jsonall, 'Taxis', '/m/0pg52'), (0, _defineProperty3.default)(_jsonall, 'autob\xFAsescolar', '/m/02yvhj'), (0, _defineProperty3.default)(_jsonall, 'autob\xFAs', '/m/01bjv'), (0, _defineProperty3.default)(_jsonall, 'veh\xEDculodeconstrucci\xF3n', '/m/02gx17'), (0, _defineProperty3.default)(_jsonall, 'estatuas', '/m/013_1c'), (0, _defineProperty3.default)(_jsonall, 'fuentes', '/m/0h8lhkg'), (0, _defineProperty3.default)(_jsonall, 'puente', '/m/015kr'), (0, _defineProperty3.default)(_jsonall, 'muelle', '/m/01phq4'), (0, _defineProperty3.default)(_jsonall, 'rascacielos', '/m/079cl'), (0, _defineProperty3.default)(_jsonall, 'pilaresocolumnas', '/m/01_m7'), (0, _defineProperty3.default)(_jsonall, 'Vitral', '/m/011y23'), (0, _defineProperty3.default)(_jsonall, 'casa', '/m/03jm5'), (0, _defineProperty3.default)(_jsonall, 'Unedificiodeapartamentos', '/m/01nblt'), (0, _defineProperty3.default)(_jsonall, 'casaligera', '/m/04h7h'), (0, _defineProperty3.default)(_jsonall, 'estaci\xF3ndetren', '/m/0py27'), (0, _defineProperty3.default)(_jsonall, 'cenizas', '/m/01n6fd'), (0, _defineProperty3.default)(_jsonall, 'unabocadeincendios', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, 'cartelera', '/m/01knjb'), (0, _defineProperty3.default)(_jsonall, 'carreteras', '/m/06gfj'), (0, _defineProperty3.default)(_jsonall, 'crucesdepeatones', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, 'sem\xE1foros', '/m/015qff'), (0, _defineProperty3.default)(_jsonall, 'puertasdegaraje', '/m/08l941'), (0, _defineProperty3.default)(_jsonall, 'paradasdeautobus', '/m/01jw_1'), (0, _defineProperty3.default)(_jsonall, 'conosdetr\xE1fico', '/m/03sy7v'), (0, _defineProperty3.default)(_jsonall, 'parqu\xEDmetros', '/m/015qbp'), (0, _defineProperty3.default)(_jsonall, 'escalera', '/m/01lynh'), (0, _defineProperty3.default)(_jsonall, 'chimeneas', '/m/01jk_4'), (0, _defineProperty3.default)(_jsonall, 'tractores', '/m/013xlm'), (0, _defineProperty3.default)(_jsonall, 'pasosdepeatones', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, 'autobuses', '/m/01bjv'), (0, _defineProperty3.default)(_jsonall, 'puentes', '/m/015kr'), (0, _defineProperty3.default)(_jsonall, 'escaleras', '/m/01lynh'), (0, _defineProperty3.default)(_jsonall, 'bocasdeincendios', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, 'montagnesoucollines', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, "panneauxd'arrêt", '/m/02pv19'), (0, _defineProperty3.default)(_jsonall, 'panneauxdesignalisation', '/m/01mqdt'), (0, _defineProperty3.default)(_jsonall, 'lesplantes', '/m/05s2s'), (0, _defineProperty3.default)(_jsonall, 'desarbres', '/m/07j7r'), (0, _defineProperty3.default)(_jsonall, 'gazon', '/m/08t9c_'), (0, _defineProperty3.default)(_jsonall, 'arbustes', '/m/0gqbt'), (0, _defineProperty3.default)(_jsonall, 'cactus', '/m/025_v'), (0, _defineProperty3.default)(_jsonall, 'palmiers', '/m/0cdl1'), (0, _defineProperty3.default)(_jsonall, 'lanature', '/m/05h0n'), (0, _defineProperty3.default)(_jsonall, 'cascades', '/m/0j2kx'), (0, _defineProperty3.default)(_jsonall, 'montagnes', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, 'collines', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, "corpsd'eau", '/m/03ktm1'), (0, _defineProperty3.default)(_jsonall, 'rivi\xE8res', '/m/06cnp'), (0, _defineProperty3.default)(_jsonall, 'desplages', '/m/0b3yr'), (0, _defineProperty3.default)(_jsonall, 'soleil', '/m/06m_p'), (0, _defineProperty3.default)(_jsonall, 'Lune', '/m/04wv_'), (0, _defineProperty3.default)(_jsonall, 'ciel', '/m/01bqvp'), (0, _defineProperty3.default)(_jsonall, 'V\xE9hicules', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, 'voitures', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, 'V\xE9los', '/m/0199g'), (0, _defineProperty3.default)(_jsonall, 'motocyclettes', '/m/04_sv'), (0, _defineProperty3.default)(_jsonall, 'camionnettes', '/m/0cvq3'), (0, _defineProperty3.default)(_jsonall, 'camionscommerciaux', '/m/0fkwjg'), (0, _defineProperty3.default)(_jsonall, 'bateaux', '/m/019jd'), (0, _defineProperty3.default)(_jsonall, 'limousines', '/m/01lcw4'), (0, _defineProperty3.default)(_jsonall, 'Taxis', '/m/0pg52'), (0, _defineProperty3.default)(_jsonall, 'busscolaire', '/m/02yvhj'), (0, _defineProperty3.default)(_jsonall, 'bus', '/m/01bjv'), (0, _defineProperty3.default)(_jsonall, 'v\xE9hiculedeconstruction', '/m/02gx17'), (0, _defineProperty3.default)(_jsonall, 'statues', '/m/013_1c'), (0, _defineProperty3.default)(_jsonall, 'fontaines', '/m/0h8lhkg'), (0, _defineProperty3.default)(_jsonall, 'pont', '/m/015kr'), (0, _defineProperty3.default)(_jsonall, 'jet\xE9e', '/m/01phq4'), (0, _defineProperty3.default)(_jsonall, 'gratte-ciel', '/m/079cl'), (0, _defineProperty3.default)(_jsonall, 'piliersoucolonnes', '/m/01_m7'), (0, _defineProperty3.default)(_jsonall, 'vitrail', '/m/011y23'), (0, _defineProperty3.default)(_jsonall, 'loger', '/m/03jm5'), (0, _defineProperty3.default)(_jsonall, 'unimmeuble', '/m/01nblt'), (0, _defineProperty3.default)(_jsonall, 'maisonlumineuse', '/m/04h7h'), (0, _defineProperty3.default)(_jsonall, 'gare', '/m/0py27'), (0, _defineProperty3.default)(_jsonall, 'encendres', '/m/01n6fd'), (0, _defineProperty3.default)(_jsonall, "unebouched'incendie", '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, "unpanneaud'affichage", '/m/01knjb'), (0, _defineProperty3.default)(_jsonall, 'routes', '/m/06gfj'), (0, _defineProperty3.default)(_jsonall, 'passagespourpi\xE9tons', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, 'feuxdecirculation', '/m/015qff'), (0, _defineProperty3.default)(_jsonall, 'portesdegarage', '/m/08l941'), (0, _defineProperty3.default)(_jsonall, "arrêtsd'autobus", '/m/01jw_1'), (0, _defineProperty3.default)(_jsonall, 'c\xF4nesdesignalisation', '/m/03sy7v'), (0, _defineProperty3.default)(_jsonall, 'parcom\xE8tres', '/m/015qbp'), (0, _defineProperty3.default)(_jsonall, 'escaliers', '/m/01lynh'), (0, _defineProperty3.default)(_jsonall, 'chemin\xE9es', '/m/01jk_4'), (0, _defineProperty3.default)(_jsonall, 'tracteurs', '/m/013xlm'), (0, _defineProperty3.default)(_jsonall, 'v\xE9hicules', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, "bouchesd'incendie", '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, 'v\xE9los', '/m/0199g'), (0, _defineProperty3.default)(_jsonall, 'ponts', '/m/015kr'), (0, _defineProperty3.default)(_jsonall, "borned'incendie", '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, 'motos', '/m/04_sv'), (0, _defineProperty3.default)(_jsonall, 'BergeoderH\xFCgel', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, 'StoppSchilder', '/m/02pv19'), (0, _defineProperty3.default)(_jsonall, 'Stra\xDFenschilder', '/m/01mqdt'), (0, _defineProperty3.default)(_jsonall, 'Pflanzen', '/m/05s2s'), (0, _defineProperty3.default)(_jsonall, 'B\xE4ume', '/m/07j7r'), (0, _defineProperty3.default)(_jsonall, 'Gras', '/m/08t9c_'), (0, _defineProperty3.default)(_jsonall, 'Str\xE4ucher', '/m/0gqbt'), (0, _defineProperty3.default)(_jsonall, 'Kaktus', '/m/025_v'), (0, _defineProperty3.default)(_jsonall, 'Palmen', '/m/0cdl1'), (0, _defineProperty3.default)(_jsonall, 'Natur', '/m/05h0n'), (0, _defineProperty3.default)(_jsonall, 'Wasserf\xE4lle', '/m/0j2kx'), (0, _defineProperty3.default)(_jsonall, 'Berge', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, 'H\xFCgel', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, 'Wasserk\xF6rper', '/m/03ktm1'), (0, _defineProperty3.default)(_jsonall, 'Fl\xFCsse', '/m/06cnp'), (0, _defineProperty3.default)(_jsonall, 'Str\xE4nde', '/m/0b3yr'), (0, _defineProperty3.default)(_jsonall, 'Sonne', '/m/06m_p'), (0, _defineProperty3.default)(_jsonall, 'Mond', '/m/04wv_'), (0, _defineProperty3.default)(_jsonall, 'Himmel', '/m/01bqvp'), (0, _defineProperty3.default)(_jsonall, 'Fahrzeuge', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, 'Autos', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, 'Fahrr\xE4der', '/m/0199g'), (0, _defineProperty3.default)(_jsonall, 'Motorr\xE4der', '/m/04_sv'), (0, _defineProperty3.default)(_jsonall, 'Pickups', '/m/0cvq3'), (0, _defineProperty3.default)(_jsonall, 'Nutzfahrzeuge', '/m/0fkwjg'), (0, _defineProperty3.default)(_jsonall, 'Boote', '/m/019jd'), (0, _defineProperty3.default)(_jsonall, 'Limousinen', '/m/01lcw4'), (0, _defineProperty3.default)(_jsonall, 'Taxen', '/m/0pg52'), (0, _defineProperty3.default)(_jsonall, 'Schulbus', '/m/02yvhj'), (0, _defineProperty3.default)(_jsonall, 'Bus', '/m/01bjv'), (0, _defineProperty3.default)(_jsonall, 'Baufahrzeug', '/m/02gx17'), (0, _defineProperty3.default)(_jsonall, 'Statuen', '/m/013_1c'), (0, _defineProperty3.default)(_jsonall, 'Brunnen', '/m/0h8lhkg'), (0, _defineProperty3.default)(_jsonall, 'Br\xFCcke', '/m/015kr'), (0, _defineProperty3.default)(_jsonall, 'Seebr\xFCcke', '/m/01phq4'), (0, _defineProperty3.default)(_jsonall, 'Wolkenkratzer', '/m/079cl'), (0, _defineProperty3.default)(_jsonall, 'S\xE4ulenoderS\xE4ulen', '/m/01_m7'), (0, _defineProperty3.default)(_jsonall, 'Buntglas', '/m/011y23'), (0, _defineProperty3.default)(_jsonall, 'Haus', '/m/03jm5'), (0, _defineProperty3.default)(_jsonall, 'einWohnhaus', '/m/01nblt'), (0, _defineProperty3.default)(_jsonall, 'Leuchtturm', '/m/04h7h'), (0, _defineProperty3.default)(_jsonall, 'Bahnhof', '/m/0py27'), (0, _defineProperty3.default)(_jsonall, 'einSchuppen', '/m/01n6fd'), (0, _defineProperty3.default)(_jsonall, 'einHydrant', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, 'eineWerbetafel', '/m/01knjb'), (0, _defineProperty3.default)(_jsonall, 'Stra\xDFen', '/m/06gfj'), (0, _defineProperty3.default)(_jsonall, 'Zebrastreifen', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, 'Ampeln', '/m/015qff'), (0, _defineProperty3.default)(_jsonall, 'Garagentore', '/m/08l941'), (0, _defineProperty3.default)(_jsonall, 'Bushaltestellen', '/m/01jw_1'), (0, _defineProperty3.default)(_jsonall, 'Leitkegel', '/m/03sy7v'), (0, _defineProperty3.default)(_jsonall, 'Parkuhren', '/m/015qbp'), (0, _defineProperty3.default)(_jsonall, 'Treppe', '/m/01lynh'), (0, _defineProperty3.default)(_jsonall, 'Schornsteine', '/m/01jk_4'), (0, _defineProperty3.default)(_jsonall, 'Traktoren', '/m/013xlm'), (0, _defineProperty3.default)(_jsonall, 'Treppen(stufen)', '/m/01lynh'), (0, _defineProperty3.default)(_jsonall, 'BergenoderH\xFCgeln', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, 'Fahrzeugen', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, 'Hydranten', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, 'Zweir\xE4dern', '/m/04_sv'), (0, _defineProperty3.default)(_jsonall, 'Fahrr\xE4dern', '/m/0199g'), (0, _defineProperty3.default)(_jsonall, 'Fu\xDFg\xE4nger\xFCberwegen', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, 'Pkws', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, 'Schornsteinen', '/m/01jk_4'), (0, _defineProperty3.default)(_jsonall, 'Motorr\xE4dern', '/m/04_sv'), (0, _defineProperty3.default)(_jsonall, 'Bussen', '/m/01bjv'), (0, _defineProperty3.default)(_jsonall, 'Br\xFCcken', '/m/015kr'), (0, _defineProperty3.default)(_jsonall, 'Booten', '/m/019jd'), (0, _defineProperty3.default)(_jsonall, 'Feuerhydranten', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, '\u0627\u0644\u062C\u0628\u0627\u0644\u0623\u0648\u0627\u0644\u062A\u0644\u0627\u0644', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, '\u0639\u0644\u0627\u0645\u0627\u062A\u0627\u0644\u062A\u0648\u0642\u0641', '/m/02pv19'), (0, _defineProperty3.default)(_jsonall, '\u0644\u0627\u0641\u062A\u0627\u062A\u0627\u0644\u0634\u0648\u0627\u0631\u0639', '/m/01mqdt'), (0, _defineProperty3.default)(_jsonall, '\u0627\u0644\u0646\u0628\u0627\u062A\u0627\u062A', '/m/05s2s'), (0, _defineProperty3.default)(_jsonall, '\u0627\u0644\u0623\u0634\u062C\u0627\u0631', '/m/07j7r'), (0, _defineProperty3.default)(_jsonall, '\u0639\u0634\u0628', '/m/08t9c_'), (0, _defineProperty3.default)(_jsonall, '\u0627\u0644\u0634\u062C\u064A\u0631\u0627\u062A', '/m/0gqbt'), (0, _defineProperty3.default)(_jsonall, '\u0635\u0628\u0627\u0631', '/m/025_v'), (0, _defineProperty3.default)(_jsonall, '\u0623\u0634\u062C\u0627\u0631\u0627\u0644\u0646\u062E\u064A\u0644', '/m/0cdl1'), (0, _defineProperty3.default)(_jsonall, '\u0637\u0628\u064A\u0639\u0629\u0633\u062C\u064A\u0629', '/m/05h0n'), (0, _defineProperty3.default)(_jsonall, '\u0627\u0644\u0634\u0644\u0627\u0644\u0627\u062A', '/m/0j2kx'), (0, _defineProperty3.default)(_jsonall, '\u0627\u0644\u062C\u0628\u0627\u0644', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, '\u0627\u0644\u062A\u0644\u0627\u0644', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, '\u0627\u0644\u0645\u0633\u0637\u062D\u0627\u062A\u0627\u0644\u0645\u0627\u0626\u064A\u0629', '/m/03ktm1'), (0, _defineProperty3.default)(_jsonall, '\u0627\u0644\u0623\u0646\u0647\u0627\u0631', '/m/06cnp'), (0, _defineProperty3.default)(_jsonall, '\u0627\u0644\u0634\u0648\u0627\u0637\u0626', '/m/0b3yr'), (0, _defineProperty3.default)(_jsonall, '\u0627\u0644\u0634\u0645\u0633', '/m/06m_p'), (0, _defineProperty3.default)(_jsonall, '\u0627\u0644\u0642\u0645\u0631', '/m/04wv_'), (0, _defineProperty3.default)(_jsonall, '\u0633\u0645\u0627\u0621', '/m/01bqvp'), (0, _defineProperty3.default)(_jsonall, '\u0645\u0631\u0643\u0628\u0627\u062A', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, '\u0633\u064A\u0627\u0631\u0627\u062A', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, '\u062F\u0631\u0627\u062C\u0627\u062A', '/m/0199g'), (0, _defineProperty3.default)(_jsonall, '\u062F\u0631\u0627\u062C\u0627\u062A\u0646\u0627\u0631\u064A\u0629', '/m/04_sv'), (0, _defineProperty3.default)(_jsonall, '\u0634\u0627\u062D\u0646\u0627\u062A\u0635\u063A\u064A\u0631\u0629', '/m/0cvq3'), (0, _defineProperty3.default)(_jsonall, '\u0634\u0627\u062D\u0646\u0627\u062A\u062A\u062C\u0627\u0631\u064A\u0629', '/m/0fkwjg'), (0, _defineProperty3.default)(_jsonall, '\u0627\u0644\u0642\u0648\u0627\u0631\u0628', '/m/019jd'), (0, _defineProperty3.default)(_jsonall, '\u0633\u064A\u0627\u0631\u0627\u062A\u0627\u0644\u0644\u064A\u0645\u0648\u0632\u064A\u0646', '/m/01lcw4'), (0, _defineProperty3.default)(_jsonall, '\u0633\u064A\u0627\u0631\u0627\u062A\u0627\u0644\u0623\u062C\u0631\u0629', '/m/0pg52'), (0, _defineProperty3.default)(_jsonall, '\u0628\u0627\u0635\u0627\u0644\u0645\u062F\u0631\u0633\u0629', '/m/02yvhj'), (0, _defineProperty3.default)(_jsonall, '\u0623\u0648\u062A\u0648\u0628\u064A\u0633', '/m/01bjv'), (0, _defineProperty3.default)(_jsonall, '\u0645\u0631\u0643\u0628\u0629\u0627\u0644\u0628\u0646\u0627\u0621', '/m/02gx17'), (0, _defineProperty3.default)(_jsonall, '\u062A\u0645\u0627\u062B\u064A\u0644', '/m/013_1c'), (0, _defineProperty3.default)(_jsonall, '\u0646\u0648\u0627\u0641\u064A\u0631', '/m/0h8lhkg'), (0, _defineProperty3.default)(_jsonall, '\u0643\u0648\u0628\u0631\u064A', '/m/015kr'), (0, _defineProperty3.default)(_jsonall, '\u0631\u0635\u064A\u0641\u0628\u062D\u0631\u064A', '/m/01phq4'), (0, _defineProperty3.default)(_jsonall, '\u0646\u0627\u0637\u062D\u0629\u0633\u062D\u0627\u0628', '/m/079cl'), (0, _defineProperty3.default)(_jsonall, '\u0623\u0639\u0645\u062F\u0629\u0627\u0644\u0623\u0639\u0645\u062F\u0629', '/m/01_m7'), (0, _defineProperty3.default)(_jsonall, '\u0632\u062C\u0627\u062C\u0645\u0644\u0648\u0646', '/m/011y23'), (0, _defineProperty3.default)(_jsonall, '\u0628\u064A\u062A', '/m/03jm5'), (0, _defineProperty3.default)(_jsonall, '\u0645\u0628\u0646\u0649\u0633\u0643\u0646\u064A', '/m/01nblt'), (0, _defineProperty3.default)(_jsonall, '\u0645\u0646\u0627\u0631\u0629', '/m/04h7h'), (0, _defineProperty3.default)(_jsonall, '\u0645\u062D\u0637\u0629\u0627\u0644\u0642\u0637\u0627\u0631', '/m/0py27'), (0, _defineProperty3.default)(_jsonall, '\u0623\u0634\u064A\u062F', '/m/01n6fd'), (0, _defineProperty3.default)(_jsonall, '\u0637\u0641\u0627\u064A\u0629\u062D\u0631\u064A\u0642', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, 'abillboard', '/m/01knjb'), (0, _defineProperty3.default)(_jsonall, '\u0627\u0644\u0637\u0631\u0642', '/m/06gfj'), (0, _defineProperty3.default)(_jsonall, '\u0645\u0645\u0631\u0627\u062A\u0627\u0644\u0645\u0634\u0627\u0629', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, '\u0625\u0634\u0627\u0631\u0627\u062A\u0627\u0644\u0645\u0631\u0648\u0631', '/m/015qff'), (0, _defineProperty3.default)(_jsonall, '\u0645\u0631\u0622\u0628', '/m/08l941'), (0, _defineProperty3.default)(_jsonall, '\u0645\u062D\u0637\u0627\u062A\u0627\u0644\u062D\u0627\u0641\u0644\u0627\u062A', '/m/01jw_1'), (0, _defineProperty3.default)(_jsonall, '\u0627\u0644\u0623\u0642\u0645\u0627\u0639\u0627\u0644\u0645\u0631\u0648\u0631\u064A\u0629', '/m/03sy7v'), (0, _defineProperty3.default)(_jsonall, '\u0639\u062F\u0627\u062F\u0627\u062A\u0645\u0648\u0627\u0642\u0641\u0627\u0644\u0633\u064A\u0627\u0631\u0627\u062A', '/m/015qbp'), (0, _defineProperty3.default)(_jsonall, '\u062F\u0631\u062C', '/m/01lynh'), (0, _defineProperty3.default)(_jsonall, '\u0645\u062F\u0627\u062E\u0646', '/m/01jk_4'), (0, _defineProperty3.default)(_jsonall, '\u0627\u0644\u062C\u0631\u0627\u0631\u0627\u062A', '/m/013xlm'), (0, _defineProperty3.default)(_jsonall, '\u0635\u0646\u0627\u0628\u064A\u0631\u0625\u0637\u0641\u0627\u0621\u062D\u0631\u0627\u0626\u0642', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, '\u0625\u0634\u0627\u0631\u0627\u062A\u0645\u0631\u0648\u0631', '/m/015qff'), (0, _defineProperty3.default)(_jsonall, '\u062D\u0627\u0641\u0644\u0629', '/m/01bjv'), (0, _defineProperty3.default)(_jsonall, '\u062F\u0631\u0651\u0627\u062C\u0627', '/m/0199g'), (0, _defineProperty3.default)(_jsonall, '\u062F\u0631\u0651\u0627\u062C\u0627\u062A', '/m/015kr'), (0, _defineProperty3.default)(_jsonall, '\u0633\u064A\u0627\u0631\u0627\u062A\u0623\u062C\u0631\u0629', '/m/0pg52'), (0, _defineProperty3.default)(_jsonall, '\u062C\u0633\u0648\u0631', '/m/015kr'), (0, _defineProperty3.default)(_jsonall, '\u062F\u064E\u0631\u064E\u062C', '/m/01lynh'), (0, _defineProperty3.default)(_jsonall, '\u0645\u062F\u0627\u062E\u0650\u0646', '/m/01jk_4'), (0, _defineProperty3.default)(_jsonall, '\u062F\u0631\u0627\u062C\u0627\u062A\u0647\u0648\u0627\u0626\u064A\u0629', '/m/0199g'), (0, _defineProperty3.default)(_jsonall, '\u0645\u0645\u0631\u0651\u0627\u062A\u0644\u0644\u0645\u0634\u0627\u0629', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, '\u0645\u062D\u0628\u0633\u0625\u0637\u0641\u0627\u0621\u062D\u0631\u064A\u0642', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, '\u0633\u064A\u0627\u0631\u0629\u0623\u062C\u0631\u0629', '/m/0pg52'), (0, _defineProperty3.default)(_jsonall, '\u0642\u0648\u0627\u0631\u0628', '/m/019jd'), (0, _defineProperty3.default)(_jsonall, '\u062C\u0628\u0627\u0644\u0623\u0648\u062A\u0644\u0627\u0644', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, '\u062C\u0631\u0627\u0631\u0627\u062A', '/m/013xlm'), (0, _defineProperty3.default)(_jsonall, '\u0623\u0634\u062C\u0627\u0631\u0646\u062E\u064A\u0644', '/m/0cdl1'), (0, _defineProperty3.default)(_jsonall, '\u0645\u0646\u0627\u0637\u0642\u0639\u0628\u0648\u0631\u0645\u0634\u0627\u0629', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, '\u062D\u0627\u0641\u0644\u0627\u062A', '/m/01bjv'), (0, _defineProperty3.default)(_jsonall, '\u062F\u0631\u0651\u0627\u062C\u0627\u062A\u0628\u062E\u0627\u0631\u064A\u0629', '/m/04_sv'), (0, _defineProperty3.default)(_jsonall, '\u062C\u0631\u0651\u0627\u0631\u0627\u062A', '/m/013xlm'), (0, _defineProperty3.default)(_jsonall, '\u092A\u0939\u093E\u0921\u093C\u092F\u093E\u092A\u0939\u093E\u0921\u093C\u093F\u092F\u093E\u0901', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, '\u0938\u094D\u091F\u0949\u092A\u0938\u093E\u0907\u0928\u094D\u0938', '/m/02pv19'), (0, _defineProperty3.default)(_jsonall, '\u0938\u0921\u093C\u0915\u0915\u0947\u0938\u0902\u0915\u0947\u0924', '/m/01mqdt'), (0, _defineProperty3.default)(_jsonall, '\u092A\u094C\u0927\u094B\u0902', '/m/05s2s'), (0, _defineProperty3.default)(_jsonall, '\u092A\u0947\u0921\u093C', '/m/07j7r'), (0, _defineProperty3.default)(_jsonall, '\u0918\u093E\u0938', '/m/08t9c_'), (0, _defineProperty3.default)(_jsonall, '\u091D\u093E\u0921\u093C\u093F\u092F\u093E\u0902', '/m/0gqbt'), (0, _defineProperty3.default)(_jsonall, '\u0915\u0948\u0915\u094D\u091F\u0938', '/m/025_v'), (0, _defineProperty3.default)(_jsonall, '\u0916\u091C\u0942\u0930\u0915\u0947\u092A\u0947\u0921\u093C', '/m/0cdl1'), (0, _defineProperty3.default)(_jsonall, '\u092A\u094D\u0930\u0915\u0943\u0924\u093F', '/m/05h0n'), (0, _defineProperty3.default)(_jsonall, '\u091D\u0930\u0928\u0947', '/m/0j2kx'), (0, _defineProperty3.default)(_jsonall, '\u092A\u0939\u093E\u0921\u093C\u094B\u0902', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, '\u0939\u093F\u0932\u094D\u0938', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, '\u091C\u0932\u0928\u093F\u0915\u093E\u092F\u094B\u0902', '/m/03ktm1'), (0, _defineProperty3.default)(_jsonall, '\u0928\u0926\u093F\u092F\u094B\u0902', '/m/06cnp'), (0, _defineProperty3.default)(_jsonall, '\u0938\u092E\u0941\u0926\u094D\u0930\u0924\u091F\u094B\u0902', '/m/0b3yr'), (0, _defineProperty3.default)(_jsonall, '\u0930\u0935\u093F', '/m/06m_p'), (0, _defineProperty3.default)(_jsonall, '\u091A\u0902\u0926\u094D\u0930\u092E\u093E', '/m/04wv_'), (0, _defineProperty3.default)(_jsonall, '\u0906\u0915\u093E\u0936', '/m/01bqvp'), (0, _defineProperty3.default)(_jsonall, '\u0935\u093E\u0939\u0928\u094B\u0902', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, '\u0915\u093E\u0930\u094B\u0902', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, '\u0938\u093E\u0907\u0915\u093F\u0932\u0947\u0902', '/m/0199g'), (0, _defineProperty3.default)(_jsonall, '\u092E\u094B\u091F\u0930\u0938\u093E\u0907\u0915\u093F\u0932\u0947\u0902', '/m/04_sv'), (0, _defineProperty3.default)(_jsonall, '\u0922\u094B\u0928\u0947\u0935\u093E\u0932\u0947\u091F\u094D\u0930\u0915\u094B\u0902', '/m/0cvq3'), (0, _defineProperty3.default)(_jsonall, '\u0935\u093E\u0923\u093F\u091C\u094D\u092F\u093F\u0915\u091F\u094D\u0930\u0915', '/m/0fkwjg'), (0, _defineProperty3.default)(_jsonall, '\u0928\u094C\u0915\u093E\u0913\u0902', '/m/019jd'), (0, _defineProperty3.default)(_jsonall, 'limousines', '/m/01lcw4'), (0, _defineProperty3.default)(_jsonall, '\u091F\u0948\u0915\u094D\u0938\u0940', '/m/0pg52'), (0, _defineProperty3.default)(_jsonall, '\u0938\u094D\u0915\u0942\u0932\u092C\u0938', '/m/02yvhj'), (0, _defineProperty3.default)(_jsonall, '\u092C\u0938', '/m/01bjv'), (0, _defineProperty3.default)(_jsonall, '\u0928\u093F\u0930\u094D\u092E\u093E\u0923\u0935\u093E\u0939\u0928', '/m/02gx17'), (0, _defineProperty3.default)(_jsonall, '\u092E\u0942\u0930\u094D\u0924\u093F\u092F\u094B\u0902', '/m/013_1c'), (0, _defineProperty3.default)(_jsonall, '\u092B\u0935\u094D\u0935\u093E\u0930\u0947', '/m/0h8lhkg'), (0, _defineProperty3.default)(_jsonall, '\u092A\u0941\u0932', '/m/015kr'), (0, _defineProperty3.default)(_jsonall, '\u0918\u093E\u091F', '/m/01phq4'), (0, _defineProperty3.default)(_jsonall, '\u0917\u0917\u0928\u091A\u0941\u0902\u092C\u0940\u0907\u092E\u093E\u0930\u0924', '/m/079cl'), (0, _defineProperty3.default)(_jsonall, '\u0938\u094D\u0924\u0902\u092D\u092F\u093E\u0938\u094D\u0924\u0902\u092D', '/m/01_m7'), (0, _defineProperty3.default)(_jsonall, '\u0930\u0902\u0917\u0940\u0928\u0915\u093E\u0902\u091A', '/m/011y23'), (0, _defineProperty3.default)(_jsonall, '\u092E\u0915\u093E\u0928', '/m/03jm5'), (0, _defineProperty3.default)(_jsonall, '\u0905\u092A\u093E\u0930\u094D\u091F\u092E\u0947\u0902\u091F\u0907\u092E\u093E\u0930\u0924', '/m/01nblt'), (0, _defineProperty3.default)(_jsonall, '\u0932\u093E\u0907\u091F\u0939\u093E\u0909\u0938', '/m/04h7h'), (0, _defineProperty3.default)(_jsonall, '\u0930\u0947\u0932\u0935\u0947\u0938\u094D\u091F\u0947\u0936\u0928', '/m/0py27'), (0, _defineProperty3.default)(_jsonall, '\u090F\u0915\u091B\u092A\u094D\u092A\u0930', '/m/01n6fd'), (0, _defineProperty3.default)(_jsonall, '\u0905\u0917\u094D\u0928\u093F\u0939\u093E\u0907\u0921\u094D\u0930\u0947\u0902\u091F', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, '\u092C\u093F\u0932\u092C\u094B\u0930\u094D\u0921', '/m/01knjb'), (0, _defineProperty3.default)(_jsonall, '\u0938\u0921\u093C\u0915\u0947\u0902', '/m/06gfj'), (0, _defineProperty3.default)(_jsonall, '\u0915\u094D\u0930\u0949\u0938\u0935\u0949\u0915', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, '\u092F\u093E\u0924\u093E\u092F\u093E\u0924\u092C\u0924\u094D\u0924\u093F\u092F\u093E', '/m/015qff'), (0, _defineProperty3.default)(_jsonall, '\u0917\u0948\u0930\u0947\u091C\u0915\u0947\u0926\u0930\u0935\u093E\u091C\u0947', '/m/08l941'), (0, _defineProperty3.default)(_jsonall, '\u092C\u0938\u0930\u0942\u0915\u0928\u0947\u0915\u0940\u091C\u0917\u0939', '/m/01jw_1'), (0, _defineProperty3.default)(_jsonall, '\u091F\u094D\u0930\u0948\u092B\u093F\u0915\u0915\u094B\u0928\u0938', '/m/03sy7v'), (0, _defineProperty3.default)(_jsonall, '\u092A\u093E\u0930\u094D\u0915\u093F\u0902\u0917\u092E\u0940\u091F\u0930', '/m/015qbp'), (0, _defineProperty3.default)(_jsonall, '\u0938\u0940\u0922\u093C\u093F\u092F\u093E\u0902', '/m/01lynh'), (0, _defineProperty3.default)(_jsonall, '\u091A\u093F\u092E\u0928\u093F\u092F\u093E\u0902', '/m/01jk_4'), (0, _defineProperty3.default)(_jsonall, '\u091F\u094D\u0930\u0948\u0915\u094D\u091F\u0930', '/m/013xlm'), (0, _defineProperty3.default)(_jsonall, '\u0905\u0917\u094D\u0928\u093F\u0936\u093E\u092E\u0915\u0939\u093E\u0908\u0921\u094D\u0930\u0947\u0902\u091F', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, '\u092A\u0948\u0926\u0932\u092A\u093E\u0930\u092A\u0925', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, '\u091F\u094D\u0930\u0948\u092B\u093C\u093F\u0915\u0932\u093E\u0907\u091F', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, '\u092A\u0941\u0932\u094B\u0902', '/m/015kr'), (0, _defineProperty3.default)(_jsonall, '\u0938\u0940\u095D\u093F\u092F\u094B\u0902', '/m/01lynh'), (0, _defineProperty3.default)(_jsonall, '\u092A\u0939\u093E\u0921\u093C\u092F\u093E\u092A\u0939\u093E\u0921\u093C\u0940', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, '\u0935\u093E\u0939\u0928', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, '\u092E\u094B\u091F\u0930\u0938\u093E\u0907\u0915\u0932', '/m/04_sv'), (0, _defineProperty3.default)(_jsonall, '\u0938\u093E\u0907\u0915\u0932', '/m/0199g'), (0, _defineProperty3.default)(_jsonall, '\u091A\u093F\u092E\u0928\u0940', '/m/01jk_4'), (0, _defineProperty3.default)(_jsonall, '\u0938\u093E\u0907\u0915\u0932\u094B\u0902', '/m/0199g'), (0, _defineProperty3.default)(_jsonall, 'bergenofheuvels', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, 'stoptekens', '/m/02pv19'), (0, _defineProperty3.default)(_jsonall, 'verkeersborden', '/m/01mqdt'), (0, _defineProperty3.default)(_jsonall, 'planten', '/m/05s2s'), (0, _defineProperty3.default)(_jsonall, 'bomen', '/m/07j7r'), (0, _defineProperty3.default)(_jsonall, 'gras', '/m/08t9c_'), (0, _defineProperty3.default)(_jsonall, 'struiken', '/m/0gqbt'), (0, _defineProperty3.default)(_jsonall, 'cactus', '/m/025_v'), (0, _defineProperty3.default)(_jsonall, 'palmbomen', '/m/0cdl1'), (0, _defineProperty3.default)(_jsonall, 'natuur', '/m/05h0n'), (0, _defineProperty3.default)(_jsonall, 'watervallen', '/m/0j2kx'), (0, _defineProperty3.default)(_jsonall, 'bergen', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, 'heuvels', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, 'waterlichamen', '/m/03ktm1'), (0, _defineProperty3.default)(_jsonall, 'rivieren', '/m/06cnp'), (0, _defineProperty3.default)(_jsonall, 'stranden', '/m/0b3yr'), (0, _defineProperty3.default)(_jsonall, 'zon', '/m/06m_p'), (0, _defineProperty3.default)(_jsonall, 'Maan', '/m/04wv_'), (0, _defineProperty3.default)(_jsonall, 'lucht', '/m/01bqvp'), (0, _defineProperty3.default)(_jsonall, 'voertuigen', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, "auto's", '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, 'fietsen', '/m/0199g'), (0, _defineProperty3.default)(_jsonall, 'motorfietsen', '/m/04_sv'), (0, _defineProperty3.default)(_jsonall, 'pick-uptrucks', '/m/0cvq3'), (0, _defineProperty3.default)(_jsonall, 'commerci\xEBlevrachtwagens', '/m/0fkwjg'), (0, _defineProperty3.default)(_jsonall, 'boten', '/m/019jd'), (0, _defineProperty3.default)(_jsonall, 'limousines', '/m/01lcw4'), (0, _defineProperty3.default)(_jsonall, "taxi's", '/m/0pg52'), (0, _defineProperty3.default)(_jsonall, 'schoolbus', '/m/02yvhj'), (0, _defineProperty3.default)(_jsonall, 'bus', '/m/01bjv'), (0, _defineProperty3.default)(_jsonall, 'bouwvoertuig', '/m/02gx17'), (0, _defineProperty3.default)(_jsonall, 'standbeelden', '/m/013_1c'), (0, _defineProperty3.default)(_jsonall, 'fonteinen', '/m/0h8lhkg'), (0, _defineProperty3.default)(_jsonall, 'brug', '/m/015kr'), (0, _defineProperty3.default)(_jsonall, 'pier', '/m/01phq4'), (0, _defineProperty3.default)(_jsonall, 'wolkenkrabber', '/m/079cl'), (0, _defineProperty3.default)(_jsonall, 'pijlersofkolommen', '/m/01_m7'), (0, _defineProperty3.default)(_jsonall, 'glas-in-lood', '/m/011y23'), (0, _defineProperty3.default)(_jsonall, 'huis', '/m/03jm5'), (0, _defineProperty3.default)(_jsonall, 'eenappartementsgebouw', '/m/01nblt'), (0, _defineProperty3.default)(_jsonall, 'vuurtoren', '/m/04h7h'), (0, _defineProperty3.default)(_jsonall, 'treinstation', '/m/0py27'), (0, _defineProperty3.default)(_jsonall, 'indeasgelegd', '/m/01n6fd'), (0, _defineProperty3.default)(_jsonall, 'brandkraan', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, 'prikbord', '/m/01knjb'), (0, _defineProperty3.default)(_jsonall, 'wegen', '/m/06gfj'), (0, _defineProperty3.default)(_jsonall, 'zebrapaden', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, 'verkeerslichten', '/m/015qff'), (0, _defineProperty3.default)(_jsonall, 'garagedeuren', '/m/08l941'), (0, _defineProperty3.default)(_jsonall, 'busstopt', '/m/01jw_1'), (0, _defineProperty3.default)(_jsonall, 'verkeerskegels', '/m/03sy7v'), (0, _defineProperty3.default)(_jsonall, 'parkeermeters', '/m/015qbp'), (0, _defineProperty3.default)(_jsonall, 'trap', '/m/01lynh'), (0, _defineProperty3.default)(_jsonall, 'schoorstenen', '/m/01jk_4'), (0, _defineProperty3.default)(_jsonall, 'tractoren', '/m/013xlm'), (0, _defineProperty3.default)(_jsonall, 'eenbrandkraan', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, 'trappen', '/m/01lynh'), (0, _defineProperty3.default)(_jsonall, 'eenbrandkraan', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, 'oversteekplaatsen', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, 'bussen', '/m/01bjv'), (0, _defineProperty3.default)(_jsonall, 'bussen', '/m/01bjv'), (0, _defineProperty3.default)(_jsonall, 'bruggen', '/m/015kr'), (0, _defineProperty3.default)(_jsonall, 'gunungataubukit', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, 'tandaberhenti', '/m/02pv19'), (0, _defineProperty3.default)(_jsonall, 'rambujalan', '/m/01mqdt'), (0, _defineProperty3.default)(_jsonall, 'tanaman', '/m/05s2s'), (0, _defineProperty3.default)(_jsonall, 'pohon', '/m/07j7r'), (0, _defineProperty3.default)(_jsonall, 'rumput', '/m/08t9c_'), (0, _defineProperty3.default)(_jsonall, 'semakbelukar', '/m/0gqbt'), (0, _defineProperty3.default)(_jsonall, 'kaktus', '/m/025_v'), (0, _defineProperty3.default)(_jsonall, 'pohon-pohonpalem', '/m/0cdl1'), (0, _defineProperty3.default)(_jsonall, 'alam', '/m/05h0n'), (0, _defineProperty3.default)(_jsonall, 'airterjun', '/m/0j2kx'), (0, _defineProperty3.default)(_jsonall, 'pegunungan', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, 'bukit', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, 'badanair', '/m/03ktm1'), (0, _defineProperty3.default)(_jsonall, 'sungai', '/m/06cnp'), (0, _defineProperty3.default)(_jsonall, 'pantai', '/m/0b3yr'), (0, _defineProperty3.default)(_jsonall, 'matahari', '/m/06m_p'), (0, _defineProperty3.default)(_jsonall, 'Bulan', '/m/04wv_'), (0, _defineProperty3.default)(_jsonall, 'langit', '/m/01bqvp'), (0, _defineProperty3.default)(_jsonall, 'kendaraan', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, 'mobil', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, 'sepeda', '/m/0199g'), (0, _defineProperty3.default)(_jsonall, 'sepedamotor', '/m/04_sv'), (0, _defineProperty3.default)(_jsonall, 'trukpickup', '/m/0cvq3'), (0, _defineProperty3.default)(_jsonall, 'trukkomersial', '/m/0fkwjg'), (0, _defineProperty3.default)(_jsonall, 'perahu', '/m/019jd'), (0, _defineProperty3.default)(_jsonall, 'limusin', '/m/01lcw4'), (0, _defineProperty3.default)(_jsonall, 'taksi', '/m/0pg52'), (0, _defineProperty3.default)(_jsonall, 'bussekolah', '/m/02yvhj'), (0, _defineProperty3.default)(_jsonall, 'bis', '/m/01bjv'), (0, _defineProperty3.default)(_jsonall, 'kendaraankonstruksi', '/m/02gx17'), (0, _defineProperty3.default)(_jsonall, 'patung', '/m/013_1c'), (0, _defineProperty3.default)(_jsonall, 'airmancur', '/m/0h8lhkg'), (0, _defineProperty3.default)(_jsonall, 'menjembatani', '/m/015kr'), (0, _defineProperty3.default)(_jsonall, 'dermaga', '/m/01phq4'), (0, _defineProperty3.default)(_jsonall, 'gedungpencakarlangit', '/m/079cl'), (0, _defineProperty3.default)(_jsonall, 'pilarataukolom', '/m/01_m7'), (0, _defineProperty3.default)(_jsonall, 'kacaberwarna', '/m/011y23'), (0, _defineProperty3.default)(_jsonall, 'rumah', '/m/03jm5'), (0, _defineProperty3.default)(_jsonall, 'sebuahgedungapartemen', '/m/01nblt'), (0, _defineProperty3.default)(_jsonall, 'rumahcahaya', '/m/04h7h'), (0, _defineProperty3.default)(_jsonall, 'Stasiunkereta', '/m/0py27'), (0, _defineProperty3.default)(_jsonall, 'pucat', '/m/01n6fd'), (0, _defineProperty3.default)(_jsonall, 'pemadamkebakaran', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, 'papanreklame', '/m/01knjb'), (0, _defineProperty3.default)(_jsonall, 'jalan', '/m/06gfj'), (0, _defineProperty3.default)(_jsonall, 'penyeberangan', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, 'lampulalulintas', '/m/015qff'), (0, _defineProperty3.default)(_jsonall, 'pintugarasi', '/m/08l941'), (0, _defineProperty3.default)(_jsonall, 'haltebus', '/m/01jw_1'), (0, _defineProperty3.default)(_jsonall, 'kerucutlalulintas', '/m/03sy7v'), (0, _defineProperty3.default)(_jsonall, 'meteranparkir', '/m/015qbp'), (0, _defineProperty3.default)(_jsonall, 'tangga', '/m/01lynh'), (0, _defineProperty3.default)(_jsonall, 'cerobong', '/m/01jk_4'), (0, _defineProperty3.default)(_jsonall, 'traktor', '/m/013xlm'), (0, _defineProperty3.default)(_jsonall, 'hidrankebakaran', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, 'jembatan', '/m/015kr'), (0, _defineProperty3.default)(_jsonall, 'zebracross', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, 'motor', '/m/04_sv'), (0, _defineProperty3.default)(_jsonall, 'cerobongasap', '/m/01jk_4'), (0, _defineProperty3.default)(_jsonall, 'pohonpalem', '/m/0cdl1'), (0, _defineProperty3.default)(_jsonall, 'montanhasoucolinas', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, 'sinaisdeparada', '/m/02pv19'), (0, _defineProperty3.default)(_jsonall, 'Sinaisdetransito', '/m/01mqdt'), (0, _defineProperty3.default)(_jsonall, 'plantas', '/m/05s2s'), (0, _defineProperty3.default)(_jsonall, '\xE1rvores', '/m/07j7r'), (0, _defineProperty3.default)(_jsonall, 'Relva', '/m/08t9c_'), (0, _defineProperty3.default)(_jsonall, 'arbustos', '/m/0gqbt'), (0, _defineProperty3.default)(_jsonall, 'cacto', '/m/025_v'), (0, _defineProperty3.default)(_jsonall, 'Palmeiras', '/m/0cdl1'), (0, _defineProperty3.default)(_jsonall, 'natureza', '/m/05h0n'), (0, _defineProperty3.default)(_jsonall, 'cachoeiras', '/m/0j2kx'), (0, _defineProperty3.default)(_jsonall, 'montanhas', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, 'Colinas', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, 'corposde\xE1gua', '/m/03ktm1'), (0, _defineProperty3.default)(_jsonall, 'rios', '/m/06cnp'), (0, _defineProperty3.default)(_jsonall, 'praias', '/m/0b3yr'), (0, _defineProperty3.default)(_jsonall, 'sol', '/m/06m_p'), (0, _defineProperty3.default)(_jsonall, 'Lua', '/m/04wv_'), (0, _defineProperty3.default)(_jsonall, 'c\xE9u', '/m/01bqvp'), (0, _defineProperty3.default)(_jsonall, 've\xEDculos', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, 'carros', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, 'bicicletas', '/m/0199g'), (0, _defineProperty3.default)(_jsonall, 'motocicletas', '/m/04_sv'), (0, _defineProperty3.default)(_jsonall, 'Caminh\xF5es', '/m/0cvq3'), (0, _defineProperty3.default)(_jsonall, 'caminh\xF5escomerciais', '/m/0fkwjg'), (0, _defineProperty3.default)(_jsonall, 'barcos', '/m/019jd'), (0, _defineProperty3.default)(_jsonall, 'limusines', '/m/01lcw4'), (0, _defineProperty3.default)(_jsonall, 'T\xE1xis', '/m/0pg52'), (0, _defineProperty3.default)(_jsonall, '\xF4nibusescolar', '/m/02yvhj'), (0, _defineProperty3.default)(_jsonall, '\xF4nibus', '/m/01bjv'), (0, _defineProperty3.default)(_jsonall, 've\xEDculodeconstru\xE7\xE3o', '/m/02gx17'), (0, _defineProperty3.default)(_jsonall, 'est\xE1tuas', '/m/013_1c'), (0, _defineProperty3.default)(_jsonall, 'fontes', '/m/0h8lhkg'), (0, _defineProperty3.default)(_jsonall, 'Ponte', '/m/015kr'), (0, _defineProperty3.default)(_jsonall, 'cais', '/m/01phq4'), (0, _defineProperty3.default)(_jsonall, 'arranha-céu', '/m/079cl'), (0, _defineProperty3.default)(_jsonall, 'pilaresoucolunas', '/m/01_m7'), (0, _defineProperty3.default)(_jsonall, 'vitrais', '/m/011y23'), (0, _defineProperty3.default)(_jsonall, 'lar', '/m/03jm5'), (0, _defineProperty3.default)(_jsonall, 'umpr\xE9diodeapartamentos', '/m/01nblt'), (0, _defineProperty3.default)(_jsonall, 'casadeluz', '/m/04h7h'), (0, _defineProperty3.default)(_jsonall, 'esta\xE7\xE3odetrem', '/m/0py27'), (0, _defineProperty3.default)(_jsonall, 'cinza', '/m/01n6fd'), (0, _defineProperty3.default)(_jsonall, 'hidrante', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, 'quadrodeavisos', '/m/01knjb'), (0, _defineProperty3.default)(_jsonall, 'estradas', '/m/06gfj'), (0, _defineProperty3.default)(_jsonall, 'faixasdepedestres', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, 'luzesdetr\xE2nsito', '/m/015qff'), (0, _defineProperty3.default)(_jsonall, 'portasdegaragem', '/m/08l941'), (0, _defineProperty3.default)(_jsonall, 'pontode\xF4nibus', '/m/01jw_1'), (0, _defineProperty3.default)(_jsonall, 'Conesdetr\xE1fego', '/m/03sy7v'), (0, _defineProperty3.default)(_jsonall, 'parqu\xEDmetros', '/m/015qbp'), (0, _defineProperty3.default)(_jsonall, 'escadaria', '/m/01lynh'), (0, _defineProperty3.default)(_jsonall, 'chamin\xE9s', '/m/01jk_4'), (0, _defineProperty3.default)(_jsonall, 'tratores', '/m/013xlm'), (0, _defineProperty3.default)(_jsonall, 'escadas', '/m/01lynh'), (0, _defineProperty3.default)(_jsonall, 'faixasdepedestre', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, 'palmeiras', '/m/0cdl1'), (0, _defineProperty3.default)(_jsonall, 'umhidrante', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, 'pontes', '/m/015kr'), (0, _defineProperty3.default)(_jsonall, 't\xE1xis', '/m/0pg52'), (0, _defineProperty3.default)(_jsonall, 'hidrantes', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, 'hidrantes', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, 'n\xFAiho\u1EB7c\u0111\u1ED3i', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, '\u0111i\u1EC3md\u1EEBng', '/m/02pv19'), (0, _defineProperty3.default)(_jsonall, '\u0111\u01B0\u1EDDngph\u1ED1', '/m/01mqdt'), (0, _defineProperty3.default)(_jsonall, 'c\xE2y', '/m/07j7r'), (0, _defineProperty3.default)(_jsonall, 'b\xE3ic\u1ECF', '/m/08t9c_'), (0, _defineProperty3.default)(_jsonall, 'c\xE2yb\u1EE5i', '/m/0gqbt'), (0, _defineProperty3.default)(_jsonall, 'c\xE2yx\u01B0\u01A1ngr\u1ED3ng', '/m/025_v'), (0, _defineProperty3.default)(_jsonall, 'c\xE2yc\u1ECD', '/m/0cdl1'), (0, _defineProperty3.default)(_jsonall, 'Thi\xEAnnhi\xEAn', '/m/05h0n'), (0, _defineProperty3.default)(_jsonall, 'th\xE1cn\u01B0\u1EDBc', '/m/0j2kx'), (0, _defineProperty3.default)(_jsonall, 'n\xFAinon', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, '\u0111\u1ED3in\xFAi', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, 'ngu\u1ED3nn\u01B0\u1EDBc', '/m/03ktm1'), (0, _defineProperty3.default)(_jsonall, 's\xF4ng', '/m/06cnp'), (0, _defineProperty3.default)(_jsonall, 'b\xE3ibi\u1EC3n', '/m/0b3yr'), (0, _defineProperty3.default)(_jsonall, 'm\u1EB7ttr\u1EDDi', '/m/06m_p'), (0, _defineProperty3.default)(_jsonall, 'M\u1EB7ttr\u0103ng', '/m/04wv_'), (0, _defineProperty3.default)(_jsonall, 'b\u1EA7utr\u1EDDi', '/m/01bqvp'), (0, _defineProperty3.default)(_jsonall, 'xec\u1ED9', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, '\xF4t\xF4', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, 'xe\u0111\u1EA1p', '/m/0199g'), (0, _defineProperty3.default)(_jsonall, 'xem\xE1y', '/m/04_sv'), (0, _defineProperty3.default)(_jsonall, 'xeb\xE1nt\u1EA3i', '/m/0cvq3'), (0, _defineProperty3.default)(_jsonall, 'xet\u1EA3ith\u01B0\u01A1ngm\u1EA1i', '/m/0fkwjg'), (0, _defineProperty3.default)(_jsonall, 'thuy\u1EC1n', '/m/019jd'), (0, _defineProperty3.default)(_jsonall, 'xelimousine', '/m/01lcw4'), (0, _defineProperty3.default)(_jsonall, 'taxi', '/m/0pg52'), (0, _defineProperty3.default)(_jsonall, 'xebu\xFDtc\u1EE7atr\u01B0\u1EDDng', '/m/02yvhj'), (0, _defineProperty3.default)(_jsonall, 'xebu\xFDt', '/m/01bjv'), (0, _defineProperty3.default)(_jsonall, 'xex\xE2yd\u1EF1ng', '/m/02gx17'), (0, _defineProperty3.default)(_jsonall, 'nh\u1EEFngb\u1EE9ct\u01B0\u1EE3ng', '/m/013_1c'), (0, _defineProperty3.default)(_jsonall, '\u0111\xE0iphunn\u01B0\u1EDBc', '/m/0h8lhkg'), (0, _defineProperty3.default)(_jsonall, 'c\u1EA7u', '/m/015kr'), (0, _defineProperty3.default)(_jsonall, '\u0111\xEA', '/m/01phq4'), (0, _defineProperty3.default)(_jsonall, 't\xF2anh\xE0ch\u1ECDctr\u1EDDi', '/m/079cl'), (0, _defineProperty3.default)(_jsonall, 'c\u1ED9ttr\u1EE5', '/m/01_m7'), (0, _defineProperty3.default)(_jsonall, 'k\xEDnhm\xE0u', '/m/011y23'), (0, _defineProperty3.default)(_jsonall, 'nh\xE0\u1EDF', '/m/03jm5'), (0, _defineProperty3.default)(_jsonall, 't\xF2anh\xE0chungc\u01B0', '/m/01nblt'), (0, _defineProperty3.default)(_jsonall, 'ng\xF4inh\xE0\xE1nhs\xE1ng', '/m/04h7h'), (0, _defineProperty3.default)(_jsonall, 'gaxel\u1EEDa', '/m/0py27'), (0, _defineProperty3.default)(_jsonall, 'trot\xE0n', '/m/01n6fd'), (0, _defineProperty3.default)(_jsonall, 'afirehydrant', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, 'abillboard', '/m/01knjb'), (0, _defineProperty3.default)(_jsonall, 'nh\u1EEFngcon\u0111\u01B0\u1EDDng', '/m/06gfj'), (0, _defineProperty3.default)(_jsonall, 'b\u0103ngqua\u0111\u01B0\u1EDDng', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, '\u0111\xE8ngiaoth\xF4ng', '/m/015qff'), (0, _defineProperty3.default)(_jsonall, 'nh\xE0\u0111\u1EC3xe', '/m/08l941'), (0, _defineProperty3.default)(_jsonall, 'tr\u1EA1md\u1EEBngxebu\xFDt', '/m/01jw_1'), (0, _defineProperty3.default)(_jsonall, 'giaoth\xF4ng', '/m/03sy7v'), (0, _defineProperty3.default)(_jsonall, '\u0111\u1ED3ngh\u1ED3\u0111\u1ED7xe', '/m/015qbp'), (0, _defineProperty3.default)(_jsonall, 'c\u1EA7uthang', '/m/01lynh'), (0, _defineProperty3.default)(_jsonall, '\u1ED1ngkh\xF3i', '/m/01jk_4'), (0, _defineProperty3.default)(_jsonall, 'm\xE1yk\xE9o', '/m/013xlm'), (0, _defineProperty3.default)(_jsonall, 'v\u1EA1chqua\u0111\u01B0\u1EDDng', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, 'xeh\u01A1i', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, 'tr\u1EE5c\u1EA5pn\u01B0\u1EDBcch\u1EEFach\xE1y', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, 'v\xF2il\u1EA5yn\u01B0\u1EDBcch\u1EEFach\xE1y', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, 'xeg\u1EAFnm\xE1y', '/m/04_sv'), (0, _defineProperty3.default)(_jsonall, 'bundokoburol', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, 'stopsigns', '/m/02pv19'), (0, _defineProperty3.default)(_jsonall, 'Tandangmgakalye', '/m/01mqdt'), (0, _defineProperty3.default)(_jsonall, 'halaman', '/m/05s2s'), (0, _defineProperty3.default)(_jsonall, 'mgapuno', '/m/07j7r'), (0, _defineProperty3.default)(_jsonall, 'damo', '/m/08t9c_'), (0, _defineProperty3.default)(_jsonall, 'mgapalumpong', '/m/0gqbt'), (0, _defineProperty3.default)(_jsonall, 'cactus', '/m/025_v'), (0, _defineProperty3.default)(_jsonall, 'mgapunongpalma', '/m/0cdl1'), (0, _defineProperty3.default)(_jsonall, 'kalikasan', '/m/05h0n'), (0, _defineProperty3.default)(_jsonall, 'talon', '/m/0j2kx'), (0, _defineProperty3.default)(_jsonall, 'mgabundok', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, 'mgaburol', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, 'anyongtubig', '/m/03ktm1'), (0, _defineProperty3.default)(_jsonall, 'mgailog', '/m/06cnp'), (0, _defineProperty3.default)(_jsonall, 'mgabeach', '/m/0b3yr'), (0, _defineProperty3.default)(_jsonall, 'Araw', '/m/06m_p'), (0, _defineProperty3.default)(_jsonall, 'Buwan', '/m/04wv_'), (0, _defineProperty3.default)(_jsonall, 'langit', '/m/01bqvp'), (0, _defineProperty3.default)(_jsonall, 'mgasasakyan', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, 'mgabisikleta', '/m/0199g'), (0, _defineProperty3.default)(_jsonall, 'mgamotorsiklo', '/m/04_sv'), (0, _defineProperty3.default)(_jsonall, 'mgapickuptruck', '/m/0cvq3'), (0, _defineProperty3.default)(_jsonall, 'mgakomersyalnatrak', '/m/0fkwjg'), (0, _defineProperty3.default)(_jsonall, 'mgabangka', '/m/019jd'), (0, _defineProperty3.default)(_jsonall, 'mgalimousine', '/m/01lcw4'), (0, _defineProperty3.default)(_jsonall, 'mgataxi', '/m/0pg52'), (0, _defineProperty3.default)(_jsonall, 'busngeskwelahan', '/m/02yvhj'), (0, _defineProperty3.default)(_jsonall, 'bus', '/m/01bjv'), (0, _defineProperty3.default)(_jsonall, 'sasakyangpang-konstruksyon', '/m/02gx17'), (0, _defineProperty3.default)(_jsonall, 'mgaestatwa', '/m/013_1c'), (0, _defineProperty3.default)(_jsonall, 'mgafountain', '/m/0h8lhkg'), (0, _defineProperty3.default)(_jsonall, 'tulay', '/m/015kr'), (0, _defineProperty3.default)(_jsonall, 'pier', '/m/01phq4'), (0, _defineProperty3.default)(_jsonall, 'napakataasnagusali', '/m/079cl'), (0, _defineProperty3.default)(_jsonall, 'mgahaligiohaligi', '/m/01_m7'), (0, _defineProperty3.default)(_jsonall, 'minantsahangsalamin', '/m/011y23'), (0, _defineProperty3.default)(_jsonall, 'bahay', '/m/03jm5'), (0, _defineProperty3.default)(_jsonall, 'gusalingisangapartment', '/m/01nblt'), (0, _defineProperty3.default)(_jsonall, 'ilawnabahay', '/m/04h7h'), (0, _defineProperty3.default)(_jsonall, 'istasyonngtren', '/m/0py27'), (0, _defineProperty3.default)(_jsonall, 'abo', '/m/01n6fd'), (0, _defineProperty3.default)(_jsonall, 'afirehydrant', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, 'abillboard', '/m/01knjb'), (0, _defineProperty3.default)(_jsonall, 'mgakalsada', '/m/06gfj'), (0, _defineProperty3.default)(_jsonall, 'mgatawiran', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, 'ilawtrapiko', '/m/015qff'), (0, _defineProperty3.default)(_jsonall, 'mgagarageddoor', '/m/08l941'), (0, _defineProperty3.default)(_jsonall, 'hintuanngbus', '/m/01jw_1'), (0, _defineProperty3.default)(_jsonall, 'mgatrafficcone', '/m/03sy7v'), (0, _defineProperty3.default)(_jsonall, 'metrongparadahan', '/m/015qbp'), (0, _defineProperty3.default)(_jsonall, 'hagdan', '/m/01lynh'), (0, _defineProperty3.default)(_jsonall, 'mgatsimenea', '/m/01jk_4'), (0, _defineProperty3.default)(_jsonall, 'mgatraktora', '/m/013xlm'), (0, _defineProperty3.default)(_jsonall, 'mgacrosswalk', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, 'mgailaw-trapiko', '/m/015qff'), (0, _defineProperty3.default)(_jsonall, 'firehydrant', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, 'mgakotse', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, 'mgachimney', '/m/01jk_4'), (0, _defineProperty3.default)(_jsonall, 'mgapalmtree', '/m/0cdl1'), (0, _defineProperty3.default)(_jsonall, 'mgahagdan', '/m/01lynh'), (0, _defineProperty3.default)(_jsonall, 'mgabus', '/m/01bjv'), (0, _defineProperty3.default)(_jsonall, 'mgafirehydrant', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, 'mgatulay', '/m/015kr'), (0, _defineProperty3.default)(_jsonall, '\u0E9E\u0EB9\u0EC0\u0E82\u0EBB\u0EB2\u0EAB\u0EBC\u0EB7\u0EC0\u0E99\u0EB5\u0E99\u0E9E\u0EB9', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, '\u0E9B\u0EC9\u0EB2\u0E8D\u0EA2\u0EB8\u0E94', '/m/02pv19'), (0, _defineProperty3.default)(_jsonall, '\u0E9B\u0EC9\u0EB2\u0E8D\u0E96\u0EB0\u0EDC\u0EBB\u0E99', '/m/01mqdt'), (0, _defineProperty3.default)(_jsonall, '\u0E9E\u0EB7\u0E94', '/m/05s2s'), (0, _defineProperty3.default)(_jsonall, '\u0E95\u0EBB\u0EC9\u0E99\u0EC4\u0EA1\u0EC9', '/m/07j7r'), (0, _defineProperty3.default)(_jsonall, '\u0EAB\u0E8D\u0EC9\u0EB2', '/m/08t9c_'), (0, _defineProperty3.default)(_jsonall, '\u0EC4\u0EA1\u0EC9\u0E9E\u0EB8\u0EC8\u0EA1', '/m/0gqbt'), (0, _defineProperty3.default)(_jsonall, '\u0E81\u0EB0\u0E97\u0EBD\u0EA1', '/m/025_v'), (0, _defineProperty3.default)(_jsonall, '\u0EC4\u0EA1\u0EC9\u200B\u0EA2\u0EB7\u0E99\u200B\u0E95\u0EBB\u0EC9\u0E99\u200B\u0E9B\u0EB2\u0EA1', '/m/0cdl1'), (0, _defineProperty3.default)(_jsonall, '\u0E97\u0ECD\u0EB2\u0EA1\u0EB0\u0E8A\u0EB2\u0E94', '/m/05h0n'), (0, _defineProperty3.default)(_jsonall, '\u0E99\u0EC9\u0EB3\u0E95\u0EBB\u0E81\u0E95\u0EB2\u0E94', '/m/0j2kx'), (0, _defineProperty3.default)(_jsonall, '\u0E9E\u0EB9\u0EC0\u0E82\u0EBB\u0EB2', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, '\u0EC0\u0E99\u0EB5\u0E99\u200B\u0E9E\u0EB9', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, '\u0EAE\u0EC8\u0EB2\u0E87\u0E81\u0EB2\u0E8D\u0E82\u0EAD\u0E87\u0E99\u0EC9\u0ECD\u0EB2', '/m/03ktm1'), (0, _defineProperty3.default)(_jsonall, '\u0EC1\u0EA1\u0EC8\u0E99\u0EC9\u0EB3', '/m/06cnp'), (0, _defineProperty3.default)(_jsonall, '\u0EAB\u0EB2\u0E94\u0E8A\u0EB2\u0E8D', '/m/0b3yr'), (0, _defineProperty3.default)(_jsonall, '\u0E95\u0EB2\u0EC0\u0EA7\u0EB1\u0E99', '/m/06m_p'), (0, _defineProperty3.default)(_jsonall, '\u0E94\u0EA7\u0E87\u0E88\u0EB1\u0E99', '/m/04wv_'), (0, _defineProperty3.default)(_jsonall, '\u0E97\u0EAD\u0E87\u0E9F\u0EC9\u0EB2', '/m/01bqvp'), (0, _defineProperty3.default)(_jsonall, '\u0E9E\u0EB2\u0EAB\u0EB0\u0E99\u0EB0', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, '\u0EA5\u0EBB\u0E94', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, '\u0EA5\u0EBB\u0E94\u0E96\u0EB5\u0E9A', '/m/0199g'), (0, _defineProperty3.default)(_jsonall, '\u0EA5\u0EBB\u0E94\u0E88\u0EB1\u0E81', '/m/04_sv'), (0, _defineProperty3.default)(_jsonall, '\u0EA5\u0EBB\u0E94\u0E81\u0EB0\u0E9A\u0EB0', '/m/0cvq3'), (0, _defineProperty3.default)(_jsonall, '\u0EA5\u0EBB\u0E94\u0E9A\u0EB1\u0E99\u0E97\u0EB8\u0E81\u0E81\u0EB2\u0E99\u0E84\u0EC9\u0EB2', '/m/0fkwjg'), (0, _defineProperty3.default)(_jsonall, '\u0EC0\u0EAE\u0EB7\u0EAD', '/m/019jd'), (0, _defineProperty3.default)(_jsonall, '\u0EA5\u0EBB\u0E94\u0EA5\u0EB5\u0EA1\u0EB9\u0E8A\u0EB5\u0E99', '/m/01lcw4'), (0, _defineProperty3.default)(_jsonall, '\u0EC1\u0E97\u0EB1\u0E81\u0E8A\u0EB5', '/m/0pg52'), (0, _defineProperty3.default)(_jsonall, '\u0EA5\u0EBB\u0E94\u200B\u0EC0\u0EA1\u200B\u0EC2\u0EAE\u0E87\u200B\u0EAE\u0EBD\u0E99', '/m/02yvhj'), (0, _defineProperty3.default)(_jsonall, '\u0EA5\u0EBB\u0E94\u0EC0\u0EA1', '/m/01bjv'), (0, _defineProperty3.default)(_jsonall, '\u0E9E\u0EB2\u0EAB\u0EB0\u0E99\u0EB0\u0E81\u0ECD\u0EC8\u0EAA\u0EC9\u0EB2\u0E87', '/m/02gx17'), (0, _defineProperty3.default)(_jsonall, '\u0EAE\u0EB9\u0E9A\u0E9B\u0EB1\u0EC9\u0E99', '/m/013_1c'), (0, _defineProperty3.default)(_jsonall, '\u0E99\u0EC9\u0EB3\u0E9E\u0EB8', '/m/0h8lhkg'), (0, _defineProperty3.default)(_jsonall, '\u0E82\u0EBB\u0EA7', '/m/015kr'), (0, _defineProperty3.default)(_jsonall, '\u0E97\u0EC8\u0EB2\u0EC0\u0EAE\u0EB7\u0EAD', '/m/01phq4'), (0, _defineProperty3.default)(_jsonall, '\u0E95\u0EB6\u0E81\u0EAA\u0EB9\u0E87', '/m/079cl'), (0, _defineProperty3.default)(_jsonall, '\u0E96\u0EB1\u0E99\u0EC0\u0EAA\u0EBB\u0EB2', '/m/01_m7'), (0, _defineProperty3.default)(_jsonall, '\u0EC1\u0E81\u0EC9\u0EA7\u0EAA\u0EB5', '/m/011y23'), (0, _defineProperty3.default)(_jsonall, '\u0EC0\u0EAE\u0EB7\u0EAD\u0E99', '/m/03jm5'), (0, _defineProperty3.default)(_jsonall, '\u0E95\u0EB6\u0E81\u0EAD\u0EB2\u0E9E\u0EB2\u0E94\u0EC0\u0EA1\u0EB1\u0E99', '/m/01nblt'), (0, _defineProperty3.default)(_jsonall, '\u0EC0\u0EAE\u0EB7\u0EAD\u0E99\u0EC1\u0EAA\u0E87\u0EAA\u0EB0\u0EAB\u0EA7\u0EC8\u0EB2\u0E87', '/m/04h7h'), (0, _defineProperty3.default)(_jsonall, '\u0EAA\u0EB0\u0E96\u0EB2\u0E99\u0EB5\u0EA5\u0EBB\u0E94\u0EC4\u0E9F', '/m/0py27'), (0, _defineProperty3.default)(_jsonall, '\u0E82\u0EB5\u0EC9\u0EC0\u0E97\u0EBB\u0EC8\u0EB2', '/m/01n6fd'), (0, _defineProperty3.default)(_jsonall, '\u0E99\u0ECD\u0EC9\u0EB2\u0E94\u0EB1\u0E9A\u0EC0\u0E9E\u0EB5\u0E87', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, '\u0E9B\u0EC9\u0EB2\u0E8D\u0EC2\u0E84\u0EAA\u0EB0\u0E99\u0EB2', '/m/01knjb'), (0, _defineProperty3.default)(_jsonall, '\u0E96\u0EB0\u0EDC\u0EBB\u0E99\u0EAB\u0EBB\u0E99\u0E97\u0EB2\u0E87', '/m/06gfj'), (0, _defineProperty3.default)(_jsonall, '\u0E97\u0EB2\u0E87\u0E82\u0EC9\u0EB2\u0EA1', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, '\u0EC4\u0E9F\u200B\u0EAD\u0ECD\u0EB2\u200B\u0E99\u0EB2\u0E94', '/m/015qff'), (0, _defineProperty3.default)(_jsonall, 'garagedoors', '/m/08l941'), (0, _defineProperty3.default)(_jsonall, '\u0E9B\u0EC9\u0EB2\u0E8D\u0EA5\u0EBB\u0E94\u0EC0\u0EA1', '/m/01jw_1'), (0, _defineProperty3.default)(_jsonall, '\u0EC2\u0E84\u0E99\u0E81\u0EB2\u0E99\u0E88\u0EB0\u0EA5\u0EB2\u0E88\u0EAD\u0E99', '/m/03sy7v'), (0, _defineProperty3.default)(_jsonall, '\u0EC1\u0EA1\u0EB1\u0E94\u0E9A\u0EC8\u0EAD\u0E99\u0E88\u0EAD\u0E94\u0EA5\u0EBB\u0E94', '/m/015qbp'), (0, _defineProperty3.default)(_jsonall, '\u0E82\u0EB1\u0EC9\u0E99\u0EC4\u0E94', '/m/01lynh'), (0, _defineProperty3.default)(_jsonall, '\u0E97\u0ECD\u0EC8\u0EC4\u0E9F', '/m/01jk_4'), (0, _defineProperty3.default)(_jsonall, '\u0EA5\u0EBB\u0E94\u0EC4\u0E96\u0E99\u0EB2', '/m/013xlm'), (0, _defineProperty3.default)(_jsonall, '\u0EA5\u0EBB\u0E94\u0EC3\u0EAB\u0E8D\u0EC8', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, '\u0E9E\u0EB9\u0EAB\u0EBC\u0EB7\u0E9C\u0EB2', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, '\u0EA5\u0EBB\u0E94\u0EC3\u0EAB\u0E8D\u0EC8', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, '\u0EC4\u0E9F\u0E88\u0EB0\u0EA5\u0EB2\u0E88\u0EAD\u0E99', '/m/015qff'), (0, _defineProperty3.default)(_jsonall, '\u0E9A\u0EC8\u0EAD\u0E99\u0E82\u0EC9\u0EB2\u0EA1\u0E97\u0EB2\u0E87', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, 'ຫົວ​ສີດ​ນ້ຳ​ດັບ​ເພີງ', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, '\u0E97\u0EB2\u0E87\u0EA1\u0EC9\u0EB2\u0EA5\u0EB2\u0E8D', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, '\u0E95\u0EBB\u0EC9\u0E99\u0E9B\u0EB2\u0EA1', '/m/0cdl1'), (0, _defineProperty3.default)(_jsonall, '\u0E9B\u0EC8\u0EAD\u0E87\u0E84\u0EA7\u0EB1\u0E99\u0EC4\u0E9F', '/m/01jk_4'), (0, _defineProperty3.default)(_jsonall, '\u0EA5\u0EBB\u0E94\u0EC1\u0E97\u0EA3\u0EB1\u0E81\u0EC0\u0E95\u0EB5', '/m/013xlm'), (0, _defineProperty3.default)(_jsonall, '\u0EAB\u0EBB\u0EA7\u0E94\u0EB1\u0E9A\u0EC0\u0E9E\u0EB5\u0E87', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, '\u0EAB\u0EBB\u0EA7\u0E94\u0EB1\u0E9A\u0EC0\u0E9E\u0EB5\u0E87', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, '\u1010\u1031\u102C\u1004\u103A\u1019\u103B\u102C\u1038\u101E\u102D\u102F\u1037\u1019\u101F\u102F\u1010\u103A\u1010\u1031\u102C\u1004\u103A\u1019\u103B\u102C\u1038', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, '\u1019\u103E\u1010\u103A\u1010\u102D\u102F\u1004\u103A\u1019\u103B\u102C\u1038', '/m/02pv19'), (0, _defineProperty3.default)(_jsonall, '\u101C\u1019\u103A\u1038\u1006\u102D\u102F\u1004\u103A\u1038\u1018\u102F\u1010\u103A\u1019\u103B\u102C\u1038', '/m/01mqdt'), (0, _defineProperty3.default)(_jsonall, '\u1021\u1015\u1004\u103A\u1019\u103B\u102C\u1038', '/m/05s2s'), (0, _defineProperty3.default)(_jsonall, '\u101E\u1005\u103A\u1015\u1004\u103A\u1019\u103B\u102C\u1038', '/m/07j7r'), (0, _defineProperty3.default)(_jsonall, '\u1019\u103C\u1000\u103A', '/m/08t9c_'), (0, _defineProperty3.default)(_jsonall, '\u1015\u1031\u102B\u1000\u103A\u1015\u1004\u103A\u1019\u103B\u102C\u1038', '/m/0gqbt'), (0, _defineProperty3.default)(_jsonall, '\u101B\u103E\u102C\u1038\u1005\u1031\u102C\u1004\u103A\u1038', '/m/025_v'), (0, _defineProperty3.default)(_jsonall, '\u1011\u1014\u103A\u1038\u1015\u1004\u103A\u1019\u103B\u102C\u1038', '/m/0cdl1'), (0, _defineProperty3.default)(_jsonall, '\u101E\u1018\u102C\u101D', '/m/05h0n'), (0, _defineProperty3.default)(_jsonall, '\u101B\u1031\u1010\u1036\u1001\u103D\u1014\u103A\u1019\u103B\u102C\u1038', '/m/0j2kx'), (0, _defineProperty3.default)(_jsonall, '\u1010\u1031\u102C\u1004\u103A\u1019\u103B\u102C\u1038', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, '\u1010\u1031\u102C\u1004\u103A\u1010\u103D\u1031', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, '\u101B\u1031\u1010\u103D\u1004\u103A\u1038', '/m/03ktm1'), (0, _defineProperty3.default)(_jsonall, '\u1019\u103C\u1005\u103A\u1019\u103B\u102C\u1038', '/m/06cnp'), (0, _defineProperty3.default)(_jsonall, '\u1000\u1019\u103A\u1038\u1001\u103C\u1031\u1019\u103B\u102C\u1038', '/m/0b3yr'), (0, _defineProperty3.default)(_jsonall, '\u1014\u1031\u1019\u1004\u103A\u1038', '/m/06m_p'), (0, _defineProperty3.default)(_jsonall, '\u1019\u103D\u1014\u103A\u1038', '/m/04wv_'), (0, _defineProperty3.default)(_jsonall, '\u1000\u1031\u102C\u1004\u103A\u1038\u1000\u1004\u103A', '/m/01bqvp'), (0, _defineProperty3.default)(_jsonall, '\u101A\u102C\u1009\u103A\u1019\u103B\u102C\u1038', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, '\u1000\u102C\u1038\u1019\u103B\u102C\u1038', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, '\u1005\u1000\u103A\u1018\u102E\u1038', '/m/0199g'), (0, _defineProperty3.default)(_jsonall, '\u1006\u102D\u102F\u1004\u103A\u1000\u101A\u103A\u1019\u103B\u102C\u1038', '/m/04_sv'), (0, _defineProperty3.default)(_jsonall, '\u1015\u1005\u103A\u1000\u1015\u103A\u1000\u102C\u1038\u1019\u103B\u102C\u1038', '/m/0cvq3'), (0, _defineProperty3.default)(_jsonall, '\u1000\u102F\u1014\u103A\u1010\u1004\u103A\u1000\u102C\u1038\u1019\u103B\u102C\u1038', '/m/0fkwjg'), (0, _defineProperty3.default)(_jsonall, '\u101C\u103E\u1031\u1019\u103B\u102C\u1038', '/m/019jd'), (0, _defineProperty3.default)(_jsonall, '\u1007\u102D\u1019\u103A\u1001\u1036\u1000\u102C\u1038\u1019\u103B\u102C\u1038', '/m/01lcw4'), (0, _defineProperty3.default)(_jsonall, '\u1021\u1004\u103E\u102C\u1038\u101A\u102C\u1009\u103A\u1019\u103B\u102C\u1038', '/m/0pg52'), (0, _defineProperty3.default)(_jsonall, '\u1000\u103B\u1031\u102C\u1004\u103A\u1038\u1000\u102C\u1038', '/m/02yvhj'), (0, _defineProperty3.default)(_jsonall, '\u1018\u1010\u103A\u1005\u103A\u1000\u102C\u1038', '/m/01bjv'), (0, _defineProperty3.default)(_jsonall, '\u1006\u1031\u102C\u1000\u103A\u101C\u102F\u1015\u103A\u101B\u1031\u1038\u101A\u102C\u1009\u103A', '/m/02gx17'), (0, _defineProperty3.default)(_jsonall, '\u101B\u102F\u1015\u103A\u1015\u103D\u102C\u1038\u1010\u1031\u102C\u103A\u1019\u103B\u102C\u1038', '/m/013_1c'), (0, _defineProperty3.default)(_jsonall, '\u1005\u1019\u103A\u1038\u101B\u1031', '/m/0h8lhkg'), (0, _defineProperty3.default)(_jsonall, '\u1010\u1036\u1010\u102C\u1038', '/m/015kr'), (0, _defineProperty3.default)(_jsonall, '\u1006\u102D\u1015\u103A\u1001\u1036', '/m/01phq4'), (0, _defineProperty3.default)(_jsonall, '\u1019\u102D\u102F\u1038\u1019\u103B\u103E\u1031\u102C\u103A\u1010\u102D\u102F\u1000\u103A', '/m/079cl'), (0, _defineProperty3.default)(_jsonall, '\u1010\u102D\u102F\u1004\u103A\u1019\u103B\u102C\u1038', '/m/01_m7'), (0, _defineProperty3.default)(_jsonall, '\u101B\u1031\u102C\u1004\u103A\u1005\u102F\u1036\u1019\u103E\u1014\u103A', '/m/011y23'), (0, _defineProperty3.default)(_jsonall, '\u1021\u102D\u1019\u103A', '/m/03jm5'), (0, _defineProperty3.default)(_jsonall, '\u1010\u102D\u102F\u1000\u103A\u1001\u1014\u103A\u1038\u1021\u1006\u1031\u102C\u1000\u103A\u1021\u1026', '/m/01nblt'), (0, _defineProperty3.default)(_jsonall, '\u1019\u102E\u1038\u1021\u102D\u1019\u103A', '/m/04h7h'), (0, _defineProperty3.default)(_jsonall, '\u1018\u1030\u1010\u102C\u101B\u102F\u1036', '/m/0py27'), (0, _defineProperty3.default)(_jsonall, '\u1015\u103C\u102C', '/m/01n6fd'), (0, _defineProperty3.default)(_jsonall, '\u1019\u102E\u1038\u101E\u1010\u103A\u1006\u1031\u1038\u1018\u1030\u1038', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, '\u1000\u103C\u1031\u102C\u103A\u1004\u103C\u102C\u1018\u102F\u1010\u103A', '/m/01knjb'), (0, _defineProperty3.default)(_jsonall, '\u101C\u1019\u103A\u1038\u1019\u103B\u102C\u1038', '/m/06gfj'), (0, _defineProperty3.default)(_jsonall, '\u101C\u1030\u1000\u1030\u1038\u1019\u103B\u1009\u103A\u1038\u1000\u103C\u102C\u1038\u1019\u103B\u102C\u1038', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, '\u1019\u102E\u1038\u1015\u103D\u102D\u102F\u1004\u1037\u103A', '/m/015qff'), (0, _defineProperty3.default)(_jsonall, '\u1000\u102C\u1038\u1002\u102D\u102F\u1012\u1031\u102B\u1004\u103A\u1019\u103B\u102C\u1038', '/m/08l941'), (0, _defineProperty3.default)(_jsonall, '\u1018\u1010\u103A\u1005\u103A\u1000\u102C\u1038\u1019\u103E\u1010\u103A\u1010\u102D\u102F\u1004\u103A\u1019\u103B\u102C\u1038', '/m/01jw_1'), (0, _defineProperty3.default)(_jsonall, 'trafficcones', '/m/03sy7v'), (0, _defineProperty3.default)(_jsonall, '\u1000\u102C\u1038\u1015\u102B\u1000\u1004\u103A\u1019\u102E\u1010\u102C', '/m/015qbp'), (0, _defineProperty3.default)(_jsonall, '\u101C\u103E\u1031\u1000\u102C\u1038', '/m/01lynh'), (0, _defineProperty3.default)(_jsonall, '\u1019\u102E\u1038\u1001\u102D\u102F\u1038\u1001\u1031\u102B\u1004\u103A\u1038\u1010\u102D\u102F\u1004\u103A\u1019\u103B\u102C\u1038', '/m/01jk_4'), (0, _defineProperty3.default)(_jsonall, '\u1011\u103D\u1014\u103A\u1005\u1000\u103A\u1019\u103B\u102C\u1038', '/m/013xlm'), (0, _defineProperty3.default)(_jsonall, 'firehydrants', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, 'buses', '/m/01bjv'), (0, _defineProperty3.default)(_jsonall, 't\xE0uthuy\u1EC1n', '/m/019jd'), (0, _defineProperty3.default)(_jsonall, 'gunungataubukit', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, 'tandaberhenti', '/m/02pv19'), (0, _defineProperty3.default)(_jsonall, 'tandajalan', '/m/01mqdt'), (0, _defineProperty3.default)(_jsonall, 'tumbuhan', '/m/05s2s'), (0, _defineProperty3.default)(_jsonall, 'pokok', '/m/07j7r'), (0, _defineProperty3.default)(_jsonall, 'rumput', '/m/08t9c_'), (0, _defineProperty3.default)(_jsonall, 'pokokrenek', '/m/0gqbt'), (0, _defineProperty3.default)(_jsonall, 'kaktus', '/m/025_v'), (0, _defineProperty3.default)(_jsonall, 'pokokpalma', '/m/0cdl1'), (0, _defineProperty3.default)(_jsonall, 'alamsemulajadi', '/m/05h0n'), (0, _defineProperty3.default)(_jsonall, 'airterjun', '/m/0j2kx'), (0, _defineProperty3.default)(_jsonall, 'pergunungan', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, 'bukitbukau', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, 'badanair', '/m/03ktm1'), (0, _defineProperty3.default)(_jsonall, 'sungai-sungai', '/m/06cnp'), (0, _defineProperty3.default)(_jsonall, 'pantai', '/m/0b3yr'), (0, _defineProperty3.default)(_jsonall, 'matahari', '/m/06m_p'), (0, _defineProperty3.default)(_jsonall, 'Bulan', '/m/04wv_'), (0, _defineProperty3.default)(_jsonall, 'langit', '/m/01bqvp'), (0, _defineProperty3.default)(_jsonall, 'kenderaan', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, 'kereta', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, 'basikal', '/m/0199g'), (0, _defineProperty3.default)(_jsonall, 'motosikal', '/m/04_sv'), (0, _defineProperty3.default)(_jsonall, 'trakpikap', '/m/0cvq3'), (0, _defineProperty3.default)(_jsonall, 'trakkomersial', '/m/0fkwjg'), (0, _defineProperty3.default)(_jsonall, 'bot', '/m/019jd'), (0, _defineProperty3.default)(_jsonall, 'limosin', '/m/01lcw4'), (0, _defineProperty3.default)(_jsonall, 'teksi', '/m/0pg52'), (0, _defineProperty3.default)(_jsonall, 'bassekolah', '/m/02yvhj'), (0, _defineProperty3.default)(_jsonall, 'bas', '/m/01bjv'), (0, _defineProperty3.default)(_jsonall, 'kenderaanpembinaan', '/m/02gx17'), (0, _defineProperty3.default)(_jsonall, 'patung-patung', '/m/013_1c'), (0, _defineProperty3.default)(_jsonall, 'airpancut', '/m/0h8lhkg'), (0, _defineProperty3.default)(_jsonall, 'jambatan', '/m/015kr'), (0, _defineProperty3.default)(_jsonall, 'jeti', '/m/01phq4'), (0, _defineProperty3.default)(_jsonall, 'bangunanpencakarlangit', '/m/079cl'), (0, _defineProperty3.default)(_jsonall, 'tiangatautiang', '/m/01_m7'), (0, _defineProperty3.default)(_jsonall, 'kacaberwarna', '/m/011y23'), (0, _defineProperty3.default)(_jsonall, 'rumah', '/m/03jm5'), (0, _defineProperty3.default)(_jsonall, 'bangunananapartmen', '/m/01nblt'), (0, _defineProperty3.default)(_jsonall, 'rumahcahaya', '/m/04h7h'), (0, _defineProperty3.default)(_jsonall, 'stesenKeretapi', '/m/0py27'), (0, _defineProperty3.default)(_jsonall, 'abu', '/m/01n6fd'), (0, _defineProperty3.default)(_jsonall, 'afirehydrant', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, 'papaniklan', '/m/01knjb'), (0, _defineProperty3.default)(_jsonall, 'jalanraya', '/m/06gfj'), (0, _defineProperty3.default)(_jsonall, 'lintasanpejalankaki', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, 'lampuisyarat', '/m/015qff'), (0, _defineProperty3.default)(_jsonall, 'pintugaraged', '/m/08l941'), (0, _defineProperty3.default)(_jsonall, 'perhentianbas', '/m/01jw_1'), (0, _defineProperty3.default)(_jsonall, 'Kontrafik', '/m/03sy7v'), (0, _defineProperty3.default)(_jsonall, 'metertempatletakkereta', '/m/015qbp'), (0, _defineProperty3.default)(_jsonall, 'tangga', '/m/01lynh'), (0, _defineProperty3.default)(_jsonall, 'cerobongasap', '/m/01jk_4'), (0, _defineProperty3.default)(_jsonall, 'traktor', '/m/013xlm'), (0, _defineProperty3.default)(_jsonall, 'pilibomba', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, 'serombongasap', '/m/01jk_4'), (0, _defineProperty3.default)(_jsonall, 'stopsigns', '/m/02pv19'), (0, _defineProperty3.default)(_jsonall, 'streetsigns', '/m/01mqdt'), (0, _defineProperty3.default)(_jsonall, 'plants', '/m/05s2s'), (0, _defineProperty3.default)(_jsonall, 'trees', '/m/07j7r'), (0, _defineProperty3.default)(_jsonall, 'grass', '/m/08t9c_'), (0, _defineProperty3.default)(_jsonall, 'shrubs', '/m/0gqbt'), (0, _defineProperty3.default)(_jsonall, 'cactus', '/m/025_v'), (0, _defineProperty3.default)(_jsonall, 'palmtrees', '/m/0cdl1'), (0, _defineProperty3.default)(_jsonall, 'nature', '/m/05h0n'), (0, _defineProperty3.default)(_jsonall, 'waterfalls', '/m/0j2kx'), (0, _defineProperty3.default)(_jsonall, 'mountainsorhills', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, 'bodiesofwater', '/m/03ktm1'), (0, _defineProperty3.default)(_jsonall, 'rivers', '/m/06cnp'), (0, _defineProperty3.default)(_jsonall, 'beaches', '/m/0b3yr'), (0, _defineProperty3.default)(_jsonall, 'theSun', '/m/06m_p'), (0, _defineProperty3.default)(_jsonall, 'theMoon', '/m/04wv_'), (0, _defineProperty3.default)(_jsonall, 'thesky', '/m/01bqvp'), (0, _defineProperty3.default)(_jsonall, 'vehicles', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, 'cars', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, 'bicycles', '/m/0199g'), (0, _defineProperty3.default)(_jsonall, 'motorcycles', '/m/04_sv'), (0, _defineProperty3.default)(_jsonall, 'pickuptrucks', '/m/0cvq3'), (0, _defineProperty3.default)(_jsonall, 'commercialtrucks', '/m/0fkwjg'), (0, _defineProperty3.default)(_jsonall, 'boats', '/m/019jd'), (0, _defineProperty3.default)(_jsonall, 'limousines', '/m/01lcw4'), (0, _defineProperty3.default)(_jsonall, 'taxis', '/m/0pg52'), (0, _defineProperty3.default)(_jsonall, 'schoolbus', '/m/02yvhj'), (0, _defineProperty3.default)(_jsonall, 'bus', '/m/01bjv'), (0, _defineProperty3.default)(_jsonall, 'constructionvehicle', '/m/02gx17'), (0, _defineProperty3.default)(_jsonall, 'statues', '/m/013_1c'), (0, _defineProperty3.default)(_jsonall, 'fountains', '/m/0h8lhkg'), (0, _defineProperty3.default)(_jsonall, 'bridges', '/m/015kr'), (0, _defineProperty3.default)(_jsonall, 'pier', '/m/01phq4'), (0, _defineProperty3.default)(_jsonall, 'skyscraper', '/m/079cl'), (0, _defineProperty3.default)(_jsonall, 'pillarsorcolumns', '/m/01_m7'), (0, _defineProperty3.default)(_jsonall, 'stainedglass', '/m/011y23'), (0, _defineProperty3.default)(_jsonall, 'ahouse', '/m/03jm5'), (0, _defineProperty3.default)(_jsonall, 'anapartmentbuilding', '/m/01nblt'), (0, _defineProperty3.default)(_jsonall, 'alighthouse', '/m/04h7h'), (0, _defineProperty3.default)(_jsonall, 'atrainstation', '/m/0py27'), (0, _defineProperty3.default)(_jsonall, 'ashed', '/m/01n6fd'), (0, _defineProperty3.default)(_jsonall, 'afirehydrant', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, 'abillboard', '/m/01knjb'), (0, _defineProperty3.default)(_jsonall, 'roads', '/m/06gfj'), (0, _defineProperty3.default)(_jsonall, 'crosswalks', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, 'trafficlights', '/m/015qff'), (0, _defineProperty3.default)(_jsonall, 'garagedoors', '/m/08l941'), (0, _defineProperty3.default)(_jsonall, 'busstops', '/m/01jw_1'), (0, _defineProperty3.default)(_jsonall, 'trafficcones', '/m/03sy7v'), (0, _defineProperty3.default)(_jsonall, 'parkingmeters', '/m/015qbp'), (0, _defineProperty3.default)(_jsonall, 'stairs', '/m/01lynh'), (0, _defineProperty3.default)(_jsonall, 'chimneys', '/m/01jk_4'), (0, _defineProperty3.default)(_jsonall, 'tractors', '/m/013xlm'), (0, _defineProperty3.default)(_jsonall, '\u8DEF\u6807', '/m/01mqdt'), (0, _defineProperty3.default)(_jsonall, '\u82B1', '/m/0c9ph5'), (0, _defineProperty3.default)(_jsonall, '\u6811\u6728', '/m/07j7r'), (0, _defineProperty3.default)(_jsonall, '\u68D5\u6988\u6811', '/m/0cdl1'), (0, _defineProperty3.default)(_jsonall, '\u7011\u5E03', '/m/0j2kx'), (0, _defineProperty3.default)(_jsonall, '\u5C71', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, '\u6C34\u57DF', '/m/03ktm1'), (0, _defineProperty3.default)(_jsonall, '\u6CB3\u6D41', '/m/06cnp'), (0, _defineProperty3.default)(_jsonall, '\u6D77\u6EE9', '/m/0b3yr'), (0, _defineProperty3.default)(_jsonall, '\u592A\u9633', '/m/06m_p'), (0, _defineProperty3.default)(_jsonall, '\u6708\u4EAE', '/m/04wv_'), (0, _defineProperty3.default)(_jsonall, '\u5929\u7A7A', '/m/01bqvp'), (0, _defineProperty3.default)(_jsonall, '\u4EA4\u901A\u5DE5\u5177', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, '\u5C0F\u8F7F\u8F66', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, '\u673A\u52A8\u8F66', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, '\u81EA\u884C\u8F66', '/m/0199g'), (0, _defineProperty3.default)(_jsonall, '\u6469\u6258\u8F66', '/m/04_sv'), (0, _defineProperty3.default)(_jsonall, '\u76AE\u5361\u8F66', '/m/0cvq3'), (0, _defineProperty3.default)(_jsonall, '\u5546\u7528\u5361\u8F66', '/m/0fkwjg'), (0, _defineProperty3.default)(_jsonall, '\u8239', '/m/019jd'), (0, _defineProperty3.default)(_jsonall, '\u8C6A\u534E\u8F7F\u8F66', '/m/01lcw4'), (0, _defineProperty3.default)(_jsonall, '\u51FA\u79DF\u8F66', '/m/0pg52'), (0, _defineProperty3.default)(_jsonall, '\u6821\u8F66', '/m/02yvhj'), (0, _defineProperty3.default)(_jsonall, '\u516C\u4EA4\u8F66', '/m/01bjv'), (0, _defineProperty3.default)(_jsonall, '\u706B\u8F66', '/m/07jdr'), (0, _defineProperty3.default)(_jsonall, '\u65BD\u5DE5\u8F66\u8F86', '/m/02gx17'), (0, _defineProperty3.default)(_jsonall, '\u96D5\u50CF', '/m/013_1c'), (0, _defineProperty3.default)(_jsonall, '\u55B7\u6CC9', '/m/0h8lhkg'), (0, _defineProperty3.default)(_jsonall, '\u6865', '/m/015kr'), (0, _defineProperty3.default)(_jsonall, '\u7801\u5934', '/m/01phq4'), (0, _defineProperty3.default)(_jsonall, '\u6469\u5929\u5927\u697C', '/m/079cl'), (0, _defineProperty3.default)(_jsonall, '\u67F1\u5B50', '/m/01_m7'), (0, _defineProperty3.default)(_jsonall, '\u5F69\u8272\u73BB\u7483', '/m/011y23'), (0, _defineProperty3.default)(_jsonall, '\u623F\u5C4B', '/m/03jm5'), (0, _defineProperty3.default)(_jsonall, '\u516C\u5BD3\u697C', '/m/01nblt'), (0, _defineProperty3.default)(_jsonall, '\u706F\u5854', '/m/04h7h'), (0, _defineProperty3.default)(_jsonall, '\u706B\u8F66\u7AD9', '/m/0py27'), (0, _defineProperty3.default)(_jsonall, '\u906E\u68DA', '/m/01n6fd'), (0, _defineProperty3.default)(_jsonall, '\u6D88\u9632\u6813', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, '\u6D88\u706B\u6813', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, '\u5E7F\u544A\u724C', '/m/01knjb'), (0, _defineProperty3.default)(_jsonall, '\u9053\u8DEF', '/m/06gfj'), (0, _defineProperty3.default)(_jsonall, '\u4EBA\u884C\u6A2A\u9053', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, '\u8FC7\u8857\u4EBA\u884C\u9053', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, '\u7EA2\u7EFF\u706F', '/m/015qff'), (0, _defineProperty3.default)(_jsonall, '\u8F66\u5E93\u95E8', '/m/08l941'), (0, _defineProperty3.default)(_jsonall, '\u516C\u4EA4\u7AD9', '/m/01jw_1'), (0, _defineProperty3.default)(_jsonall, '\u9525\u5F62\u4EA4\u901A\u8DEF\u6807', '/m/03sy7v'), (0, _defineProperty3.default)(_jsonall, '\u505C\u8F66\u8BA1\u65F6\u5668', '/m/015qbp'), (0, _defineProperty3.default)(_jsonall, '\u505C\u8F66\u8BA1\u4EF7\u8868', '/m/015qbp'), (0, _defineProperty3.default)(_jsonall, '\u697C\u68AF', '/m/01lynh'), (0, _defineProperty3.default)(_jsonall, '\u70DF\u56F1', '/m/01jk_4'), (0, _defineProperty3.default)(_jsonall, '\u62D6\u62C9\u673A', '/m/013xlm'), (0, _defineProperty3.default)(_jsonall, '\u505C\u8F66\u6807\u5FD7', '/m/02pv19'), (0, _defineProperty3.default)(_jsonall, '\u8DEF\u724C', '/m/01mqdt'), (0, _defineProperty3.default)(_jsonall, '\u690D\u7269', '/m/05s2s'), (0, _defineProperty3.default)(_jsonall, '\u6811', '/m/07j7r'), (0, _defineProperty3.default)(_jsonall, '\u8349', '/m/08t9c_'), (0, _defineProperty3.default)(_jsonall, '\u68D5\u6988\u6811', '/m/0cdl1'), (0, _defineProperty3.default)(_jsonall, '\u81EA\u7136', '/m/05h0n'), (0, _defineProperty3.default)(_jsonall, '\u4E18\u9675', '/m/09d_r'), (0, _defineProperty3.default)(_jsonall, '\u6C34\u4F53', '/m/03ktm1'), (0, _defineProperty3.default)(_jsonall, '\u6D77\u6EE9', '/m/0b3yr'), (0, _defineProperty3.default)(_jsonall, '\u5929\u7A7A', '/m/01bqvp'), (0, _defineProperty3.default)(_jsonall, '\u8F66\u8F86', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, '\u6C7D\u8F66', '/m/0k4j'), (0, _defineProperty3.default)(_jsonall, '\u6469\u6258\u8F66', '/m/04_sv'), (0, _defineProperty3.default)(_jsonall, '\u5546\u4E1A\u5361\u8F66', '/m/0fkwjg'), (0, _defineProperty3.default)(_jsonall, '\u8C6A\u534E\u8F7F\u8F66', '/m/01lcw4'), (0, _defineProperty3.default)(_jsonall, '\u516C\u5171\u6C7D\u8F66', '/m/01bjv'), (0, _defineProperty3.default)(_jsonall, '\u5EFA\u7B51\u8F66\u8F86', '/m/02gx17'), (0, _defineProperty3.default)(_jsonall, '\u96D5\u50CF', '/m/013_1c'), (0, _defineProperty3.default)(_jsonall, '\u652F\u67F1\u67F1', '/m/01_m7'), (0, _defineProperty3.default)(_jsonall, '\u5F69\u8272\u73BB\u7483', '/m/011y23'), (0, _defineProperty3.default)(_jsonall, '\u623F\u5B50', '/m/03jm5'), (0, _defineProperty3.default)(_jsonall, '\u7070\u70EC', '/m/01n6fd'), (0, _defineProperty3.default)(_jsonall, '\u6D88\u706B\u6813', '/m/01pns0'), (0, _defineProperty3.default)(_jsonall, '\u9053\u8DEF', '/m/06gfj'), (0, _defineProperty3.default)(_jsonall, '\u4EBA\u884C\u6A2A\u9053', '/m/014xcs'), (0, _defineProperty3.default)(_jsonall, '\u4EA4\u901A\u706F', '/m/015qff'), (0, _defineProperty3.default)(_jsonall, '\u8F66\u5E93\u95E8', '/m/08l941'), (0, _defineProperty3.default)(_jsonall, '\u5DF4\u58EB\u7AD9', '/m/01jw_1'), (0, _defineProperty3.default)(_jsonall, '\u4EA4\u901A\u9525', '/m/03sy7v'), (0, _defineProperty3.default)(_jsonall, '\u505C\u8F66\u54AA\u8868', '/m/015qbp'), (0, _defineProperty3.default)(_jsonall, '\u697C\u68AF', '/m/01lynh'), (0, _defineProperty3.default)(_jsonall, '\u70DF\u56F1', '/m/01jk_4'), _jsonall);

/***/ }),
/* 191 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _defineProperty = __webpack_require__(192);

var _defineProperty2 = _interopRequireDefault(_defineProperty);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = function (obj, key, value) {
  if (key in obj) {
    (0, _defineProperty2.default)(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
};

/***/ }),
/* 192 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(193), __esModule: true };

/***/ }),
/* 193 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(194);
var $Object = __webpack_require__(5).Object;
module.exports = function defineProperty(it, key, desc) {
  return $Object.defineProperty(it, key, desc);
};


/***/ }),
/* 194 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(14);
// 19.1.2.4 / 15.2.3.6 Object.defineProperty(O, P, Attributes)
$export($export.S + $export.F * !__webpack_require__(13), 'Object', { defineProperty: __webpack_require__(17).f });


/***/ })
/******/ ]);
//# sourceMappingURL=captcha2.js.map